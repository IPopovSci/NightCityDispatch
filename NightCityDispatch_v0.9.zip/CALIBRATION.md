# Calibrating the district table

District response doctrine is the highest-value axis in the whole design — the
thing that makes the mod *Night City* rather than "cops respond". The doctrine
itself is already written. What it needs from you is a map: which world
coordinates are which district.

That table ships empty, deliberately. See `docs/BLOCKERS.md` for why. Filling
it in takes about fifteen minutes.

Until you do, every incident resolves to the `Unlisted` profile — a moderate,
Heywood-ish response everywhere. The mod works; it just is not yet doing the
one thing that makes it interesting.

---

## What you are filling in

Zones are **circles**: a centre in world X/Y and a radius in metres. Not boxes,
because a circle is one point and one number, which is exactly what you can
read off the screen while standing somewhere.

Overlaps are fine and expected. **The smallest circle containing a point wins**,
so you can drop a tight circle for a neighbourhood inside a loose one for its
district and the neighbourhood takes precedence.

Wrong numbers cannot crash anything. The worst case is a district responding
with the wrong doctrine, which the probe will show you.

---

## Procedure

**1. Turn on calibration mode.**

In `r6/scripts/NCDispatch/NCD_Config.reds`:

```reds
public let calibrationMode: Bool = true;
```

Relaunch. redscript recompiles on launch.

**2. Watch the probe.**

Every third on-screen line is now:

```
NCD calib pos -1387.4 1455.9 22.1 -> Unlisted (0 zones defined)
```

Those three numbers are V's world X, Y and Z. **You only need X and Y.**

The name after the arrow is the zone that position currently resolves to, which
is how you check your work as you go.

**3. Walk to the middle of a district and write down X and Y.**

Somewhere central and unambiguous. For a large district, stand roughly in the
middle and estimate a radius that covers it without swallowing its neighbours —
400–800 m is a reasonable range for a district, 200–400 m for a neighbourhood.

You do not need to be precise. You need the right doctrine to fire in roughly
the right place.

**4. Add a line to `BuildZones()` in `NCD_Doctrine.reds`.**

```reds
private func BuildZones() -> Void {
  // ... the reset lines stay as they are ...

  this.AddZone(NCDZone.WatsonCentre(), -1387.0, 1456.0, 450.0);
  this.AddZone(NCDZone.Northside(),    -1050.0, 2100.0, 350.0);
  this.AddZone(NCDZone.Pacifica(),     -1900.0, -1500.0, 700.0);
}
```

Argument order: **zone, X, Y, radius**.

**5. Relaunch and check.**

Walk back through the districts you defined. The probe's calibration line
should now name them instead of `Unlisted`.

**6. Turn calibration mode off** when you are happy, so line 3 goes back to
reporting the hottest incident.

---

## The zones available

Every one of these already has a full doctrine profile in `BuildProfiles()`.
You are only supplying geometry.

| `NCDZone.…` | District | Delay | Ceiling |
|---|---|---|---|
| `CityCenter()` | Corpo Plaza, Downtown | 14 s | MaxTac, plus corporate override |
| `Westbrook()` | Charter Hill, North Oak | 20 s | Tactical |
| `Japantown()` | Japantown | 30 s | Tactical |
| `HeywoodGov()` | Wellsprings, The Glen | 26 s | Tactical |
| `VistaDelRey()` | Vista del Rey | 45 s | Containment |
| `WatsonCentre()` | Little China, Kabuki | 45 s | Containment |
| `Northside()` | Northside | 60 s | Patrol |
| `SantoDomingo()` | Arroyo, Rancho Coronado | 45 s | Containment |
| `Pacifica()` | Pacifica | — | **None** |
| `Badlands()` | Badlands | — | **None** |
| `Unknown()` | anywhere unlisted | 30 s | Tactical |

Pacifica and Badlands having no response is a feature, not an omission. It is
the clearest way the system communicates its own logic: firefights there
escalate forever and nobody comes.

---

## Tuning a district rather than moving it

The profiles themselves are in `BuildProfiles()` in the same file, one call per
district:

```reds
this.AddProfile(NCDZone.Northside(), "Watson - Northside",
                60.0,   // responseDelay  - seconds before the first unit
                1,      // ceiling        - 0 none, 1 patrol, 2 containment,
                        //                  3 tactical, 4 MaxTac
                1.7,    // thresholdMult  - >1 reacts to less readily
                0.6,    // forceMult      - wave size multiplier
                false,  // maxTacOverride - corporate pressure
                "Maelstrom territory. Minimal presence.");
```

`thresholdMult` scales every heat threshold. Above 1.0 the district needs more
before it reacts at all; below 1.0 it calls things in early.

`forceMult` scales wave size. `0.0` means the district never turns out,
whatever the ceiling says.

---

## Sanity checks once it is in

- A firefight in Pacifica should produce an incident that climbs and never
  gets a response. Probe line 3 shows a rising `heat` with `t0`, and `blk d`
  on line 2 climbing.
- The same firefight in City Center should get units in about 14 seconds.
- Northside should show `[capped 2->1]` in the `why=` field on line 3 when a
  fight there earns containment. That message is the district doctrine working.
