# Changelog

Every version names what was *wrong*, not just what changed.

---

## v0.9 — refactor

A rebuild on v0.8a's foundations. The prototype's skeleton was right and its
API surface was proven; what it lacked was room for the three things the design
actually asks for — entry conditions instead of thresholds, a lifecycle that
ends, and somewhere for the district layer to live.

**This version has not been compiled or run.** See `docs/BLOCKERS.md`.

### Defaults changed

Per CLAUDE.md, no default changes silently.

| Setting | Was | Now | Why |
|---|---|---|---|
| `despawnOnPlayerWanted` | `true` | **`false`** | This was v0.8a's circuit breaker. It deleted every unit and cleared every incident the instant V acquired a wanted level — which is the design document's loudest named anti-goal, "an incident silently ceasing to exist because V acquired a wanted level". Ownership transfer replaces it. Still available as an escape hatch. |
| `tier3Heat` | `34.0` | `30.0` | The ladder gained a fourth rung. Tier 3 is now Tactical, not MaxTac. |
| tier 2 unit roster | border guards + `prevention_maxtac_rifle_ma` | patrol officers | A MaxTac record in the mid tier made MaxTac a generic escalation step rather than a specialist unit. |
| tier 3 unit roster | MaxTac elites | border guards | Moved down one rung; these are the tactical unit. |

**No new TweakDB records were introduced.** The existing verified records —
all of them ones the game itself spawns dynamically as vehicle passengers —
were re-mapped across the design's four-tier ladder. That provenance is the
whole reason v0.4's crash is not repeatable.

New tunables: `waveBurstSize`, `spawnGraceSeconds`, `maxUnitsPerIncident`,
`tier4Heat`/`tier4Count`, the tier entry-condition group, the MaxTac gate
group, the arrival/staging group, the resolution group, and seven feature
flags. All are printed at session start.

### Bugs fixed

**Cross-wave target race.** `m_pendingTargets` was a single field written by
`SpawnWave` and read later by the asynchronous attach callback. Entities attach
when they stream in, routinely after the next wave has overwritten that field,
so units woke up holding a different incident's target list and marched to the
wrong place. Every unit now carries its own binding record, written at
`CreateEntity` time and looked up by ID on attach.

**Unbounded spawn loop latent in the tracking prune.** `LiveUnitCount` dropped
any record whose entity was not findable — but a *queued* entity is not
findable either, and `CreateEntity` returning a valid ID only means the request
was accepted. So a queued unit freed its cap slot, a replacement was spawned,
and the original was then deleted as an unrecognised stray when it finally
attached. Unattached requests now hold their slot for `spawnGraceSeconds`. This
is the same class of failure as v0.8's `GetTagged` bug and is the best
remaining explanation for entity accumulation.

**Heat mutated outside the lock.** The registry decayed heat under its write
lock and the dispatcher then added sustained heat to the same field outside it,
racing the sensor hooks. All heat and tally mutation now happens inside
`NCD_Registry` under the lock; `Tick` queries the world first with no lock held,
then applies.

**Perimeter and sustained-heat counts included our own officers.** Responding
units standing off at the staging distance are outside the perimeter radius by
design, so they would have reported the perimeter as broken the instant it was
established. Our units are now flagged in the participant list and excluded
from both counts — while still escalating the incident by dying, which is the
deliberate exception.

**Alerts could open incidents.** One startled civilian opened an incident. With
`maxIncidents` at 4, a busy street corner filled every slot with bystander
noise and locked out the firefight next to it. Fear now feeds an incident but
never starts one.

**The continuous-violence clock could stall.** It was only set from discrete
events. A long firefight that lulls and resumes without generating a fresh
combat-entry or death event — the normal shape of a lull — kept a zeroed clock,
which made both the tier 1 duration gate and the MaxTac duration gate
unreachable. Sustained combat now restarts it.

**Orphaned units.** An incident dropped for leaving the player's radius left
its units with no owner and no orders. They are now sent back to where they
came from and removed by the TTL at range, rather than either standing there
forever or being deleted where the player can see them.

### Escalation is now conditional

v0.8a decided everything with three float comparisons, which made MaxTac
reachable by standing next to a big enough fight for long enough. Heat is now a
*necessary* condition at every rung and a *sufficient* one at none:

- **Tier 1** needs sustained violence (~12 s) and at least two participants.
  This is also where melee brawls are excluded — weapon class is not readable
  from the available hooks, so duration and participant count carry it.
- **Tier 2** needs patrol already on the ground, plus either an officer down or
  the incident still running after 15 s.
- **Tier 3** needs containment on the ground, plus perimeter breaches, or
  officer casualties, or containment simply failing.
- **Tier 4** needs any one of: cyberpsychosis indicators, three officers down,
  tier 3 uncontained for 90 s of continuous violence, or City Center corporate
  pressure. Never raw heat, never raw combatant count, never a single burst.

`entryConditionsEnabled = false` restores heat-only gating, which is the only
practical way to test tiers 3 and 4 without staging a real battle.

### Incidents now end

A full lifecycle replaces the monotonic tier integer: `DORMANT → REPORTED →
RESPONDING → CONTAINING → ASSAULTING → SPECIALIST`, with every tier able to
terminate straight to `SWEEPING → WITHDRAWING → CLOSED`. When the shooting
stops units sweep, hold briefly, then leave the way they came. The location is
released so the same corner can generate a fresh incident later.

Orders are a function of state, not tier: containment holds at
`stagingDistance`, tactical closes to `assaultDistance`, sweeping closes
further, withdrawing heads back to the spawn point.

### District doctrine (design phase 3)

New `NCD_Doctrine`. Each district gets response delay, tier ceiling, severity
multiplier, turnout multiplier and the City Center corporate override — all
transcribed from the design document's table. Pacifica and the Badlands have a
ceiling of zero, which is a feature: firefights there escalate forever and
nobody comes.

**The position → district map ships empty.** Night City's world coordinates
could not be verified from any reachable source, and a wrong circle would
silence a district or summon MaxTac to Pacifica — both indistinguishable from a
logic bug. Everything resolves to one sane default until you fill it in;
`docs/CALIBRATION.md` is a fifteen-minute procedure with a probe mode that
prints V's position and resolved zone.

### Ownership transfer (design phase 1.5)

New `NCD_Ownership`. When V acquires a wanted level at a live incident, the
incident stays open and keeps escalating; every unit on scene stops ignoring V
as an active transition rather than a spawn-time policy; and spawn authority
passes to vanilla so the scene does not double in unit count with two
authorities disagreeing. When V's stars clear, control returns after
`ownershipReturnDelay`.

Officer deaths caused by V still count, including toward the MaxTac gate. That
is the good consequence and it is deliberately not special-cased away.

### Arrival

Spawn points are measured from the **incident**, not from V — v0.8a measured
from the player, which put responders wherever the player happened to be
standing relative to the fight. Direction is randomised per attempt, points
closer than `minSpawnDistanceFromPlayer` to V are rejected, three attempts
before giving up, and the failure is counted.

Waves now run on two clocks. Escalating to a higher tier is gated by
`waveCooldown`; topping the current tier up to its complement is gated by the
much shorter `waveStaggerSeconds`, `waveBurstSize` units at a time. One clock
cannot be right for both — either the ladder gets climbed in one breath or
reinforcements never arrive.

### Telemetry

Six separate spawn-stage counters, never collapsed. Four separate
"why nothing happened" counters — district ceiling, ownership, cap, entry
conditions — because a correctly suppressed response and a silently broken one
are otherwise identical. Every feature flag on screen every cycle. Every config
value dumped at session start.

`tools/ncd_check.py` fails the build if a tunable is not covered by the config
dump.

### Tooling

- `scripts/check.sh` — the build gate. Static checks always; a real `scc`
  compile when one is available.
- `tools/ncd_check.py` — provenance enforcement (CLAUDE.md's hard rule, made
  mechanical), unverified-syntax deny-list, own-symbol resolution, config
  coverage, brace balance.
- `tools/api-provenance.txt` — all 88 game symbols with sources. Adding a name
  is now a deliberate act.
- `scripts/fetch-decompiled.sh`, `scripts/package.sh`, `.redscript` workspace
  config.
- `docs/ARCHITECTURE.md`, `docs/CALIBRATION.md`, `docs/BLOCKERS.md`.

---

## v0.8a

`spawnEnabled` was shipped as `false`. It was flipped during the v0.7 crash
work and never announced, so v0.8 looked like a spawning regression against
v0.6 when in fact nothing was ever calling `CreateEntity`. The `SPAWN 0/94`
signature — attempts climbing, successes flat — is precisely what the disabled
branch produces. Back to `true`, and the probe now prefixes `SPAWN-OFF` when it
is disabled, because a switched-off spawner and a broken one produce identical
telemetry otherwise.

## v0.8

`GetTagged` returns 0 even while the attach callback is firing for those same
tags, so unit population is now tracked in an array we own, pruned against live
entities each tick. This was not cosmetic: the spawn cap is computed as
`maxLiveUnits - live`, so a permanently-zero count meant every wave spawned at
full size every cooldown with no ceiling. Unbounded entity accumulation is the
best explanation yet for the crashes.

Added `maxIncidentHeat` (55.0). A sustained fight was reaching 88+, far past the
MaxTac threshold, which kept re-triggering waves indefinitely.

## v0.7

Two real bugs, both mine.

Unshakeable police: officers go hostile to combatants, V catches a stray,
vanilla prevention grants stars, and `respectPlayerHeat` then STOPS forcing
friendly on every later spawn — so the mod bootstraps a wanted level and keeps
feeding it. Added a circuit breaker: any wanted level at all now despawns every
unit and stands the system down.

Reload crash: nothing was cleaned up at session end. Spawned entities and their
self-rescheduling TTL callbacks outlived the world. Added `OnDetach` teardown.

Also removed the forced `AlertPuppet` on spawn and the synthetic gunshot stim
used to make officers notice targets — broadcasting a gunshot beside the player
escalates everything in earshot, V included. Spawning now defaults OFF.

`suppressDuringChase` now defaults OFF. It stood the whole system down whenever
vanilla prevention was chasing you, which made the mod untestable, since picking
a fight with police is the easiest way to generate violence.

Added session teardown. Dynamic entities and their self-rescheduling TTL
callbacks were surviving into a disposed session, and the TTL callback then
called `DeleteEntity` on a system mid-disposal. Now despawns on
`Session/BeforeEnd` and `OnDetach`, and TTL callbacks bail out during teardown.

Added a detach counter to distinguish "never spawned" from "spawned and
immediately removed".

## v0.6

Checked the actual Codeware spec instead of inferring semantics from other
mods, and found two things.

First, `spawnInView = false` does not drop a spawn whose point is in view — it
QUEUES it until the player looks away, potentially forever. `CreateEntity` still
returns a valid ID. That is precisely the `spawn 6/6, units 0` signature.
Default is now true.

Second, and worse: the entity-attached callback was registered inside
`OnPlayerAttach`, which per the docs only fires on a NEW GAME. Loading a save
goes through `OnRestored`. So on any loaded save the callback never registered,
meaning no attitude assignment, no move orders, and no despawn cleanup.
Registration moved to `OnAttach` as the official example does. Also switched the
entity system handle to `wref` per the docs' warning about holding strong
references to game systems.

## v0.5

`spawn 5/5, units 0` showed that a valid EntityID from `CreateEntity` means the
request was accepted, not that an entity exists. Added an `att` counter
incremented in the entity-attached callback, which is the real measure, plus an
`A` flag confirming that callback registered at all. Exposed `allowSpawnInView`,
now defaulting true.

## v0.4

CRASH FIX. Tier 1 used `Character.sq023_policeman` and `mq010_policeman`, which
are quest-scene NPCs. They were taken from They Will Remember's identification
database, where they are used to RECOGNISE NPCs, not to spawn them — a record
existing in TweakDB is not the same as it being safe to instantiate cold. Tier 1
fires first, which matches the crash timing. All three tiers now use only records
the game itself spawns dynamically as vehicle passengers. Also dropped the
`n"random"` appearance override (unresolved appearances crash natively rather
than erroring), added a position sanity check before `CreateEntity`, and now
verify the returned EntityID. Added a `spawnEnabled` config switch for bisecting.

## v0.3

Officer deaths now escalate (8.0 heat) — the self-exclusion guard blocked our
units from generating heat by entering combat, which was correct, but it also
silently swallowed downed officers. Added sustained heat: each combatant still
alive and fighting feeds 0.35/sec into its incident, so long firefights escalate
rather than decaying below threshold. Waves can now repeat at the same tier
after cooldown. Probe now reports heat and spawn telemetry.

## v0.2a

Fixed an unresolved type annotation on `GetSystemRequestsHandler`.

## v0.2

Rewrote the sensor layer. v0.1 wrapped
`ReactionManagerComponent.OnDelayStimEvent`, which never fired once in a real
load order — confirmed by instrumented counter, not assumption. Now uses
`NPCPuppet.ChangeHighLevelState` and `ScriptedPuppet.OnDeath`. Added
self-exclusion guard against feedback loops. Counters moved into `NCDRegistry`
so the probe is safely deletable. `debugON` now defaults true.
