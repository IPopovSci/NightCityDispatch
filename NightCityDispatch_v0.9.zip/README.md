# Night City Dispatch

NCPD responds to violence that isn't yours.

Night City has no shortage of mods that make the world violent. What none of it
has is *consequence* — a six-man firefight can run for two minutes across from
a police checkpoint and nothing acknowledges it happened. NCPD in the base game
is a function of the player's wanted level and nothing else.

This is the reactive layer: violence in the world generates a police response
proportional to its scale, duration, and **location**, independent of whether V
is involved at all.

The goal is not "more cops". It is plausibility. You should be able to watch a
shootout escalate, see NCPD arrive, and find the outcome unsurprising.

Requires redscript. Nothing else.

---

## ⚠ Read this before installing v0.9

**This version has not been compiled or run.** No redscript compiler could be
obtained in the environment it was built in, and neither could the decompiled
game scripts or NativeDB — all three hosts are blocked by an egress policy.
`docs/BLOCKERS.md` has the full account.

What that means in practice:

- Run `./scripts/check.sh` on a machine with `scc` and the game installed
  **before you load it**. It auto-detects both and runs a real compile.
- Back up your save first.
- The mod introduces **zero new game API names** versus v0.8a — the symbol sets
  are identical, verified mechanically — so the risk is concentrated in syntax
  and logic rather than in unresolved types, which is the class of failure that
  takes down a load order.

---

## How it works

| Stage | What |
|---|---|
| **Sense** | Wraps `NPCPuppet.ChangeHighLevelState` and `ScriptedPuppet.OnDeath`. Combat entry, alerts, deaths and officer deaths feed heat at a position. |
| **Cluster** | Events within 30 m merge into one incident. Heat decays continuously. Ongoing combat feeds sustained heat, which is what separates a brief exchange from a battle. |
| **Locate** | The incident resolves to a district, which sets response delay, tier ceiling, severity threshold and turnout. |
| **Escalate** | Each tier has **entry conditions**, not just a heat threshold. Heat is necessary at every rung and sufficient at none. |
| **Dispatch** | Units are created off-camera near the incident, arrive over time, and stage at distance. |
| **Resolve** | When violence stops: sweep, hold, withdraw, close. The location is released so it can generate a fresh incident later. |

### The escalation ladder

**Tier 0 — Noticed.** Nothing happens. By far the most common outcome, and
what makes the rest feel earned.

**Tier 1 — Patrol.** Sustained violence, ~12 s, at least two participants.
Two officers. They stop at distance and do not push in.

**Tier 2 — Containment.** Still active after the first response, or the first
response took casualties. Perimeter, not assault. **This is the tier most
incidents should end at** — the gangs kill each other, police watch the exits.

**Tier 3 — Tactical.** Containment failing: combatants breaking the perimeter,
or officer casualties mounting. These actually push in.

**Tier 4 — MaxTac.** Any one of: cyberpsychosis indicators, three officers
down, tier 3 uncontained for 90 s of continuous violence, or City Center
corporate pressure. Explicitly *not* reachable on raw heat, raw combatant
count, or any single burst however intense.

### Districts

Response is a function of whose property is being damaged. City Center gets
MaxTac for things Santo Domingo would ignore. **Pacifica gets nothing at all,
and that is the point.**

The doctrine table is complete. The map from world position to district ships
**empty** and takes about fifteen minutes to fill in — see
`docs/CALIBRATION.md`. Until then everything uses one sane default profile.

### When V gets stars mid-incident

The incident does not disappear. V becomes the police operation's second
problem:

- The incident stays open and keeps escalating.
- Every unit on scene stops ignoring V — an active transition, not a policy
  applied at spawn.
- We stop *adding* units; vanilla owns spawning while it is chasing you.
- Officer deaths you caused still count, including toward the MaxTac gate. Get
  sloppy at someone else's firefight, kill three cops, and you can legitimately
  pull MaxTac onto a scene you were only ever a bystander at.
- When your stars clear, control returns after a few seconds. The fight was
  never yours to end.

---

## Install

Install as a normal MO2 mod, overwriting any previous version. Rename it
`[NoDelete] [00xx] Night City Dispatch` so Wabbajack keeps it across Ultrapunk
updates.

Or copy `r6/` into your Cyberpunk 2077 directory.

`./scripts/package.sh` builds an installable zip.

---

## Diagnostics

The probe prints to screen. At session start it dumps **every config value**,
one line at a time — most of the lost cycles on this project were a config
value being wrong rather than logic being wrong.

After that it rotates three lines every 5 s:

```
NCD 12 [CRSDUOTA] flags=MSDOGWXE sig 32/34/1+0 inc 3 (5 opened, 2 closed)
NCD pipe wave 4 req 8 acc 8 att 6 det 0 desp 2 live 6(tag0) | blk d0 o1 c0 e7 | navfail 1
NCD#3 CONT t2 zone=City Center ceil4 heat 41.2/55.0 viol 34s ppl 6 off 1 brch 0 top 2 own=us why=t3: contained
```

**Line 1 — is anything alive.** `[CRSDUOTA]` is one letter per system, a dash
means that piece is dead: Config, Registry, Spawner, Dispatcher, Units,
Ownership, docTrine, and **A** = the entity-attach callback registered.
`flags=` is the feature switches — a missing letter means that feature is off,
which is the difference between a broken subsystem and a disabled one.

**Line 2 — the spawn pipeline, one number per stage.**
`req → acc` is `CreateEntity` accepting the request, which means **queued**,
not created. `acc → att` is the attach callback, the first number that means a
unit really exists. If `acc` climbs while `att` stays flat, check for `A` on
line 1 and try `allowSpawnInView = true`. `live` is our own count and is the
real one; `tag` is `GetTagged`, kept only as a cross-check because it has been
observed reading 0 while units were demonstrably alive.
`blk` is why responses were withheld: **d**istrict ceiling, **o**wnership,
**c**ap, **e**ntry conditions. `e` climbing steadily is the mod working
correctly — most violence is supposed to produce nothing.

**Line 3 — the hottest incident.** State, tier, district and ceiling, heat and
peak, seconds of continuous violence, participants, officer deaths, perimeter
breaches, top single-combatant kill count, who owns spawning, and why the
current tier decision went the way it did.

In `calibrationMode` line 3 is replaced by V's world position and resolved
zone.

Set `probeON = false` to silence it. Nothing depends on it.

---

## Tuning

Everything is in `r6/scripts/NCDispatch/NCD_Config.reds`. Relaunch to apply.

| Symptom | Try |
|---|---|
| Too much police | raise `tier1Heat`, raise `heatDecayPerSec`, lower `maxLiveUnits` |
| Never triggers | lower `tier1Heat`, lower `tier1MinViolenceSeconds`; check `blk e` on line 2 |
| Response feels instant | that is the district profile's `responseDelay` — raise it |
| MaxTac too eager | raise `maxTacOfficerDeaths`, `maxTacUncontainedSeconds`, `maxTacSingleKillerKills` |
| Want to force a high tier for testing | `entryConditionsEnabled = false` — heat alone then decides |
| Alerted bystanders too noisy | drop `heatAlerted` to 0.3 |
| Crashing | `spawnEnabled = false`. If it stops, it is spawning, and the record list in `NCD_Units.reds` is the first place to look. |
| Unshakeable wanted level | `despawnOnPlayerWanted = true` — the v0.8a circuit breaker. It abandons live incidents, so it is a last resort. |

---

## Known limits

- Incidents exist near V only. Nothing escalates off-screen — the engine
  streams NPCs aggressively and there is nothing to police 300 m away.
- Officers arrive on foot. No vehicles, no AV drops.
- No arrests, no de-escalation, no surrender. Fights end when one side is down.
- Incidents do not survive a reload.
- Melee brawls are excluded by duration and participant count rather than by
  weapon class, which is not readable from the available hooks.

---

## Repository

```
r6/scripts/NCDispatch/   the mod
docs/                    design vision, architecture, calibration, blockers
scripts/check.sh         build gate — run this after every change
scripts/package.sh       build an installable zip
scripts/fetch-decompiled.sh   clone the decompiled game scripts
tools/api-provenance.txt every game symbol used, and where it came from
archive/                 previous releases
```

`CLAUDE.md` is the working agreement. Its first rule is the important one:
never invent an API name. `tools/ncd_check.py` enforces it mechanically.
