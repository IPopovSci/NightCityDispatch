module NCDispatch

// ============================================================================
//  Spawner and unit lifecycle
//
//  Creates responders off-camera near an incident, binds each one to the
//  incident it was sent to, sets attitude, gives it orders appropriate to the
//  incident's current state, and takes it away again when the incident ends.
//
//  THE BUG THIS FILE EXISTS TO FIX. v0.8a kept the current wave's targets in
//  a single `m_pendingTargets` field, written by SpawnWave and read later by
//  the asynchronous attach callback. Entities attach whenever they stream in,
//  which can be well after the next wave has overwritten that field - so units
//  from wave N routinely woke up holding wave N+1's target list and marched to
//  the wrong incident. Every unit now carries its own binding record, written
//  at CreateEntity time and read by ID when it attaches. Nothing is shared.
//
//  ARRIVAL. Spawn points are measured from the INCIDENT, not from V. v0.8a
//  measured from the player, which put responders wherever the player happened
//  to be standing relative to the fight - frequently behind them, arriving
//  from the wrong direction entirely.
// ============================================================================

// One unit we created, and everything we need to know to run its whole life.
public class NCDUnitRec extends IScriptable {
  public let id: EntityID;
  public let incidentId: Int32;
  public let tier: Int32;

  // Where it came from, so it can leave the way it came rather than
  // evaporating in front of the player.
  public let origin: Vector4;

  public let attached: Bool;

  // When CreateEntity accepted the request. A unit that has not attached yet
  // is not findable, so it cannot be pruned on "can I find this entity" - see
  // the comment on spawnGraceSeconds in NCD_Config.
  public let createdAt: Float;

  // Whether the friendly-to-V override is currently applied. Tracked rather
  // than assumed, because ownership transfer flips it on live units and
  // "friendly at spawn" stops being the answer the moment it does.
  public let friendlyForced: Bool;

  // The incident state this unit's current orders were issued for. Orders are
  // only re-sent when this goes stale, so a squad is not spammed with a fresh
  // move command every heartbeat.
  public let orderedForState: Int32;
}

public class NCDSpawner extends ScriptableSystem {

  private let m_entitySystem: wref<DynamicEntitySystem>;
  private let m_callbackSystem: wref<CallbackSystem>;

  private let m_units: array<ref<NCDUnitRec>>;
  private let m_lock: RWLock;
  private let m_hookRegistered: Bool;
  private let m_sessionEnding: Bool;

  public static func Get(gi: GameInstance) -> ref<NCDSpawner> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDSpawner") as NCDSpawner;
  }

  // ==========================================================================
  //  Registration
  //
  //  In OnAttach, NOT OnPlayerAttach. OnPlayerAttach fires on a new game only;
  //  loading a save goes through OnRestored. Registering there means that on
  //  any loaded save - which is how essentially everyone plays - the callback
  //  never registers, so no attitude is assigned, no orders are issued, and
  //  nothing is ever cleaned up.
  // ==========================================================================
  private func OnAttach() -> Void {
    this.m_entitySystem = GameInstance.GetDynamicEntitySystem();
    this.m_callbackSystem = GameInstance.GetCallbackSystem();

    if IsDefined(this.m_callbackSystem) {
      this.m_callbackSystem.RegisterCallback(n"Entity/Attached", this, n"OnUnitAttached")
        .AddTarget(DynamicEntityTarget.Tag(n"NCDispatch"));
      this.m_callbackSystem.RegisterCallback(n"Entity/Detach", this, n"OnUnitDetached")
        .AddTarget(DynamicEntityTarget.Tag(n"NCDispatch"));

      // Tear our entities down BEFORE the session disposes its own objects.
      // Dynamic entities and pending callbacks that outlive a session are a
      // documented route to a native crash on reload.
      this.m_callbackSystem.RegisterCallback(n"Session/BeforeEnd", this, n"OnSessionEnding");
      this.m_hookRegistered = true;
    };
  }

  private func OnDetach() -> Void {
    this.m_sessionEnding = true;
    this.DespawnAll();
  }

  // Either of these firing confirms the system is live and past pregame.
  private func OnPlayerAttach(request: ref<PlayerAttachRequest>) {
    this.MarkHookLive();
  }

  private func OnRestored(saveVersion: Int32, gameVersion: Int32) {
    this.MarkHookLive();
  }

  private func MarkHookLive() -> Void {
    if !this.m_hookRegistered {
      return;
    };
    let reg: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if IsDefined(reg) {
      reg.attachHookLive = true;
    };
  }

  protected cb func OnSessionEnding(event: ref<GameSessionEvent>) -> Void {
    this.m_sessionEnding = true;
    this.DespawnAll();
  }

  public func IsSessionEnding() -> Bool {
    return this.m_sessionEnding;
  }

  // ==========================================================================
  //  Population
  // ==========================================================================

  // Prunes dead and vanished units, then reports what is really there.
  // GetTagged has been observed returning 0 while the attach callback was
  // firing for those same tags, so it is never used as a population count -
  // and this count gates the spawn cap, so a wrong one means every wave
  // spawns at full size forever.
  public func LiveUnitCount() -> Int32 {
    let gi: GameInstance = this.GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let now: Float = EngineTime.ToFloat(GameInstance.GetSimTime(gi));
    let grace: Float = 30.0;
    if IsDefined(cfg) {
      grace = cfg.spawnGraceSeconds;
    };

    let kept: array<ref<NCDUnitRec>>;
    RWLock.Acquire(this.m_lock);
    for rec in this.m_units {
      let p: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, rec.id) as ScriptedPuppet;
      if IsDefined(p) {
        ArrayPush(kept, rec);
      } else {
        // Not findable. Either it has not streamed in yet, or it is gone.
        // A request that has not attached inside the grace window still holds
        // its slot: dropping it would free the cap, spawn a replacement, and
        // then delete the original as an unrecognised stray when it finally
        // arrived. Once the window passes, the request is written off.
        if !rec.attached && (now - rec.createdAt) < grace {
          ArrayPush(kept, rec);
        };
      };
    };
    this.m_units = kept;
    RWLock.Release(this.m_lock);
    return ArraySize(kept);
  }

  public func LiveUnitCountForIncident(incidentId: Int32) -> Int32 {
    let n: Int32 = 0;
    RWLock.AcquireShared(this.m_lock);
    for rec in this.m_units {
      if rec.incidentId == incidentId {
        n += 1;
      };
    };
    RWLock.ReleaseShared(this.m_lock);
    return n;
  }

  // Cross-check only, shown in the probe beside the real number.
  public func TaggedCount() -> Int32 {
    let es: wref<DynamicEntitySystem> = GameInstance.GetDynamicEntitySystem();
    if !IsDefined(es) {
      return 0;
    };
    return ArraySize(es.GetTagged(n"NCDispatch"));
  }

  public func AttachedCount() -> Int32 {
    let n: Int32 = 0;
    RWLock.AcquireShared(this.m_lock);
    for rec in this.m_units {
      if rec.attached {
        n += 1;
      };
    };
    RWLock.ReleaseShared(this.m_lock);
    return n;
  }

  private func FindRec(id: EntityID) -> ref<NCDUnitRec> {
    let found: ref<NCDUnitRec>;
    RWLock.AcquireShared(this.m_lock);
    for rec in this.m_units {
      if rec.id == id {
        found = rec;
      };
    };
    RWLock.ReleaseShared(this.m_lock);
    return found;
  }

  // ==========================================================================
  //  Spawning
  // ==========================================================================

  public func SpawnWave(inc: ref<NCDIncident>, tier: Int32, count: Int32) -> Int32 {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let gi: GameInstance = this.GetGameInstance();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    let units: ref<NCDUnits> = NCDUnits.Get(gi);
    let reg: ref<NCDRegistry> = NCDRegistry.Get(gi);

    if !IsDefined(cfg) || !IsDefined(player) || !IsDefined(units) || !IsDefined(inc) {
      return 0;
    };
    if count <= 0 {
      return 0;
    };

    let records: array<TweakDBID> = units.ForTier(tier);
    if ArraySize(records) == 0 {
      return 0;
    };

    if IsDefined(reg) {
      reg.unitsRequested += count;
    };

    // The bisect switch. Requests are still counted so the probe can show a
    // disabled spawner climbing attempts with zero successes, which is
    // exactly the signature a broken one produces - hence the SPAWN-OFF
    // prefix on the probe line.
    if !cfg.spawnEnabled {
      return 0;
    };
    if !IsDefined(this.m_entitySystem) {
      return 0;
    };

    let playerPos: Vector4 = player.GetWorldPosition();
    let now: Float = EngineTime.ToFloat(GameInstance.GetSimTime(gi));
    let spawned: Int32 = 0;
    let i: Int32 = 0;
    while i < count {
      let spawnPos: Vector4;
      if this.FindSpawnPoint(inc.position, playerPos, cfg.spawnDistanceFromIncident, spawnPos) {

        // Reject a degenerate navmesh result rather than handing garbage
        // coordinates to a native call.
        if !Vector4.IsZero(spawnPos) {
          let facing: Vector4 = inc.position - spawnPos;
          let len: Float = Vector4.Length(facing);
          let orientation: Quaternion;
          if len > 0.01 {
            orientation = EulerAngles.ToQuat(Vector4.ToRotation(facing / len));
          } else {
            orientation = player.GetWorldOrientation();
          };

          let pick: Int32 = RandRange(0, ArraySize(records));
          let spec = new DynamicEntitySpec();
          spec.recordID = records[pick];
          // No appearanceName override. n"random" is fine on gang records and
          // is not guaranteed to resolve on police ones, and an unresolved
          // appearance is a native crash rather than a script error.
          spec.position = spawnPos;
          spec.orientation = orientation;
          spec.spawnInView = cfg.allowSpawnInView;
          spec.alwaysSpawned = true;
          spec.persistState = false;
          spec.persistSpawn = false;
          spec.tags = [n"NCDispatch", n"NCDispatch.Unit"];

          let newID: EntityID = this.m_entitySystem.CreateEntity(spec);

          // A valid EntityID means the REQUEST WAS ACCEPTED, not that an
          // entity exists. With spawnInView false it may sit queued
          // indefinitely until the player looks away. Only the attach
          // callback proves a unit is really in the world.
          if EntityID.GetHash(newID) > 1u {
            spawned += 1;
            let rec: ref<NCDUnitRec> = new NCDUnitRec();
            rec.id = newID;
            rec.incidentId = inc.id;
            rec.tier = tier;
            rec.origin = spawnPos;
            rec.createdAt = now;
            rec.attached = false;
            rec.friendlyForced = false;
            rec.orderedForState = -1;
            RWLock.Acquire(this.m_lock);
            ArrayPush(this.m_units, rec);
            RWLock.Release(this.m_lock);
          };
        };
      } else {
        if IsDefined(reg) {
          reg.spawnPointFailures += 1;
        };
      };
      i += 1;
    };

    if IsDefined(reg) {
      reg.unitsAccepted += spawned;
    };
    inc.unitsDeployed += spawned;

    NCDLog(s"wave inc=\(inc.id) tier=\(tier) requested=\(count) accepted=\(spawned)");
    return spawned;
  }

  // ==========================================================================
  //  Spawn point selection
  //
  //  A navmesh point roughly `desired` metres from the INCIDENT, on the far
  //  side from nothing in particular - the direction is randomised per attempt
  //  so a repeatedly-reinforced incident does not grow a queue of officers all
  //  entering from the same alley.
  //
  //  Rejects anything too close to V. "Never spawn within player line of sight
  //  if avoidable" is not directly checkable here, but distance is, and
  //  distance is most of it.
  // ==========================================================================
  private func FindSpawnPoint(incidentPos: Vector4, playerPos: Vector4,
                              desired: Float, out spawnPos: Vector4) -> Bool {
    let gi: GameInstance = this.GetGameInstance();
    let nav: ref<NavigationSystem> = GameInstance.GetNavigationSystem(gi);
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    if !IsDefined(nav) || !IsDefined(cfg) {
      return false;
    };

    let attempt: Int32 = 0;
    while attempt < 3 {
      let angle: Float = RandF() * 360.0;
      let origin: Vector4 = incidentPos;
      origin.X += 2.0 * CosF(angle);
      origin.Y += 2.0 * SinF(angle);
      origin.Z = incidentPos.Z + 1.0;

      let originFinal: Vector4 = nav.GetNearestNavmeshPointBelowOnlyHumanNavmesh(origin, 0.5, 6);
      let position: Vector4;
      let ok: Bool = nav.FindNavmeshPointAwayFromReferencePoint(
        originFinal, incidentPos, desired, NavGenAgentSize.Human, position, 10.0, 60.0);

      if ok && !Vector4.IsZero(position) {
        if Vector4.Distance(position, playerPos) >= cfg.minSpawnDistanceFromPlayer {
          spawnPos = position;
          return true;
        };
      };
      attempt += 1;
    };
    return false;
  }

  // ==========================================================================
  //  Attach - the first moment a unit really exists
  // ==========================================================================
  private cb func OnUnitAttached(event: ref<EntityLifecycleEvent>) {
    let entity: ref<Entity> = event.GetEntity();
    if !IsDefined(entity) {
      return;
    };
    let officer: ref<ScriptedPuppet> = entity as ScriptedPuppet;
    if !IsDefined(officer) {
      return;
    };

    let gi: GameInstance = this.GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let reg: ref<NCDRegistry> = NCDRegistry.Get(gi);
    if IsDefined(reg) {
      reg.unitsAttached += 1;
      reg.attachHookLive = true;
    };
    if !IsDefined(cfg) {
      return;
    };

    let rec: ref<NCDUnitRec> = this.FindRec(officer.GetEntityID());
    if !IsDefined(rec) {
      // Tagged as ours but not in our records - almost certainly a leftover
      // from a previous session that survived teardown. Remove it rather than
      // adopting it; an unowned unit has no incident and would never leave.
      GameInstance.GetDynamicEntitySystem().DeleteEntity(officer.GetEntityID());
      return;
    };
    rec.attached = true;

    // Register with the incident as one of ours, so the incident can tell its
    // own responders apart from the people they were sent to deal with. This
    // is what stops our officers feeding sustained heat by fighting, while
    // still letting them escalate it by dying.
    let inc: ref<NCDIncident> = this.IncidentFor(rec);
    if IsDefined(inc) {
      inc.AddOwnUnit(officer.GetEntityID());
    };

    this.ApplyPlayerAttitude(officer, rec);
    this.ApplyCombatantAttitude(officer, inc);
    this.IssueOrders(officer, rec, inc);

    GameInstance.GetDelaySystem(gi).DelayCallback(
      NCDUnitTTLCallback.Create(officer.GetEntityID()), cfg.ttlInterval, true);
  }

  private cb func OnUnitDetached(event: ref<EntityLifecycleEvent>) {
    let reg: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if IsDefined(reg) {
      reg.unitsDetached += 1;
    };
  }

  private func IncidentFor(rec: ref<NCDUnitRec>) -> ref<NCDIncident> {
    // `none` is returned rather than a null literal: an undefined ref is the
    // pattern the rest of this codebase already relies on and IsDefined is the
    // only test used against it.
    let none: ref<NCDIncident>;
    let reg: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if !IsDefined(reg) || !IsDefined(rec) {
      return none;
    };
    for inc in reg.Snapshot() {
      if inc.id == rec.incidentId {
        return inc;
      };
    };
    return none;
  }

  // ==========================================================================
  //  Attitude
  // ==========================================================================

  // The load-bearing bit: these officers are not here for you.
  private func ApplyPlayerAttitude(officer: ref<ScriptedPuppet>, rec: ref<NCDUnitRec>) -> Void {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let gi: GameInstance = this.GetGameInstance();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    if !IsDefined(cfg) || !IsDefined(player) || !cfg.forceFriendlyToPlayer {
      return;
    };

    // If V is already wanted, hand attitude to vanilla and do not override.
    // Without this the mod launders your wanted level: it forces every new
    // officer friendly, so a wanted level it helped create can never be shaken.
    if cfg.respectPlayerHeat && NCDOwnership.PlayerIsWanted(gi) {
      rec.friendlyForced = false;
      return;
    };

    let officerAttitude: ref<AttitudeAgent> = officer.GetAttitudeAgent();
    let playerAttitude: ref<AttitudeAgent> = player.GetAttitudeAgent();
    if IsDefined(officerAttitude) && IsDefined(playerAttitude) {
      officerAttitude.SetAttitudeTowards(playerAttitude, EAIAttitude.AIA_Friendly);
      rec.friendlyForced = true;
    };
  }

  private func ApplyCombatantAttitude(officer: ref<ScriptedPuppet>, inc: ref<NCDIncident>) -> Void {
    if !IsDefined(inc) {
      return;
    };
    let gi: GameInstance = this.GetGameInstance();
    let officerAttitude: ref<AttitudeAgent> = officer.GetAttitudeAgent();
    if !IsDefined(officerAttitude) {
      return;
    };
    for c in inc.combatants {
      if !c.isOurs {
        let targetPuppet: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, c.id) as ScriptedPuppet;
        if IsDefined(targetPuppet) && ScriptedPuppet.IsActive(targetPuppet) {
          let targetAttitude: ref<AttitudeAgent> = targetPuppet.GetAttitudeAgent();
          if IsDefined(targetAttitude) {
            officerAttitude.SetAttitudeTowards(targetAttitude, EAIAttitude.AIA_Hostile);
            targetAttitude.SetAttitudeTowards(officerAttitude, EAIAttitude.AIA_Hostile);
          };
        };
      };
      // Deliberately NOT broadcasting a stim here. A synthetic gunshot next to
      // the player escalates everything in earshot, V included.
    };
  }

  // ==========================================================================
  //  Ownership transfer support (Phase 1.5)
  //
  //  "Attitude re-evaluates on wanted-state change - for existing units, not
  //   just new ones. This must be an active transition, not a policy applied
  //   at spawn."
  //
  //  v0.8a only ever set attitude once, at spawn, so a unit that was ignoring
  //  V thirty seconds ago carried on ignoring V after V shot at it.
  // ==========================================================================
  public func SetPlayerAttitudeOnAllUnits(friendly: Bool) -> Int32 {
    let gi: GameInstance = this.GetGameInstance();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    if !IsDefined(player) {
      return 0;
    };
    let playerAttitude: ref<AttitudeAgent> = player.GetAttitudeAgent();
    if !IsDefined(playerAttitude) {
      return 0;
    };

    let changed: Int32 = 0;
    RWLock.AcquireShared(this.m_lock);
    let snapshot: array<ref<NCDUnitRec>> = this.m_units;
    RWLock.ReleaseShared(this.m_lock);

    for rec in snapshot {
      if rec.friendlyForced != friendly {
        let p: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, rec.id) as ScriptedPuppet;
        if IsDefined(p) && ScriptedPuppet.IsActive(p) {
          let agent: ref<AttitudeAgent> = p.GetAttitudeAgent();
          if IsDefined(agent) {
            if friendly {
              agent.SetAttitudeTowards(playerAttitude, EAIAttitude.AIA_Friendly);
            } else {
              // Dropping the override back to whatever vanilla would have
              // said is not expressible with the attitude API verified for
              // this build, so the transition is expressed as its observable
              // outcome instead: a unit that was ignoring V becomes a normal
              // hostile cop. See docs/BLOCKERS.md.
              agent.SetAttitudeTowards(playerAttitude, EAIAttitude.AIA_Hostile);
            };
            rec.friendlyForced = friendly;
            changed += 1;
          };
        };
      };
    };
    return changed;
  }

  // ==========================================================================
  //  Orders
  //
  //  What a responder does is a function of the incident's state, not of its
  //  tier. Containment holds at distance; tactical pushes in; sweeping closes
  //  on the scene once the shooting stops; withdrawing leaves the way it came.
  // ==========================================================================
  public func RefreshOrders(inc: ref<NCDIncident>) -> Void {
    if !IsDefined(inc) {
      return;
    };
    let gi: GameInstance = this.GetGameInstance();
    RWLock.AcquireShared(this.m_lock);
    let snapshot: array<ref<NCDUnitRec>> = this.m_units;
    RWLock.ReleaseShared(this.m_lock);

    for rec in snapshot {
      if rec.incidentId == inc.id && rec.attached && rec.orderedForState != inc.state {
        let p: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, rec.id) as ScriptedPuppet;
        if IsDefined(p) && ScriptedPuppet.IsActive(p) {
          this.IssueOrders(p, rec, inc);
        };
      };
    };
  }

  private func IssueOrders(officer: ref<ScriptedPuppet>, rec: ref<NCDUnitRec>, inc: ref<NCDIncident>) -> Void {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    if !IsDefined(cfg) || !IsDefined(officer) {
      return;
    };

    let destination: Vector4;
    let standoff: Float;

    if IsDefined(inc) {
      destination = inc.position;
      standoff = this.StandoffFor(cfg, inc.state, rec.tier);

      // Withdrawing units head back to where they came from instead.
      if inc.state == NCDState.Withdrawing() {
        destination = rec.origin;
        standoff = 2.0;
      };
    } else {
      // Incident gone out from under us. Go home and wait to be removed.
      destination = rec.origin;
      standoff = 2.0;
    };

    // Spread so a squad does not form a perfect ring around the incident.
    standoff += RandF() * cfg.arrivalSpread;

    let moveCmd: ref<AIMoveToCommand> = new AIMoveToCommand();
    let end: AIPositionSpec;
    let endWorldPosition: WorldPosition;
    WorldPosition.SetVector4(endWorldPosition, destination);
    AIPositionSpec.SetWorldPosition(end, endWorldPosition);
    moveCmd.movementTarget = end;
    moveCmd.ignoreInCombat = false;
    moveCmd.alwaysUseStealth = false;
    moveCmd.ignoreNavigation = false;
    // Sprint is the only movement type verified against this build. A cautious
    // approach is expressed through the standoff distance instead of through
    // gait - they run to their position and then hold it, rather than jogging
    // into the middle of a firefight. See docs/BLOCKERS.md.
    moveCmd.movementType = moveMovementType.Sprint;
    moveCmd.desiredDistanceFromTarget = standoff;
    moveCmd.finishWhenDestinationReached = true;

    let evt: ref<AICommandEvent> = new AICommandEvent();
    evt.command = moveCmd;
    officer.QueueEvent(evt);

    let aiComponent = officer.GetAIControllerComponent();
    if IsDefined(aiComponent) {
      aiComponent.SendCommand(moveCmd);
    };

    if IsDefined(inc) {
      rec.orderedForState = inc.state;
    };
  }

  // How close a unit gets. This single number carries most of the design's
  // "police are reluctant" principle: they arrive cautiously, hold perimeter,
  // and wait for numbers before pushing in.
  private func StandoffFor(cfg: ref<NCDConfig>, state: Int32, tier: Int32) -> Float {
    if state == NCDState.Sweeping() {
      return cfg.sweepDistance;
    };
    if !cfg.stagingEnabled {
      return cfg.assaultDistance;
    };
    // Tactical and MaxTac actually push in. Everyone below them holds.
    if state == NCDState.Assaulting() || state == NCDState.Specialist() {
      return cfg.assaultDistance;
    };
    return cfg.stagingDistance;
  }

  // ==========================================================================
  //  Removal
  // ==========================================================================

  public func DespawnUnit(id: EntityID) -> Void {
    let es: wref<DynamicEntitySystem> = GameInstance.GetDynamicEntitySystem();
    if IsDefined(es) {
      es.DeleteEntity(id);
    };
    let reg: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if IsDefined(reg) {
      reg.unitsDespawned += 1;
    };
    let kept: array<ref<NCDUnitRec>>;
    RWLock.Acquire(this.m_lock);
    for rec in this.m_units {
      if rec.id != id {
        ArrayPush(kept, rec);
      };
    };
    this.m_units = kept;
    RWLock.Release(this.m_lock);
  }

  // Units whose incident no longer exists - the player walked out of range,
  // or it closed while they were still streaming in. They are sent back to
  // where they came from and left to the TTL, which removes them once they are
  // far enough away to go unnoticed. Deleting them where they stand is the
  // "cops evaporating in front of you" failure, which is as bad as the one
  // this mod exists to fix.
  public func HandleOrphans(liveIncidentIds: array<Int32>) -> Void {
    let gi: GameInstance = this.GetGameInstance();
    RWLock.AcquireShared(this.m_lock);
    let snapshot: array<ref<NCDUnitRec>> = this.m_units;
    RWLock.ReleaseShared(this.m_lock);

    for rec in snapshot {
      // -2 marks a unit that has already been told to go home, so the order is
      // issued once rather than every heartbeat.
      if rec.attached && rec.orderedForState != -2 && !ArrayContains(liveIncidentIds, rec.incidentId) {
        let p: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, rec.id) as ScriptedPuppet;
        if IsDefined(p) && ScriptedPuppet.IsActive(p) {
          let noIncident: ref<NCDIncident>;
          this.IssueOrders(p, rec, noIncident);
          rec.orderedForState = -2;
        };
      };
    };
  }

  public func DespawnForIncident(incidentId: Int32) -> Int32 {
    let doomed: array<EntityID>;
    RWLock.AcquireShared(this.m_lock);
    for rec in this.m_units {
      if rec.incidentId == incidentId {
        ArrayPush(doomed, rec.id);
      };
    };
    RWLock.ReleaseShared(this.m_lock);
    for id in doomed {
      this.DespawnUnit(id);
    };
    return ArraySize(doomed);
  }

  public func DespawnAll() -> Void {
    let es: wref<DynamicEntitySystem> = GameInstance.GetDynamicEntitySystem();
    let empty: array<ref<NCDUnitRec>>;
    let n: Int32 = 0;

    RWLock.Acquire(this.m_lock);
    for rec in this.m_units {
      if IsDefined(es) {
        es.DeleteEntity(rec.id);
        n += 1;
      };
    };
    this.m_units = empty;
    RWLock.Release(this.m_lock);

    let reg: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if IsDefined(reg) {
      reg.unitsDespawned += n;
    };

    // Belt and braces: anything carrying our tag that we somehow lost track of
    // goes too. Units that never leave are worse than units that never arrive.
    if IsDefined(this.m_entitySystem) {
      let strays: array<ref<Entity>> = this.m_entitySystem.GetTagged(n"NCDispatch");
      for u in strays {
        this.m_entitySystem.DeleteEntity(u.GetEntityID());
      };
    };
  }
}

// ============================================================================
//  Per-unit TTL
//
//  Reschedules itself until the unit is removed. Bails out during teardown -
//  calling DeleteEntity on a system that is mid-disposal is the prime suspect
//  for this project's reload crash.
// ============================================================================

public class NCDUnitTTLCallback extends DelayCallback {

  private let id: EntityID;

  public static func Create(id: EntityID) -> ref<NCDUnitTTLCallback> {
    let self: ref<NCDUnitTTLCallback> = new NCDUnitTTLCallback();
    self.id = id;
    return self;
  }

  public func Call() -> Void {
    let gi: GameInstance = GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    if !IsDefined(cfg) || !IsDefined(player) {
      return;
    };
    if GameInstance.GetSystemRequestsHandler().IsPreGame() {
      return;
    };

    let spawner: ref<NCDSpawner> = NCDSpawner.Get(gi);
    if !IsDefined(spawner) || spawner.IsSessionEnding() {
      return;
    };

    let puppet: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, this.id) as ScriptedPuppet;
    if !IsDefined(puppet) {
      // Already gone. Stop rescheduling and let the record be pruned.
      return;
    };

    let dist: Float = Vector4.Distance(puppet.GetWorldPosition(), player.GetWorldPosition());
    let dead: Bool = !ScriptedPuppet.IsActive(puppet);

    let remove: Bool = false;
    if dist > cfg.despawnDistance {
      remove = true;
    };
    // Bodies remain while the player can see them - the world keeps the
    // evidence. They are only removed once well out of sight.
    if dead && dist > cfg.corpseDespawnDistance {
      remove = true;
    };

    if remove {
      spawner.DespawnUnit(this.id);
      return;
    };

    GameInstance.GetDelaySystem(gi).DelayCallback(
      NCDUnitTTLCallback.Create(this.id), cfg.ttlInterval, true);
  }
}
