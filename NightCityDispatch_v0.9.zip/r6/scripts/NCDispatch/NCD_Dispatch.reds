module NCDispatch

// ============================================================================
//  Dispatcher - the heartbeat
//
//  Runs the incident lifecycle. Everything else in the mod is either feeding
//  this or being driven by it.
//
//    DORMANT -> REPORTED -> RESPONDING -> CONTAINING -> ASSAULTING
//                                                    -> SPECIALIST
//    any of the above -> SWEEPING -> WITHDRAWING -> CLOSED
//
//  Every tier can terminate straight to SWEEPING when the shooting stops, and
//  every incident that opens eventually reaches CLOSED. v0.8a had no such
//  guarantee: an incident's only exits were decaying below a heat floor or the
//  player walking away, and neither of those swept, withdrew, or released the
//  location so a fresh incident could happen there later.
// ============================================================================

public class NCDDispatcher extends ScriptableSystem {

  private let m_initialized: Bool;
  private let m_tickDelayID: DelayID;
  private let m_lastTick: Float;
  private let m_lastReason: String;

  public static func Get(gi: GameInstance) -> ref<NCDDispatcher> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDDispatcher") as NCDDispatcher;
  }

  public func LastReason() -> String {
    return this.m_lastReason;
  }

  protected func OnAttach() -> Void {
    if this.m_initialized {
      return;
    };
    this.m_initialized = true;
    this.m_lastReason = "";
    this.ScheduleTick(3.0);
  }

  protected func OnDetach() -> Void {
    let ds: ref<DelaySystem> = GameInstance.GetDelaySystem(this.GetGameInstance());
    if IsDefined(ds) {
      ds.CancelCallback(this.m_tickDelayID);
    };
  }

  private func ScheduleTick(interval: Float) -> Void {
    let ds: ref<DelaySystem> = GameInstance.GetDelaySystem(this.GetGameInstance());
    if IsDefined(ds) {
      let cb: ref<NCDHeartbeatCallback> = new NCDHeartbeatCallback();
      cb.system = this;
      this.m_tickDelayID = ds.DelayCallback(cb, interval);
    };
  }

  // ==========================================================================

  public func Heartbeat() -> Void {
    let gi: GameInstance = this.GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();

    if !IsDefined(cfg) || !cfg.modON {
      this.ScheduleTick(2.0);
      return;
    };
    if GameInstance.GetSystemRequestsHandler().IsPreGame() {
      this.ScheduleTick(2.0);
      return;
    };

    let player: ref<PlayerPuppet> = GetPlayer(gi);
    let registry: ref<NCDRegistry> = NCDRegistry.Get(gi);
    let spawner: ref<NCDSpawner> = NCDSpawner.Get(gi);
    let doctrine: ref<NCDDoctrine> = NCDDoctrine.Get(gi);
    let ownership: ref<NCDOwnership> = NCDOwnership.Get(gi);
    if !IsDefined(player) || !IsDefined(registry) || !IsDefined(spawner) {
      this.ScheduleTick(2.0);
      return;
    };

    let now: Float = EngineTime.ToFloat(GameInstance.GetSimTime(gi));
    let dt: Float = now - this.m_lastTick;
    if dt <= 0.0 || dt > 30.0 {
      dt = cfg.tickInterval;
    };
    this.m_lastTick = now;

    // --- legacy blunt switches ----------------------------------------------
    // Both default OFF now. despawnOnPlayerWanted is the v0.8a circuit
    // breaker, kept only as an escape hatch if a wanted level ever becomes
    // unshakeable again - it abandons live incidents, which is the behaviour
    // ownership transfer exists to replace.
    if cfg.despawnOnPlayerWanted && NCDOwnership.PlayerIsWanted(gi) {
      spawner.DespawnAll();
      registry.Clear();
      this.m_lastReason = "halted: despawnOnPlayerWanted";
      this.ScheduleTick(cfg.tickInterval);
      return;
    };
    if cfg.suppressDuringChase && NCDOwnership.PlayerIsChased(gi) {
      spawner.DespawnAll();
      registry.Clear();
      this.m_lastReason = "halted: suppressDuringChase";
      this.ScheduleTick(cfg.tickInterval);
      return;
    };

    let playerPos: Vector4 = player.GetWorldPosition();
    let incidents: array<ref<NCDIncident>> = registry.Tick(now, dt, playerPos);

    // Units whose incident no longer exists are sent home. Their TTL removes
    // them once they are far enough from the player to go unnoticed - they are
    // never deleted where they stand.
    let liveIds: array<Int32>;
    for inc in incidents {
      ArrayPush(liveIds, inc.id);
    };
    spawner.HandleOrphans(liveIds);

    if ArraySize(incidents) == 0 {
      this.m_lastReason = "";
      this.ScheduleTick(cfg.tickInterval);
      return;
    };

    // Ownership transfer runs before any dispatch decision, so a wanted-state
    // change is reflected in the same tick it happens.
    if IsDefined(ownership) {
      ownership.Update(now, incidents);
    };

    let live: Int32 = spawner.LiveUnitCount();

    for inc in incidents {
      live = this.AdvanceIncident(cfg, registry, spawner, doctrine, ownership, inc, now, live);
      spawner.RefreshOrders(inc);
    };

    this.ScheduleTick(cfg.tickInterval);
  }

  // ==========================================================================
  //  One incident, one tick. Returns the updated global live-unit count.
  // ==========================================================================
  private func AdvanceIncident(cfg: ref<NCDConfig>, registry: ref<NCDRegistry>,
                               spawner: ref<NCDSpawner>, doctrine: ref<NCDDoctrine>,
                               ownership: ref<NCDOwnership>, inc: ref<NCDIncident>,
                               now: Float, live: Int32) -> Int32 {

    // Zone is resolved once and then kept. An incident's centre drifts toward
    // new activity, and a firefight that wanders across a district boundary
    // should not change which precinct owns it halfway through.
    let profile: ref<NCDZoneProfile>;
    if IsDefined(doctrine) {
      if inc.zone == NCDZone.Unknown() {
        inc.zone = doctrine.Resolve(inc.position);
      };
      profile = doctrine.ProfileFor(inc.zone);
    };

    let reason: String;
    let earned: Int32 = NCDEscalation.DesiredTier(cfg, profile, inc, now, reason);
    let allowed: Int32 = NCDEscalation.ApplyCeiling(profile, earned);

    // "Northside earned tactical and was capped at patrol" is a different
    // world from "Northside never got past patrol", and only the first one
    // means the district tuning is doing its job.
    if allowed < earned && IsDefined(registry) {
      registry.blockedByDistrict += 1;
      reason = reason + " [capped " + ToString(earned) + "->" + ToString(allowed) + "]";
    };

    // Heat was high enough for a response and the entry conditions were not
    // met. This is the mod working as designed - most violence should produce
    // nothing - but it needs its own counter, because "heat never got there"
    // and "heat got there and the fight was too short to matter" are different
    // tuning problems with the same silent output.
    if earned == 0 && inc.heat >= cfg.tier1Heat && IsDefined(registry) {
      registry.blockedByEntryCond += 1;
    };
    this.m_lastReason = reason;

    let quiet: Bool = inc.SecondsQuiet(now) >= cfg.quietAfter;

    // --- terminal states ----------------------------------------------------
    if inc.state == NCDState.Closed() {
      return live;
    };

    if inc.state == NCDState.Withdrawing() {
      if inc.SecondsInState(now) >= cfg.withdrawSeconds {
        spawner.DespawnForIncident(inc.id);
        inc.SetState(NCDState.Closed(), now);
        NCDLog(s"incident \(inc.id) closed");
      };
      return live;
    };

    if inc.state == NCDState.Sweeping() {
      // Violence resumed. The sweep becomes a response again at whatever tier
      // was already on the ground - the same location generating a fresh fight
      // does not need a fresh incident.
      if !quiet && inc.heat >= cfg.tier1Heat {
        inc.SetState(NCDState.ForTier(inc.tier), now);
        NCDLog(s"incident \(inc.id) re-engaged");
        return live;
      };
      if inc.SecondsInState(now) >= cfg.sweepSeconds {
        if cfg.withdrawEnabled {
          inc.SetState(NCDState.Withdrawing(), now);
        } else {
          spawner.DespawnForIncident(inc.id);
          inc.SetState(NCDState.Closed(), now);
        };
      };
      return live;
    };

    // --- quiet ends any live response ---------------------------------------
    // "When violence stops, units sweep the area rather than vanishing."
    if quiet && NCDState.IsActiveResponse(inc.state) {
      if cfg.sweepEnabled {
        inc.SetState(NCDState.Sweeping(), now);
      } else {
        inc.SetState(NCDState.Withdrawing(), now);
      };
      return live;
    };

    // An incident that never got a response and has gone cold just closes.
    // The registry prunes it on the next tick.
    if quiet && inc.tier == 0 && inc.heat <= cfg.closeBelowHeat {
      inc.SetState(NCDState.Closed(), now);
      return live;
    };

    // --- nothing earned yet -------------------------------------------------
    if allowed <= 0 {
      // A district with a ceiling of zero is not a failure state. Pacifica
      // having no response is the clearest way the system communicates its own
      // logic: firefights escalate forever and nobody comes.
      if inc.state == NCDState.Dormant() && inc.heat > cfg.closeBelowHeat {
        inc.SetState(NCDState.Reported(), now);
      };
      return live;
    };

    // --- reported: start the response clock ---------------------------------
    if inc.state == NCDState.Dormant() || inc.state == NCDState.Reported() {
      if inc.respondAt <= 0.0 {
        let delay: Float = 30.0;
        if IsDefined(profile) {
          delay = profile.responseDelay;
        };
        inc.respondAt = now + delay;
        inc.SetState(NCDState.Reported(), now);
        NCDLog(s"incident \(inc.id) reported, zone=\(inc.zone) responding in \(delay)s");
      };
      // Response time is real. Delay is not a defect - it is the mechanism
      // that lets the player watch a situation develop.
      if now < inc.respondAt {
        return live;
      };
    };

    // --- dispatch -----------------------------------------------------------
    //
    // Two different things happen here and they run on different clocks.
    //
    // ESCALATING to a higher tier is gated by nextEscalationAt / waveCooldown,
    // so an incident cannot climb the whole ladder in one breath.
    //
    // TOPPING UP the current tier to its full complement is gated by
    // nextWaveAt / waveStaggerSeconds, because "2-3 more vehicles, 4-6
    // officers, arriving over ~20 s rather than at once" is what makes a
    // containment look like units converging on a scene rather than a squad
    // materialising in it.
    //
    // Two clocks, not one. Sharing a single clock means either escalation is
    // too fast or reinforcement is too slow, and no value is right for both.
    let escalating: Bool = allowed > inc.tier;
    let complement: Int32 = NCDEscalation.WaveSize(cfg, profile, allowed);
    let onScene: Int32 = spawner.LiveUnitCountForIncident(inc.id);

    if escalating {
      if now < inc.nextEscalationAt {
        return live;
      };
    } else {
      if onScene >= complement {
        return live;
      };
      if now < inc.nextWaveAt {
        return live;
      };
    };

    // Spawn authority may currently belong to vanilla. The incident keeps
    // running and keeps escalating - it just stops being the thing that spawns.
    if IsDefined(ownership) && !ownership.MaySpawnFor(inc) {
      if IsDefined(registry) {
        registry.blockedByOwnership += 1;
      };
      // The tier is still recorded as earned, so that when control returns the
      // response resumes where the incident actually is rather than replaying
      // the ladder from patrol.
      //
      // Only on an actual change. This branch runs every heartbeat for as long
      // as vanilla holds authority, and re-stamping tierEnteredAt each time
      // would keep SecondsAtTier pinned near zero - which is an input to the
      // tier 2 and tier 3 entry conditions, so the incident would stop being
      // able to escalate for exactly as long as V had stars. The whole point
      // of this path is that escalation continues.
      if allowed != inc.tier {
        inc.tier = allowed;
        inc.tierEnteredAt = now;
        inc.SetState(NCDState.ForTier(allowed), now);
      };
      return live;
    };

    let want: Int32 = complement - onScene;
    if want > cfg.waveBurstSize {
      want = cfg.waveBurstSize;
    };

    // Caps. Global first, then per-incident, so one firefight cannot eat the
    // entire budget and leave nothing for anything else happening nearby.
    let globalRoom: Int32 = cfg.maxLiveUnits - live;
    let incidentRoom: Int32 = cfg.maxUnitsPerIncident - onScene;
    if want > globalRoom {
      want = globalRoom;
    };
    if want > incidentRoom {
      want = incidentRoom;
    };

    if want <= 0 {
      if IsDefined(registry) {
        registry.blockedByCap += 1;
      };
      return live;
    };

    if IsDefined(registry) {
      registry.wavesRequested += 1;
    };

    let got: Int32 = spawner.SpawnWave(inc, allowed, want);
    if got > 0 {
      if escalating {
        inc.tier = allowed;
        inc.tierEnteredAt = now;
        inc.SetState(NCDState.ForTier(allowed), now);
        inc.nextEscalationAt = now + cfg.waveCooldown;
      };
      // Either way the rest of this tier's complement follows on the stagger
      // clock, so an escalation lands as a first vehicle plus arrivals rather
      // than as a finished squad.
      inc.nextWaveAt = now + cfg.waveStaggerSeconds;
      live += got;
      NCDLog(s"incident \(inc.id) tier=\(allowed) heat=\(inc.heat) got=\(got)/\(complement) live=\(live) why=\(reason)");
    };

    return live;
  }
}

public class NCDHeartbeatCallback extends DelayCallback {
  public let system: wref<NCDDispatcher>;
  public func Call() -> Void {
    if IsDefined(this.system) {
      this.system.Heartbeat();
    };
  }
}
