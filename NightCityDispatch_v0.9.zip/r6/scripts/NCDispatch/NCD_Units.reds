module NCDispatch

// ============================================================================
//  Unit rosters
//
//  READ THIS BEFORE ADDING A RECORD.
//
//  A TweakDB record existing is not the same as it being safe to spawn cold.
//  Quest-scene NPCs (sq*, mq* prefixes) exist in TweakDB, carry scene
//  dependencies, and hard-crash the game when instantiated from scratch. This
//  project has already lost a session to exactly that: v0.4's tier 1 used
//  Character.sq023_policeman, lifted from a mod that used it to RECOGNISE
//  NPCs rather than to create them.
//
//  Every record below is one the game itself spawns dynamically as a vehicle
//  passenger. That is the provenance, and it is the only provenance that
//  counts. Do not add a record here unless you can say where vanilla or a
//  working mod spawns it dynamically.
//
//  No appearanceName override anywhere. n"random" resolves fine on gang
//  records and is not guaranteed to on police records, and an unresolved
//  appearance is a native crash rather than a script error.
// ============================================================================

public class NCDUnits extends ScriptableSystem {

  public static func Get(gi: GameInstance) -> ref<NCDUnits> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDUnits") as NCDUnits;
  }

  // --- Tier 1: patrol response ----------------------------------------------
  // 1 cruiser, 2 officers. They arrive, they stop at distance, they do not
  // push. They are outnumbered and they know it.
  public func Tier1Units() -> array<TweakDBID> {
    return [
      t"Character.ncpd_inspector_ranged1_lexington_ma",
      t"Character.ncpd_inspector_melee1_baton_ma"
    ];
  }

  // --- Tier 2: containment --------------------------------------------------
  // More of the same officers, not better ones. Containment is a numbers and
  // positioning tier, not an equipment tier - they establish a perimeter and
  // wait the fight out. This is where most incidents should end.
  public func Tier2Units() -> array<TweakDBID> {
    return [
      t"Character.ncpd_inspector_ranged1_lexington_ma",
      t"Character.ncpd_inspector_melee1_baton_ma"
    ];
  }

  // --- Tier 3: tactical -----------------------------------------------------
  // Better armed and armoured, and they actually push in.
  //
  // CHANGED FROM v0.8a: these were tier 2 there, alongside
  // prevention_maxtac_rifle_ma. Having a MaxTac record in the mid tier made
  // MaxTac a generic escalation step, which the design lists as an anti-goal.
  // Same records, moved up one rung; nothing new was introduced.
  public func Tier3Units() -> array<TweakDBID> {
    return [
      t"Character.prevention_border_guards",
      t"Character.prevention_border_guards_shotgun"
    ];
  }

  // --- Tier 4: MaxTac -------------------------------------------------------
  // A psycho squad, not a SWAT escalation. Their arrival should be an event
  // the player remembers.
  //
  // prevention_maxtac_rifle_ma moved here from v0.8a's tier 2, where it did
  // not belong. Same verified record, correct rung.
  public func Tier4Units() -> array<TweakDBID> {
    return [
      t"Character.maxtac_rifle_ma_elite",
      t"Character.maxtac_shotgun_ma_elite",
      t"Character.maxtac_melee_ma_elite",
      t"Character.maxtac_gunner_mb_elite",
      t"Character.prevention_maxtac_rifle_ma"
    ];
  }

  public func ForTier(tier: Int32) -> array<TweakDBID> {
    if tier >= 4 {
      return this.Tier4Units();
    };
    if tier == 3 {
      return this.Tier3Units();
    };
    if tier == 2 {
      return this.Tier2Units();
    };
    return this.Tier1Units();
  }
}
