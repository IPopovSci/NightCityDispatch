module NCDispatch

// ============================================================================
//  Incident model
//
//  An incident is a cluster of violence in space and time. It has a lifecycle
//  and it always ends - "something that starts must resolve, get cleaned up,
//  and leave a trace. Units that never leave are worse than units that never
//  arrive."
//
//      DORMANT -> REPORTED -> RESPONDING -> CONTAINING -> ASSAULTING
//                                                      -> SPECIALIST
//      any of the above -> SWEEPING -> WITHDRAWING -> CLOSED
//
//  Every tier can terminate straight to SWEEPING when the shooting stops.
//  Most incidents should never get past REPORTED.
//
//  v0.8a had no lifecycle at all - only an Int32 tier that ratcheted up and
//  never came down, so an incident's only two ends were decaying below the
//  heat floor or leaving the player's radius. Neither of those sweeps, neither
//  withdraws, and neither closes cleanly enough for the same street corner to
//  generate a fresh incident afterwards.
// ============================================================================

public class NCDState {
  public static func Dormant()     -> Int32 { return 0; }
  public static func Reported()    -> Int32 { return 1; }
  public static func Responding()  -> Int32 { return 2; }
  public static func Containing()  -> Int32 { return 3; }
  public static func Assaulting()  -> Int32 { return 4; }
  public static func Specialist()  -> Int32 { return 5; }
  public static func Sweeping()    -> Int32 { return 6; }
  public static func Withdrawing() -> Int32 { return 7; }
  public static func Closed()      -> Int32 { return 8; }

  // Short codes for the probe. Long enough to read, short enough to fit.
  public static func Name(s: Int32) -> String {
    if s == 0 { return "DORM"; };
    if s == 1 { return "REPT"; };
    if s == 2 { return "RESP"; };
    if s == 3 { return "CONT"; };
    if s == 4 { return "ASLT"; };
    if s == 5 { return "SPEC"; };
    if s == 6 { return "SWEP"; };
    if s == 7 { return "WDRW"; };
    return "CLSD";
  }

  // States in which units are deployed and the incident is still a police
  // operation rather than a cleanup.
  public static func IsActiveResponse(s: Int32) -> Bool {
    return s >= 2 && s <= 5;
  }

  // States in which our units should still exist in the world.
  public static func HasUnits(s: Int32) -> Bool {
    return s >= 2 && s <= 7;
  }

  // The state a given deployed tier corresponds to.
  public static func ForTier(tier: Int32) -> Int32 {
    if tier <= 0 { return 1; };
    if tier == 1 { return 2; };
    if tier == 2 { return 3; };
    if tier == 3 { return 4; };
    return 5;
  }
}

// ---------------------------------------------------------------------------
// One combatant's contribution, tracked so the cyberpsychosis gate has
// something observable to gate on. A single combatant with a disproportionate
// kill count is the closest proxy available to chrome load without an API
// this build could verify - see docs/BLOCKERS.md.
// ---------------------------------------------------------------------------
public class NCDCombatant extends IScriptable {
  public let id: EntityID;
  public let kills: Int32;
  public let isOurs: Bool;
}

public class NCDIncident extends IScriptable {

  // --- identity -------------------------------------------------------------
  public let id: Int32;
  public let position: Vector4;
  public let zone: Int32;

  // --- heat -----------------------------------------------------------------
  public let heat: Float;
  public let peakHeat: Float;

  // --- lifecycle ------------------------------------------------------------
  public let state: Int32;
  public let stateEnteredAt: Float;

  // Tier actually deployed, 0-4. Distinct from state: an incident can be
  // SWEEPING with tier 3 units on the ground.
  public let tier: Int32;
  public let tierEnteredAt: Float;

  // --- timing ---------------------------------------------------------------
  public let openedAt: Float;
  public let lastEventAt: Float;

  // When the current unbroken run of violence started. Reset whenever the
  // incident goes quiet and violence later resumes. This, not total age, is
  // what the MaxTac duration gate reads: "ninety seconds of CONTINUOUS
  // violence", not ninety seconds since something first happened.
  public let violenceSince: Float;

  // Wall clock at which the first unit may be created. Set from the district
  // profile's responseDelay when the incident is first reported, and the
  // reason a player gets to watch a situation develop.
  public let respondAt: Float;

  // Earliest wall clock for the next TOP-UP wave - more units at the tier
  // already deployed. Runs on waveStaggerSeconds, because a containment should
  // look like units converging on a scene over twenty seconds.
  public let nextWaveAt: Float;

  // Earliest wall clock for the next ESCALATION - a move to a higher tier.
  // Runs on waveCooldown, which is much longer, so an incident cannot climb
  // the whole ladder in one breath. Kept separate from nextWaveAt because
  // sharing one clock means either escalation is too fast or reinforcement is
  // too slow, and there is no value that is right for both.
  public let nextEscalationAt: Float;

  // --- tallies --------------------------------------------------------------
  public let deaths: Int32;
  public let officerDeaths: Int32;
  public let unitsDeployed: Int32;
  public let perimeterBreaches: Int32;

  // --- ownership (Phase 1.5) ------------------------------------------------
  // True while vanilla prevention is chasing V here. The incident keeps
  // running - it just stops being the thing that spawns.
  public let vanillaOwnsSpawning: Bool;

  // Wall clock after which we take spawn authority back, set when V's stars
  // clear so control returns on a delay rather than instantly.
  public let ownershipReturnsAt: Float;

  // --- participants ---------------------------------------------------------
  public let combatants: array<ref<NCDCombatant>>;

  // =========================================================================

  public func AddCombatant(cid: EntityID) -> Void {
    if EntityID.GetHash(cid) <= 1u {
      return;
    };
    if ArraySize(this.combatants) >= 24 {
      return;
    };
    for c in this.combatants {
      if c.id == cid {
        return;
      };
    };
    let c: ref<NCDCombatant> = new NCDCombatant();
    c.id = cid;
    c.kills = 0;
    c.isOurs = false;
    ArrayPush(this.combatants, c);
  }

  // One of our own responders, registered when it attaches. Tracked in the
  // same list as everyone else but flagged, so the incident can tell its
  // responders apart from the people they were sent to deal with. This is what
  // lets our officers escalate an incident by dying without also feeding it
  // sustained heat merely by fighting - which is a loop with no exit.
  public func AddOwnUnit(cid: EntityID) -> Void {
    if EntityID.GetHash(cid) <= 1u {
      return;
    };
    for c in this.combatants {
      if c.id == cid {
        c.isOurs = true;
        return;
      };
    };
    if ArraySize(this.combatants) >= 24 {
      return;
    };
    let c: ref<NCDCombatant> = new NCDCombatant();
    c.id = cid;
    c.kills = 0;
    c.isOurs = true;
    ArrayPush(this.combatants, c);
  }

  public func CreditKill(killer: EntityID) -> Void {
    if EntityID.GetHash(killer) <= 1u {
      return;
    };
    for c in this.combatants {
      if c.id == killer {
        c.kills += 1;
        return;
      };
    };
    // Killer was not yet a known participant - a sniper, or someone whose
    // combat entry we missed. Register them, because a combatant who only
    // ever shows up as a cause of death is exactly the one the cyberpsychosis
    // gate cares about.
    this.AddCombatant(killer);
    for c in this.combatants {
      if c.id == killer {
        c.kills += 1;
        return;
      };
    };
  }

  // Highest kill count held by any single non-police participant. The
  // cyberpsychosis proxy.
  public func TopKillerKills() -> Int32 {
    let best: Int32 = 0;
    for c in this.combatants {
      if !c.isOurs && c.kills > best {
        best = c.kills;
      };
    };
    return best;
  }

  public func CombatantCount() -> Int32 {
    return ArraySize(this.combatants);
  }

  public func SetState(newState: Int32, now: Float) -> Void {
    if this.state == newState {
      return;
    };
    this.state = newState;
    this.stateEnteredAt = now;
  }

  public func SecondsInState(now: Float) -> Float {
    return now - this.stateEnteredAt;
  }

  public func SecondsAtTier(now: Float) -> Float {
    return now - this.tierEnteredAt;
  }

  // Length of the current unbroken run of violence. Zero when quiet.
  public func ViolenceDuration(now: Float) -> Float {
    if this.violenceSince <= 0.0 {
      return 0.0;
    };
    return now - this.violenceSince;
  }

  public func SecondsQuiet(now: Float) -> Float {
    return now - this.lastEventAt;
  }
}
