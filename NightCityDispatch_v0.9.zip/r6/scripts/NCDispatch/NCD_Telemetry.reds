module NCDispatch

// ============================================================================
//  Telemetry
//
//  There is no debugger attached by default and no log the user can reliably
//  read mid-session. FTLog does not surface in the CET console on all setups,
//  and redscript_rCURRENT.log is compile-time only. On-screen output is the
//  only runtime channel that always works, so this is it.
//
//  TWO RULES, both learned expensively.
//
//  1. INSTRUMENT EVERY STAGE BOUNDARY SEPARATELY. Requested, accepted,
//     attached and alive were four distinct numbers on this project and three
//     of them lied at different times. Collapsing any two of them hides a bug.
//
//  2. ANY FEATURE FLAG THAT DISABLES WORK MUST BE VISIBLE. A switched-off
//     subsystem and a broken one produce identical telemetry otherwise. That
//     is not hypothetical here - v0.8 shipped with spawnEnabled false and read
//     as a spawning regression for an entire release.
//
//  Session start dumps every config value to screen, one line at a time,
//  before normal reporting begins. Most of the lost cycles on this project
//  were a config value being wrong rather than logic being wrong.
// ============================================================================

public class NCDProbe extends ScriptableSystem {

  private let m_tickID: DelayID;
  private let m_beats: Int32;

  // Config dump progress. While this is short of the dump length, the probe is
  // printing config rather than telemetry.
  private let m_dumpLine: Int32;
  private let m_dumpDone: Bool;

  // Which of the three rotating telemetry lines to show next.
  private let m_rotation: Int32;

  public static func Get(gi: GameInstance) -> ref<NCDProbe> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDProbe") as NCDProbe;
  }

  protected func OnAttach() -> Void {
    FTLog("[NCDispatch] probe attached");
    this.m_dumpLine = 0;
    this.m_dumpDone = false;
    this.m_rotation = 0;
    this.Schedule(6.0);
  }

  protected func OnDetach() -> Void {
    let ds: ref<DelaySystem> = GameInstance.GetDelaySystem(this.GetGameInstance());
    if IsDefined(ds) {
      ds.CancelCallback(this.m_tickID);
    };
  }

  private func Schedule(t: Float) -> Void {
    let ds: ref<DelaySystem> = GameInstance.GetDelaySystem(this.GetGameInstance());
    if IsDefined(ds) {
      let cb: ref<NCDProbeCallback> = new NCDProbeCallback();
      cb.system = this;
      this.m_tickID = ds.DelayCallback(cb, t);
    };
  }

  private func Screen(text: String) -> Void {
    let gi: GameInstance = this.GetGameInstance();
    let bb: ref<IBlackboard> = GameInstance.GetBlackboardSystem(gi).Get(GetAllBlackboardDefs().UI_Notifications);
    if !IsDefined(bb) {
      return;
    };
    let msg: SimpleScreenMessage;
    msg.isShown = true;
    msg.duration = 4.0;
    msg.message = text;
    bb.SetVariant(GetAllBlackboardDefs().UI_Notifications.OnscreenMessage, ToVariant(msg), true);
  }

  private func Emit(text: String) -> Void {
    this.Screen(text);
    FTLog(text);
  }

  // ==========================================================================

  public func Beat() -> Void {
    let gi: GameInstance = this.GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();

    if GameInstance.GetSystemRequestsHandler().IsPreGame() {
      this.Schedule(5.0);
      return;
    };
    if !IsDefined(cfg) {
      this.Emit("NCD FATAL: config system did not resolve");
      this.Schedule(5.0);
      return;
    };
    if !cfg.probeON {
      this.Schedule(10.0);
      return;
    };

    this.m_beats += 1;

    // --- session-start config dump ------------------------------------------
    if !this.m_dumpDone {
      let dump: array<String> = cfg.SelfCheck();
      if this.m_dumpLine < ArraySize(dump) {
        this.Emit(dump[this.m_dumpLine]);
        this.m_dumpLine += 1;
        this.Schedule(2.5);
        return;
      };
      this.m_dumpDone = true;
      this.Emit("NCD config: end of dump. flags=" + cfg.FlagString() + " (see NCD_Telemetry for the key)");
      this.Schedule(4.0);
      return;
    };

    // --- rotating telemetry --------------------------------------------------
    if this.m_rotation == 0 {
      this.Emit(this.LineSystems(gi, cfg));
    } else {
      if this.m_rotation == 1 {
        this.Emit(this.LinePipeline(gi, cfg));
      } else {
        this.Emit(this.LineIncident(gi, cfg));
      };
    };

    this.m_rotation += 1;
    if this.m_rotation > 2 {
      this.m_rotation = 0;
    };

    this.Schedule(5.0);
  }

  // ==========================================================================
  //  Line 1 - are the systems there, are the flags what you think, is
  //  anything being sensed at all.
  //
  //    NCD 12 [CRSDUOTA] flags=MSDOGWXE sig 32/34/1+0 inc 3
  //
  //  [CRSDUOTA] one letter per system, a dash means that piece is dead:
  //    C config  R registry  S spawner  D dispatcher  U units
  //    O ownership  T doctrine  A entity-attach callback registered
  //  flags: see NCDConfig.FlagString - M mod, S spawn, D districts,
  //    O ownership transfer, G staging, W sweep, X withdraw, E entry conditions
  //  sig: combat entries / alerts / deaths + officer deaths
  // ==========================================================================
  private func LineSystems(gi: GameInstance, cfg: ref<NCDConfig>) -> String {
    let reg: ref<NCDRegistry> = NCDRegistry.Get(gi);
    let sys: String = "";
    if IsDefined(cfg) { sys += "C"; } else { sys += "-"; };
    if IsDefined(reg) { sys += "R"; } else { sys += "-"; };
    if IsDefined(NCDSpawner.Get(gi)) { sys += "S"; } else { sys += "-"; };
    if IsDefined(NCDDispatcher.Get(gi)) { sys += "D"; } else { sys += "-"; };
    if IsDefined(NCDUnits.Get(gi)) { sys += "U"; } else { sys += "-"; };
    if IsDefined(NCDOwnership.Get(gi)) { sys += "O"; } else { sys += "-"; };
    if IsDefined(NCDDoctrine.Get(gi)) { sys += "T"; } else { sys += "-"; };
    if IsDefined(reg) && reg.attachHookLive { sys += "A"; } else { sys += "-"; };

    let line: String = "NCD " + ToString(this.m_beats) + " [" + sys + "]"
      + " flags=" + cfg.FlagString();

    if IsDefined(reg) {
      line += " sig " + ToString(reg.sensedCombat) + "/" + ToString(reg.sensedAlert)
        + "/" + ToString(reg.sensedDeath) + "+" + ToString(reg.sensedOfficerDeath)
        + " inc " + ToString(reg.Count())
        + " (" + ToString(reg.incidentsOpened) + " opened, " + ToString(reg.incidentsClosed) + " closed)";
    };

    if !cfg.spawnEnabled {
      line = "SPAWN-OFF " + line;
    };
    return line;
  }

  // ==========================================================================
  //  Line 2 - the spawn pipeline, one number per stage boundary, plus why
  //  waves did not happen.
  //
  //    NCD pipe wave 4 req 8 acc 8 att 6 det 0 desp 2 live 6(tag0) | blk d0 o1 c0 | navfail 1
  //
  //  req -> acc : CreateEntity returned a valid EntityID. The request was
  //               QUEUED. It does not mean anything exists.
  //  acc -> att : the Entity/Attached callback fired. First number that means
  //               a unit is really in the world. If acc climbs and att stays
  //               flat, check for A in line 1 and try allowSpawnInView.
  //  live       : our own count, pruned against live entities. This is the
  //               real number and it is what gates the spawn cap.
  //  tag        : GetTagged, kept only as a cross-check. It has been observed
  //               reading 0 while units were demonstrably alive. Never trust
  //               it over live.
  //  blk        : ticks on which a response was withheld - d district ceiling,
  //               o vanilla owns spawning, c unit cap, e heat was high enough
  //               but the entry conditions were not met. A correctly
  //               suppressed response and a silently broken one look identical
  //               without these. `e` climbing steadily is the mod working:
  //               most violence is supposed to produce nothing.
  //  navfail    : spawn points the navmesh would not give us.
  // ==========================================================================
  private func LinePipeline(gi: GameInstance, cfg: ref<NCDConfig>) -> String {
    let reg: ref<NCDRegistry> = NCDRegistry.Get(gi);
    let spw: ref<NCDSpawner> = NCDSpawner.Get(gi);
    if !IsDefined(reg) || !IsDefined(spw) {
      return "NCD pipe: registry or spawner missing";
    };

    let line: String = "NCD pipe wave " + ToString(reg.wavesRequested)
      + " req " + ToString(reg.unitsRequested)
      + " acc " + ToString(reg.unitsAccepted)
      + " att " + ToString(reg.unitsAttached)
      + " det " + ToString(reg.unitsDetached)
      + " desp " + ToString(reg.unitsDespawned)
      + " live " + ToString(spw.LiveUnitCount()) + "(tag" + ToString(spw.TaggedCount()) + ")"
      + " | blk d" + ToString(reg.blockedByDistrict)
      + " o" + ToString(reg.blockedByOwnership)
      + " c" + ToString(reg.blockedByCap)
      + " e" + ToString(reg.blockedByEntryCond)
      + " | navfail " + ToString(reg.spawnPointFailures);

    if !cfg.spawnEnabled {
      line = "SPAWN-OFF " + line;
    };
    return line;
  }

  // ==========================================================================
  //  Line 3 - the hottest incident, or the calibration readout.
  //
  //    NCD#3 CONT t2/4 zone=City Center heat 41.2/55.0 viol 34s off 1 brch 0
  //          top 2 own=us why=t3: contained
  //
  //  In calibrationMode this line is replaced by V's world position and
  //  resolved zone, which is what you fill the geometry table in NCD_Doctrine
  //  with. See docs/CALIBRATION.md.
  // ==========================================================================
  private func LineIncident(gi: GameInstance, cfg: ref<NCDConfig>) -> String {
    let doctrine: ref<NCDDoctrine> = NCDDoctrine.Get(gi);

    if cfg.calibrationMode {
      let player: ref<PlayerPuppet> = GetPlayer(gi);
      if !IsDefined(player) {
        return "NCD calib: no player";
      };
      let p: Vector4 = player.GetWorldPosition();
      let zoneName: String = "?";
      let zoneCount: Int32 = 0;
      if IsDefined(doctrine) {
        zoneCount = doctrine.ZoneCount();
        let prof: ref<NCDZoneProfile> = doctrine.ProfileAt(p);
        if IsDefined(prof) {
          zoneName = prof.name;
        };
      };
      return "NCD calib pos " + FloatToStringPrec(p.X, 1) + " " + FloatToStringPrec(p.Y, 1)
        + " " + FloatToStringPrec(p.Z, 1)
        + " -> " + zoneName + " (" + ToString(zoneCount) + " zones defined)";
    };

    let reg: ref<NCDRegistry> = NCDRegistry.Get(gi);
    if !IsDefined(reg) {
      return "NCD inc: registry missing";
    };
    let inc: ref<NCDIncident> = reg.Hottest();
    if !IsDefined(inc) {
      return "NCD inc: none active. peak heat this session "
        + FloatToStringPrec(reg.peakHeat, 1)
        + " (tier 1 needs " + FloatToStringPrec(cfg.tier1Heat, 1) + ")";
    };

    let now: Float = EngineTime.ToFloat(GameInstance.GetSimTime(gi));

    let zoneName: String = "unlisted";
    if IsDefined(doctrine) {
      let prof: ref<NCDZoneProfile> = doctrine.ProfileFor(inc.zone);
      if IsDefined(prof) {
        zoneName = prof.name + " ceil" + ToString(prof.ceiling);
      };
    };

    let owner: String = "us";
    if inc.vanillaOwnsSpawning {
      owner = "vanilla";
    };

    let line: String = "NCD#" + ToString(inc.id) + " " + NCDState.Name(inc.state)
      + " t" + ToString(inc.tier)
      + " zone=" + zoneName
      + " heat " + FloatToStringPrec(inc.heat, 1) + "/" + FloatToStringPrec(inc.peakHeat, 1)
      + " viol " + FloatToStringPrec(inc.ViolenceDuration(now), 0) + "s"
      + " ppl " + ToString(inc.CombatantCount())
      + " off " + ToString(inc.officerDeaths)
      + " brch " + ToString(inc.perimeterBreaches)
      + " top " + ToString(inc.TopKillerKills())
      + " own=" + owner;

    let dsp: ref<NCDDispatcher> = NCDDispatcher.Get(gi);
    if IsDefined(dsp) {
      line += " why=" + dsp.LastReason();
    };
    return line;
  }
}

public class NCDProbeCallback extends DelayCallback {
  public let system: wref<NCDProbe>;
  public func Call() -> Void {
    if IsDefined(this.system) {
      this.system.Beat();
    };
  }
}
