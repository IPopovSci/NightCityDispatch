module NCDispatch

// ============================================================================
//  Escalation ladder
//
//  "Each tier has entry conditions, not just a threshold."
//
//  Heat is a NECESSARY condition at every rung and a SUFFICIENT one at none.
//  That distinction is the whole difference between this file and v0.8a, where
//  three float comparisons decided everything and MaxTac was reachable by
//  standing still long enough next to a big enough fight.
//
//  Explicitly NOT qualifying for MaxTac, per the design:
//    - raw combatant count alone
//    - raw heat alone
//    - any single burst of violence, however intense, that resolves quickly
//
//  Pure logic, no state, no system registration. Everything it reads is on the
//  incident or in config, which makes it the one part of the mod you can
//  reason about without launching the game.
// ============================================================================

public class NCDEscalation {

  // ==========================================================================
  //  The one entry point. Returns the tier this incident has EARNED, 0-4,
  //  before the district ceiling is applied. `reason` is for telemetry: a
  //  suppressed tier and a tier that was never earned look identical without
  //  it.
  // ==========================================================================
  public static func DesiredTier(cfg: ref<NCDConfig>, profile: ref<NCDZoneProfile>,
                                 inc: ref<NCDIncident>, now: Float,
                                 out reason: String) -> Int32 {
    reason = "";
    if !IsDefined(cfg) || !IsDefined(inc) {
      return 0;
    };

    // District severity scaling. Below 1.0 the district reacts to less;
    // Northside barely reacts at all.
    let mult: Float = 1.0;
    if IsDefined(profile) {
      mult = profile.thresholdMult;
    };
    if mult <= 0.0 {
      mult = 1.0;
    };

    // Heat-only mode. Kept because forcing a high tier on demand is the only
    // practical way to test tier 3 and 4 behaviour without staging a
    // ninety-second gun battle, but it is not how the mod is meant to run.
    if !cfg.entryConditionsEnabled {
      reason = "heat-only";
      if inc.heat >= cfg.tier4Heat * mult { return 4; };
      if inc.heat >= cfg.tier3Heat * mult { return 3; };
      if inc.heat >= cfg.tier2Heat * mult { return 2; };
      if inc.heat >= cfg.tier1Heat * mult { return 1; };
      return 0;
    };

    // Each rung is asked in descending order and the first one that qualifies
    // wins. `r` is a plain local rather than `reason` forwarded straight
    // through, because forwarding an out parameter into another out parameter
    // slot is not something this build could verify.
    let r: String;

    if NCDEscalation.QualifiesForMaxTac(cfg, profile, inc, now, mult, r) {
      reason = r;
      return 4;
    };
    reason = r;

    if NCDEscalation.QualifiesForTactical(cfg, inc, now, mult, r) {
      reason = r;
      return 3;
    };

    if NCDEscalation.QualifiesForContainment(cfg, inc, now, mult, r) {
      reason = r;
      return 2;
    };

    if NCDEscalation.QualifiesForPatrol(cfg, inc, now, mult, r) {
      reason = r;
      return 1;
    };
    reason = r;
    return 0;
  }

  // ==========================================================================
  //  Tier 1 - Patrol response
  //
  //  "sustained violence, ~10-20 s, above minimum severity"
  //
  //  This is also where melee brawls and single punches get filtered out. The
  //  hooks cannot see weapon class, so the exclusion is expressed as duration
  //  plus a participant floor: a two-person scuffle that ends in ten seconds
  //  never clears both. The city is rough. Police do not come for rough.
  // ==========================================================================
  public static func QualifiesForPatrol(cfg: ref<NCDConfig>, inc: ref<NCDIncident>,
                                         now: Float, mult: Float, out reason: String) -> Bool {
    if inc.heat < cfg.tier1Heat * mult {
      reason = "t1: heat";
      return false;
    };
    if inc.ViolenceDuration(now) < cfg.tier1MinViolenceSeconds {
      reason = "t1: duration";
      return false;
    };
    if inc.deaths < cfg.tier1MinDeaths {
      reason = "t1: severity";
      return false;
    };
    if inc.CombatantCount() < cfg.tier1MinCombatants {
      reason = "t1: participants";
      return false;
    };
    reason = "t1: sustained violence";
    return true;
  }

  // ==========================================================================
  //  Tier 2 - Containment
  //
  //  "incident still active after first response, or first response takes
  //   casualties"
  //
  //  This is the tier most incidents should end at: the gangs kill each other,
  //  police watch the exits, then move in when it is quiet.
  // ==========================================================================
  public static func QualifiesForContainment(cfg: ref<NCDConfig>, inc: ref<NCDIncident>,
                                              now: Float, mult: Float, out reason: String) -> Bool {
    // Containment is a response to a response. Nobody escalates to it from
    // nothing - patrol has to have been on the ground first.
    if inc.tier < 1 {
      reason = "t2: no patrol yet";
      return false;
    };
    if inc.heat < cfg.tier2Heat * mult {
      reason = "t2: heat";
      return false;
    };

    // First response took casualties - that alone qualifies, immediately.
    if inc.officerDeaths >= 1 {
      reason = "t2: officer down";
      return true;
    };

    // Or the incident is simply still going.
    if inc.SecondsAtTier(now) >= cfg.tier2MinSecondsAtTier1 {
      reason = "t2: still active";
      return true;
    };

    reason = "t2: too soon";
    return false;
  }

  // ==========================================================================
  //  Tier 3 - Tactical
  //
  //  "containment failing - combatants breaking the perimeter, officer
  //   casualties mounting, heavy weapons, or a hostage/civilian situation"
  //
  //  Heavy weapons and hostages are not readable from the sensor hooks
  //  available here (docs/BLOCKERS.md); perimeter breaches and officer
  //  casualties are, and they carry the tier on their own.
  // ==========================================================================
  public static func QualifiesForTactical(cfg: ref<NCDConfig>, inc: ref<NCDIncident>,
                                           now: Float, mult: Float, out reason: String) -> Bool {
    if inc.tier < 2 {
      reason = "t3: no containment yet";
      return false;
    };
    if inc.heat < cfg.tier3Heat * mult {
      reason = "t3: heat";
      return false;
    };

    // Combatants fighting outside the cordon. The perimeter is not holding.
    if inc.perimeterBreaches >= cfg.tier3PerimeterBreaches {
      reason = "t3: perimeter broken";
      return true;
    };

    // Casualties mounting.
    if inc.officerDeaths >= cfg.tier3MinOfficerDeaths
       && inc.SecondsAtTier(now) >= cfg.tier3MinSecondsAtTier2 {
      reason = "t3: casualties";
      return true;
    };

    // Containment has simply failed to contain.
    if inc.SecondsAtTier(now) >= cfg.tier3MinSecondsAtTier2 * 2.0 {
      reason = "t3: containment failing";
      return true;
    };

    reason = "t3: contained";
    return false;
  }

  // ==========================================================================
  //  Tier 4 - MaxTac
  //
  //  A psycho squad, not a SWAT escalation. Deliberately hard to reach. ANY
  //  ONE of the four conditions below qualifies; nothing else does.
  // ==========================================================================
  public static func QualifiesForMaxTac(cfg: ref<NCDConfig>, profile: ref<NCDZoneProfile>,
                                         inc: ref<NCDIncident>, now: Float, mult: Float,
                                         out reason: String) -> Bool {

    // 1. Cyberpsychosis indicators - the canonical trigger, and the only one
    //    that bypasses the heat floor entirely. A single combatant with a
    //    disproportionate kill count is what this build can observe; chrome
    //    load and sandevistan signatures need an API that could not be
    //    verified here. See docs/BLOCKERS.md.
    if inc.TopKillerKills() >= cfg.maxTacSingleKillerKills {
      reason = "t4: cyberpsycho indicators";
      return true;
    };

    // 2. Officer casualties. Losing this many badges changes the department's
    //    posture entirely, and it is a hard count rather than a rate.
    if inc.officerDeaths >= cfg.maxTacOfficerDeaths {
      reason = "t4: officers down";
      return true;
    };

    // Everything below here needs the heat floor as well.
    if inc.heat < cfg.tier4Heat * mult {
      reason = "t4: heat";
      return false;
    };

    // 3. Prolonged uncontained incident. Tier 3 active and still not resolving
    //    after ninety seconds of CONTINUOUS violence - a fight that stops and
    //    restarts does not accumulate credit toward this.
    if inc.tier >= 3 && inc.ViolenceDuration(now) >= cfg.maxTacUncontainedSeconds {
      reason = "t4: uncontained";
      return true;
    };

    // 4. District override. Corporate pressure produces disproportionate
    //    force. MaxTac for something that would get one cruiser in Santo
    //    Domingo is correct, and it says something about the city.
    if cfg.maxTacDistrictOverrideEnabled && IsDefined(profile) && profile.maxTacOverride {
      if inc.tier >= 2 && inc.ViolenceDuration(now) >= 30.0 {
        reason = "t4: corporate pressure";
        return true;
      };
    };

    reason = "t4: not qualified";
    return false;
  }

  // ==========================================================================
  //  District ceiling. Applied after the tier is earned, never before - the
  //  distinction matters for telemetry, because "Northside earned tactical and
  //  was capped at patrol" is a different world from "Northside never got
  //  past patrol", and only the first one means the tuning is working.
  // ==========================================================================
  public static func ApplyCeiling(profile: ref<NCDZoneProfile>, desired: Int32) -> Int32 {
    if !IsDefined(profile) {
      return desired;
    };
    if desired > profile.ceiling {
      return profile.ceiling;
    };
    return desired;
  }

  // Wave size for a tier, scaled by how heavily the district turns out.
  // Vista del Rey shows up late and in numbers; Watson shows up thin.
  public static func WaveSize(cfg: ref<NCDConfig>, profile: ref<NCDZoneProfile>, tier: Int32) -> Int32 {
    let base: Int32 = cfg.tier1Count;
    if tier == 2 { base = cfg.tier2Count; };
    if tier == 3 { base = cfg.tier3Count; };
    if tier >= 4 { base = cfg.tier4Count; };

    if !IsDefined(profile) {
      return base;
    };
    if profile.forceMult <= 0.0 {
      return 0;
    };

    // Round to nearest by counting up. Cast<Int32> from a Float is not on the
    // verified-API list for this build, and a wave size is small enough that
    // counting is free. The 32 is a guard, not a limit anyone should reach.
    let target: Float = Cast<Float>(base) * profile.forceMult;
    let n: Int32 = 0;
    while n < 32 && Cast<Float>(n + 1) <= target + 0.5 {
      n += 1;
    };
    if n < 1 {
      n = 1;
    };
    return n;
  }
}
