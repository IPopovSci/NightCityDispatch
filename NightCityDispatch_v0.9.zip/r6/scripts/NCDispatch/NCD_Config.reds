module NCDispatch

// ============================================================================
//  Night City Dispatch - configuration
//
//  Every tunable in the mod lives in this file. Nothing else declares a magic
//  number. Edit, relaunch (redscript recompiles on launch), done.
//
//  THIS FILE IS OVERWRITTEN ON EVERY INSTALL. If you change a default here,
//  say so in CHANGELOG.md. A silently changed default cost this project a
//  whole release cycle once already (v0.8a, spawnEnabled).
//
//  Every field below is dumped to screen and log once at session start by
//  NCD_Telemetry. That is deliberate and load-bearing: a switched-off
//  subsystem and a broken one produce identical telemetry otherwise.
// ============================================================================

public class NCDConfig extends ScriptableSystem {

  public static func Get() -> ref<NCDConfig> {
    return GameInstance.GetScriptableSystemsContainer(GetGameInstance()).Get(n"NCDispatch.NCDConfig") as NCDConfig;
  }

  // ==========================================================================
  //  MASTER SWITCHES
  // ==========================================================================

  // Kills everything. Sensors return immediately, heartbeat idles.
  public let modON: Bool = true;

  // Bisect switch. Sensing and escalation run normally, nothing is ever
  // created. Use this to prove a crash is or is not CreateEntity.
  public let spawnEnabled: Bool = true;

  // FTLog output. Compile-time log only - see docs, FTLog does not reliably
  // reach the CET console. The probe is the runtime channel.
  public let debugON: Bool = true;

  // On-screen telemetry probe.
  public let probeON: Bool = true;

  // Prints V's world position and resolved zone on every probe beat. This is
  // how you fill in the zone table in NCD_Doctrine - see docs/CALIBRATION.md.
  public let calibrationMode: Bool = false;

  // ==========================================================================
  //  FEATURE FLAGS
  //
  //  Each of these disables a whole behaviour. All of them are printed in the
  //  probe's flag string so a disabled feature never masquerades as a bug.
  // ==========================================================================

  // District response doctrine: per-zone delay, ceiling and severity floor.
  // With this off every incident uses the default profile everywhere.
  public let districtsEnabled: Bool = true;

  // Phase 1.5. When V acquires a wanted level at a live incident, hand spawn
  // authority to vanilla and flip our units hostile, but KEEP the incident.
  // With this off the incident is abandoned when V gets stars, which is the
  // single loudest anti-goal in the design document.
  public let ownershipTransferEnabled: Bool = true;

  // Units stage at distance from the incident and hold, rather than running
  // into the middle of it. With this off they close to contact immediately.
  public let stagingEnabled: Bool = true;

  // After violence stops, units move in and sweep instead of standing still.
  public let sweepEnabled: Bool = true;

  // After the sweep, units walk back out and are removed at range rather than
  // popping out of existence where you can see them.
  public let withdrawEnabled: Bool = true;

  // Escalation requires the design's entry conditions, not just a heat number.
  // With this off, tiers gate on heat alone (v0.8a behaviour) - useful for
  // forcing high tiers while testing, wrong for play.
  public let entryConditionsEnabled: Bool = true;

  // ==========================================================================
  //  INCIDENT TRACKING
  // ==========================================================================

  // Two violent events within this many metres are one incident.
  public let mergeRadius: Float = 30.0;

  // Hard cap on simultaneously tracked incidents. Keeps the tick cheap.
  public let maxIncidents: Int32 = 4;

  // Incidents further than this from V are dropped. This is the "near the
  // player only" boundary - beyond it NPCs are not streamed and there is
  // nothing to police. Off-screen simulation is explicitly out of scope.
  public let maxRangeFromPlayer: Float = 130.0;

  // An incident with heat below this is forgotten.
  public let closeBelowHeat: Float = 0.5;

  // Seconds with no violent event before an incident counts as quiet. Quiet
  // is what moves a live incident to SWEEPING.
  public let quietAfter: Float = 12.0;

  // ==========================================================================
  //  HEAT WEIGHTS
  // ==========================================================================

  // An NPC entering Combat. The primary signal - the game telling us a fight
  // started, rather than us inferring it from noise.
  public let heatCombatEntry: Float = 2.5;

  // An NPC entering Alerted. Bystander fear. Volume matters, not individuals.
  public let heatAlerted: Float = 0.7;

  // An NPC dying.
  public let heatDeath: Float = 3.0;

  // One of OUR officers dying. The single strongest escalator, and the
  // deliberate exception to the self-exclusion rule below.
  public let heatOfficerDeath: Float = 8.0;

  // Per second, per combatant still alive and fighting. This is what makes a
  // prolonged firefight escalate instead of decaying out, and it is the core
  // of the MaxTac duration gate.
  public let heatSustainPerCombatant: Float = 0.35;

  // Multiplier when the killer is not V. Gang-on-gang violence is the reason
  // this mod exists; V's own gunfire is already vanilla prevention's problem.
  public let thirdPartyMult: Float = 1.35;

  // Bled off per second. Higher = incidents resolve faster.
  public let heatDecayPerSec: Float = 0.5;

  // Ceiling. Without this a long fight saturates far past the top tier and
  // re-triggers waves every cooldown forever.
  public let maxIncidentHeat: Float = 55.0;

  // ==========================================================================
  //  ESCALATION LADDER
  //
  //  Heat thresholds are a NECESSARY condition for each tier, never a
  //  sufficient one (unless entryConditionsEnabled is false). The design is
  //  explicit that MaxTac in particular must not be reachable on raw heat.
  // ==========================================================================

  public let tier1Heat: Float = 6.0;    // patrol
  public let tier2Heat: Float = 16.0;   // containment
  public let tier3Heat: Float = 30.0;   // tactical
  public let tier4Heat: Float = 40.0;   // MaxTac - necessary, never sufficient

  public let tier1Count: Int32 = 2;
  public let tier2Count: Int32 = 4;
  public let tier3Count: Int32 = 4;
  public let tier4Count: Int32 = 5;

  // --- tier 1: patrol -------------------------------------------------------
  // "sustained violence, ~10-20 s, above minimum severity"

  // Violence must have been running this long before anyone is dispatched.
  public let tier1MinViolenceSeconds: Float = 12.0;

  // Minimum severity. A single punch-up does not summon police; the city is
  // rough and police do not come for rough. Either a body, or several people
  // committing to a fight.
  public let tier1MinDeaths: Int32 = 0;
  public let tier1MinCombatants: Int32 = 2;

  // --- tier 2: containment --------------------------------------------------
  // "incident still active after first response, or first response takes
  //  casualties"

  public let tier2MinSecondsAtTier1: Float = 15.0;

  // Containment arrives spread over this long rather than all at once.
  public let waveStaggerSeconds: Float = 5.0;

  // How many units a single burst may create. A tier's full complement is
  // reached over several bursts spaced by waveStaggerSeconds, which is what
  // makes a response look like units converging on a scene rather than a
  // squad materialising in it.
  public let waveBurstSize: Int32 = 2;

  // --- tier 3: tactical -----------------------------------------------------
  // "containment failing - combatants breaking the perimeter, officer
  //  casualties mounting"

  public let tier3MinSecondsAtTier2: Float = 20.0;
  public let tier3MinOfficerDeaths: Int32 = 1;

  // Combatants this far outside the incident centre have broken the
  // perimeter, which also qualifies.
  public let perimeterRadius: Float = 35.0;
  public let tier3PerimeterBreaches: Int32 = 2;

  // --- tier 4: MaxTac -------------------------------------------------------
  // Deliberately hard to reach. ANY ONE of these qualifies.

  // Officer casualties. Losing this many badges changes the department's
  // posture entirely.
  public let maxTacOfficerDeaths: Int32 = 3;

  // Tier 3 active and still not resolving after this long of continuous
  // violence.
  public let maxTacUncontainedSeconds: Float = 90.0;

  // Cyberpsychosis proxy: one combatant with a disproportionate kill count.
  // The canonical trigger in the fiction is chrome load, which needs an API
  // this build could not verify (see docs/BLOCKERS.md) - kill count is the
  // observable stand-in and is genuinely close in practice.
  public let maxTacSingleKillerKills: Int32 = 5;

  // City Center corporate pressure produces disproportionate force. Set per
  // zone in NCD_Doctrine; this is the master switch for the behaviour.
  public let maxTacDistrictOverrideEnabled: Bool = true;

  // ==========================================================================
  //  DISPATCH
  // ==========================================================================

  // Minimum seconds between waves on the same incident.
  public let waveCooldown: Float = 22.0;

  // Global cap on units this mod has alive at once, across all incidents.
  public let maxLiveUnits: Int32 = 12;

  // Per-incident cap. Stops one firefight eating the entire global budget.
  public let maxUnitsPerIncident: Int32 = 8;

  // Heartbeat period.
  public let tickInterval: Float = 1.5;

  // ==========================================================================
  //  ARRIVAL AND STAGING
  //
  //  The failure mode that breaks immersion hardest is police materialising
  //  out of nothing at a jog. Everything here exists to avoid that.
  // ==========================================================================

  // Units are created this far from the incident, on navmesh, facing it.
  // Note this is measured from the INCIDENT, not from V - v0.8a measured from
  // V, which put officers behind the player rather than up the road.
  public let spawnDistanceFromIncident: Float = 60.0;

  // Never create a unit closer than this to V, whatever the navmesh says.
  public let minSpawnDistanceFromPlayer: Float = 35.0;

  // false = the engine QUEUES the spawn until the point leaves view, which
  // can be forever, and CreateEntity still returns a valid EntityID. That is
  // elegant when it works and invisible when it does not. See CLAUDE.md.
  public let allowSpawnInView: Bool = true;

  // Where a staging unit stops: this far from the incident centre. They hold
  // here, they do not push in. Most incidents should end at this distance.
  public let stagingDistance: Float = 22.0;

  // Where an assaulting unit stops. Tier 3+ actually go in.
  public let assaultDistance: Float = 8.0;

  // Where a sweeping unit stops once the shooting is over.
  public let sweepDistance: Float = 5.0;

  // Random spread added to each unit's stopping distance so a squad does not
  // form a perfect circle.
  public let arrivalSpread: Float = 8.0;

  // ==========================================================================
  //  RESOLUTION AND CLEANUP
  // ==========================================================================

  // How long a unit that has been requested but has not attached yet still
  // counts against the caps.
  //
  // This is load-bearing and it is subtle. CreateEntity returning a valid ID
  // means the request was QUEUED - with spawnInView false it can sit queued
  // indefinitely. A queued entity is not findable, so pruning the tracking
  // list purely on "can I find this entity" would drop the record, free the
  // cap slot, spawn a replacement, and then delete the original as an
  // unrecognised stray when it finally attached. That is an unbounded spawn
  // loop with a plausible-looking telemetry line.
  public let spawnGraceSeconds: Float = 30.0;

  // How often the per-unit despawn check runs.
  public let ttlInterval: Float = 12.0;

  // Units beyond this distance from V are removed regardless of state.
  public let despawnDistance: Float = 165.0;

  // A dead unit beyond this distance from V is removed. Bodies remain in the
  // world while you can see them - the world keeps the evidence.
  public let corpseDespawnDistance: Float = 60.0;

  // Seconds spent sweeping before the perimeter releases.
  public let sweepSeconds: Float = 20.0;

  // Seconds spent withdrawing before units are removed.
  public let withdrawSeconds: Float = 25.0;

  // ==========================================================================
  //  THE PLAYER
  // ==========================================================================

  // Force spawned officers friendly toward V. This is the whole point: they
  // are here for the gang fight, not for you.
  public let forceFriendlyToPlayer: Bool = true;

  // If V already has stars when a unit spawns, skip the friendly override and
  // let vanilla own attitude. Without this the mod launders your wanted level.
  public let respectPlayerHeat: Bool = true;

  // Seconds after V's stars clear before the friendly override is restored
  // and spawn authority comes back. "The fight was never ours to end."
  public let ownershipReturnDelay: Float = 8.0;

  // LAST RESORT. Deletes every unit the moment V is wanted, and abandons the
  // incident with them. This was v0.8a's circuit breaker and it is the
  // behaviour ownership transfer exists to replace, so it defaults OFF now.
  // Turn it on only if a wanted level becomes unshakeable again.
  public let despawnOnPlayerWanted: Bool = false;

  // Suppress dispatch entirely while vanilla prevention is chasing V.
  // Default OFF: police turning up to a firefight you are in is correct, and
  // leaving this on makes the mod nearly untestable, since picking a fight
  // with police is the easiest way to generate violence.
  public let suppressDuringChase: Bool = false;

  // ==========================================================================
  //  CONFIG SELF-CHECK
  //
  //  Printed once at session start. Most of the lost cycles on this project
  //  were a config value being wrong rather than logic being wrong, and a
  //  disabled subsystem is indistinguishable from a broken one without this.
  //
  //  tools/ncd_check.py asserts that every `public let` above appears here.
  //  If you add a tunable and forget to dump it, the build gate fails.
  // ==========================================================================

  public func FlagString() -> String {
    let s: String = "";
    if this.modON { s += "M"; } else { s += "-"; };
    if this.spawnEnabled { s += "S"; } else { s += "-"; };
    if this.districtsEnabled { s += "D"; } else { s += "-"; };
    if this.ownershipTransferEnabled { s += "O"; } else { s += "-"; };
    if this.stagingEnabled { s += "G"; } else { s += "-"; };
    if this.sweepEnabled { s += "W"; } else { s += "-"; };
    if this.withdrawEnabled { s += "X"; } else { s += "-"; };
    if this.entryConditionsEnabled { s += "E"; } else { s += "-"; };
    return s;
  }

  public func SelfCheck() -> array<String> {
    let out: array<String>;

    ArrayPush(out, "NCD config: master modON=" + ToString(this.modON)
      + " spawnEnabled=" + ToString(this.spawnEnabled)
      + " debugON=" + ToString(this.debugON)
      + " probeON=" + ToString(this.probeON)
      + " calibrationMode=" + ToString(this.calibrationMode));

    ArrayPush(out, "NCD config: flags districtsEnabled=" + ToString(this.districtsEnabled)
      + " ownershipTransferEnabled=" + ToString(this.ownershipTransferEnabled)
      + " stagingEnabled=" + ToString(this.stagingEnabled)
      + " sweepEnabled=" + ToString(this.sweepEnabled)
      + " withdrawEnabled=" + ToString(this.withdrawEnabled)
      + " entryConditionsEnabled=" + ToString(this.entryConditionsEnabled));

    ArrayPush(out, "NCD config: incident mergeRadius=" + FloatToStringPrec(this.mergeRadius, 1)
      + " maxIncidents=" + ToString(this.maxIncidents)
      + " maxRangeFromPlayer=" + FloatToStringPrec(this.maxRangeFromPlayer, 1)
      + " closeBelowHeat=" + FloatToStringPrec(this.closeBelowHeat, 2)
      + " quietAfter=" + FloatToStringPrec(this.quietAfter, 1));

    ArrayPush(out, "NCD config: heat combat=" + FloatToStringPrec(this.heatCombatEntry, 2)
      + " alerted=" + FloatToStringPrec(this.heatAlerted, 2)
      + " death=" + FloatToStringPrec(this.heatDeath, 2)
      + " officerDeath=" + FloatToStringPrec(this.heatOfficerDeath, 2)
      + " sustain=" + FloatToStringPrec(this.heatSustainPerCombatant, 2)
      + " thirdPartyMult=" + FloatToStringPrec(this.thirdPartyMult, 2)
      + " decay=" + FloatToStringPrec(this.heatDecayPerSec, 2)
      + " max=" + FloatToStringPrec(this.maxIncidentHeat, 1));

    ArrayPush(out, "NCD config: tiers t1=" + FloatToStringPrec(this.tier1Heat, 1)
      + " t2=" + FloatToStringPrec(this.tier2Heat, 1)
      + " t3=" + FloatToStringPrec(this.tier3Heat, 1)
      + " t4=" + FloatToStringPrec(this.tier4Heat, 1)
      + " counts=" + ToString(this.tier1Count) + "/" + ToString(this.tier2Count)
      + "/" + ToString(this.tier3Count) + "/" + ToString(this.tier4Count));

    ArrayPush(out, "NCD config: entry t1MinViolence=" + FloatToStringPrec(this.tier1MinViolenceSeconds, 1)
      + " t1MinDeaths=" + ToString(this.tier1MinDeaths)
      + " t1MinCombatants=" + ToString(this.tier1MinCombatants)
      + " t2MinAtT1=" + FloatToStringPrec(this.tier2MinSecondsAtTier1, 1)
      + " waveStagger=" + FloatToStringPrec(this.waveStaggerSeconds, 1)
      + " waveBurstSize=" + ToString(this.waveBurstSize)
      + " t3MinAtT2=" + FloatToStringPrec(this.tier3MinSecondsAtTier2, 1)
      + " t3MinOfficerDeaths=" + ToString(this.tier3MinOfficerDeaths)
      + " perimeterRadius=" + FloatToStringPrec(this.perimeterRadius, 1)
      + " t3Breaches=" + ToString(this.tier3PerimeterBreaches));

    ArrayPush(out, "NCD config: maxtac officerDeaths=" + ToString(this.maxTacOfficerDeaths)
      + " uncontainedSeconds=" + FloatToStringPrec(this.maxTacUncontainedSeconds, 1)
      + " singleKillerKills=" + ToString(this.maxTacSingleKillerKills)
      + " districtOverride=" + ToString(this.maxTacDistrictOverrideEnabled));

    ArrayPush(out, "NCD config: dispatch waveCooldown=" + FloatToStringPrec(this.waveCooldown, 1)
      + " maxLiveUnits=" + ToString(this.maxLiveUnits)
      + " maxUnitsPerIncident=" + ToString(this.maxUnitsPerIncident)
      + " tickInterval=" + FloatToStringPrec(this.tickInterval, 2));

    ArrayPush(out, "NCD config: arrival spawnDist=" + FloatToStringPrec(this.spawnDistanceFromIncident, 1)
      + " minFromPlayer=" + FloatToStringPrec(this.minSpawnDistanceFromPlayer, 1)
      + " allowSpawnInView=" + ToString(this.allowSpawnInView)
      + " staging=" + FloatToStringPrec(this.stagingDistance, 1)
      + " assault=" + FloatToStringPrec(this.assaultDistance, 1)
      + " sweep=" + FloatToStringPrec(this.sweepDistance, 1)
      + " spread=" + FloatToStringPrec(this.arrivalSpread, 1));

    ArrayPush(out, "NCD config: cleanup spawnGrace=" + FloatToStringPrec(this.spawnGraceSeconds, 1)
      + " ttlInterval=" + FloatToStringPrec(this.ttlInterval, 1)
      + " despawnDistance=" + FloatToStringPrec(this.despawnDistance, 1)
      + " corpseDespawnDistance=" + FloatToStringPrec(this.corpseDespawnDistance, 1)
      + " sweepSeconds=" + FloatToStringPrec(this.sweepSeconds, 1)
      + " withdrawSeconds=" + FloatToStringPrec(this.withdrawSeconds, 1));

    ArrayPush(out, "NCD config: player forceFriendlyToPlayer=" + ToString(this.forceFriendlyToPlayer)
      + " respectPlayerHeat=" + ToString(this.respectPlayerHeat)
      + " ownershipReturnDelay=" + FloatToStringPrec(this.ownershipReturnDelay, 1)
      + " despawnOnPlayerWanted=" + ToString(this.despawnOnPlayerWanted)
      + " suppressDuringChase=" + ToString(this.suppressDuringChase));

    return out;
  }
}

// ---------------------------------------------------------------------------
// Compile-time log sink. Note this reaches redscript_rCURRENT.log, which is
// compile-time only on most setups - it is NOT a runtime channel. Runtime
// telemetry goes on screen via NCD_Telemetry. LogChannel does not exist.
// ---------------------------------------------------------------------------
public static func NCDLog(msg: String) -> Void {
  let cfg: ref<NCDConfig> = NCDConfig.Get();
  if IsDefined(cfg) && cfg.debugON {
    FTLog("[NCDispatch] " + msg);
  };
}
