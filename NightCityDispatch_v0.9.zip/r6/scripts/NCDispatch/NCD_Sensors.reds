import NCDispatch.*

// ============================================================================
//  Sensors
//
//  Two hooks, both known to fire against the current build:
//
//    NPCPuppet.ChangeHighLevelState  - every NPC entering Combat or Alerted
//    ScriptedPuppet.OnDeath          - every NPC death
//
//  Combat entry is a much better signal than stimuli: it is the game telling
//  us a fight started, rather than us inferring it from noise. An earlier
//  version wrapped ReactionManagerComponent.OnDelayStimEvent, which never
//  fired once in a real load order - confirmed by an instrumented counter,
//  not by assumption.
//
//  This file is deliberately in global scope rather than `module NCDispatch`,
//  because @wrapMethod has to see the game's classes unqualified.
//
//  ON MELEE: the design excludes melee brawls and single punches - "the city
//  is rough, police don't come for rough". Weapon class is not readable from
//  either of these hooks, so that exclusion is enforced downstream instead, by
//  the tier 1 entry conditions in NCD_Escalation: sustained duration plus a
//  combatant floor. A two-person scuffle that ends in ten seconds never clears
//  them. See docs/BLOCKERS.md for what a direct check would need.
// ============================================================================

// ---------------------------------------------------------------------------
// Guard against counting our own officers. Without it, responding units enter
// combat, generate heat, and summon reinforcements for themselves forever.
// ---------------------------------------------------------------------------
public static func NCD_IsOurUnit(obj: ref<GameObject>) -> Bool {
  if !IsDefined(obj) {
    return false;
  };
  let es: ref<DynamicEntitySystem> = GameInstance.GetDynamicEntitySystem();
  if !IsDefined(es) {
    return false;
  };
  return ArrayContains(es.GetTags(obj.GetEntityID()), n"NCDispatch");
}

@wrapMethod(NPCPuppet)
public final static func ChangeHighLevelState(obj: ref<GameObject>, newState: gamedataNPCHighLevelState) -> Void {
  wrappedMethod(obj, newState);

  let cfg: ref<NCDConfig> = NCDConfig.Get();
  if !IsDefined(cfg) || !cfg.modON {
    return;
  };
  if !IsDefined(obj) || obj.IsPlayer() {
    return;
  };
  if GameInstance.GetSystemRequestsHandler().IsPreGame() {
    return;
  };
  if NCD_IsOurUnit(obj) {
    return;
  };

  let weight: Float = 0.0;
  let isCombat: Bool = false;
  if Equals(newState, gamedataNPCHighLevelState.Combat) {
    weight = cfg.heatCombatEntry;
    isCombat = true;
  } else {
    if Equals(newState, gamedataNPCHighLevelState.Alerted) {
      weight = cfg.heatAlerted;
    };
  };

  if weight <= 0.0 {
    return;
  };

  let registry: ref<NCDRegistry> = NCDRegistry.Get(GetGameInstance());
  if !IsDefined(registry) {
    return;
  };

  let none: EntityID;
  if isCombat {
    registry.sensedCombat += 1;
    // Anyone entering combat is a legitimate target for responding officers.
    registry.AddHeat(obj.GetWorldPosition(), weight, obj.GetEntityID(), none, false, false, true);
  } else {
    registry.sensedAlert += 1;
    // Alerted bystanders raise heat but are never marked as targets. Fear is
    // a volume signal, not a list of people to shoot.
    // mayOpen false: fear feeds an incident, it never starts one.
    registry.AddHeat(obj.GetWorldPosition(), weight, none, none, false, false, false);
  };
}

@wrapMethod(ScriptedPuppet)
protected cb func OnDeath(evt: ref<gameDeathEvent>) -> Bool {
  // Capture before wrappedMethod - death processing can invalidate position.
  let deathPos: Vector4 = this.GetWorldPosition();
  let wasOurUnit: Bool = NCD_IsOurUnit(this);

  let result: Bool = wrappedMethod(evt);

  let cfg: ref<NCDConfig> = NCDConfig.Get();
  if !IsDefined(cfg) || !cfg.modON {
    return result;
  };

  let sysHandler = GameInstance.GetSystemRequestsHandler();
  if IsDefined(sysHandler) && sysHandler.IsPreGame() {
    return result;
  };

  let registry: ref<NCDRegistry> = NCDRegistry.Get(GetGameInstance());
  if !IsDefined(registry) {
    return result;
  };

  registry.sensedDeath += 1;

  let none: EntityID;

  // --- one of ours went down ------------------------------------------------
  // The deliberate exception to the self-exclusion rule. Our units cannot
  // generate heat by ENTERING combat, because that loops forever - but they
  // absolutely can by dying. An officer down is the single strongest
  // escalator in the design, and it is the counter the MaxTac gate reads.
  //
  // Note this counts regardless of who fired. If V clips an officer at
  // someone else's firefight, that death escalates the incident exactly as if
  // a Valentino had done it. Get sloppy at a scene you were only ever a
  // bystander at, kill three cops, and you can legitimately pull MaxTac onto
  // it. That is a good Night City outcome and it is not special-cased away.
  if wasOurUnit {
    registry.sensedOfficerDeath += 1;
    registry.AddHeat(deathPos, cfg.heatOfficerDeath, none, none, true, true, true);
    return result;
  };

  // --- a civilian or combatant went down ------------------------------------
  let killer: EntityID;
  let weight: Float = cfg.heatDeath;
  let instigator: ref<GameObject> = evt.instigator as GameObject;

  // A body dropped by a third party is the strongest ordinary signal there is,
  // and it is what this mod exists for. Kills by V are not credited to a
  // killer: vanilla prevention already answers for those, and crediting them
  // would let the cyberpsychosis gate fire on the player. Kills by our own
  // officers are not credited either - police shooting people is the response,
  // not the incident.
  if IsDefined(instigator) && !instigator.IsPlayer() && !NCD_IsOurUnit(instigator) {
    killer = instigator.GetEntityID();
    weight *= cfg.thirdPartyMult;
  };

  registry.AddHeat(deathPos, weight, none, killer, true, false, true);
  return result;
}
