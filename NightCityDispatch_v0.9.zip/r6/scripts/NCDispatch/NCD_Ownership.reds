module NCDispatch

// ============================================================================
//  Ownership transfer  (design Phase 1.5)
//
//  The awkward case, and the one most likely to be hit in normal play: a gang
//  firefight is running, our units have arrived, V is a bystander, and a stray
//  round from V clips an officer. V now has stars.
//
//  v0.8a's answer was a circuit breaker - delete every unit, clear every
//  incident, stand the system down. That fixed an unshakeable wanted level and
//  in doing so implemented the single loudest anti-goal in the design
//  document: "an incident silently ceasing to exist because V acquired a
//  wanted level". Six combatants and two dead officers stop existing because
//  the player made a mistake, and the world's attention collapses back onto V,
//  which is exactly the failure this mod was built to fix.
//
//  The other wrong answer is running both systems at full tilt: vanilla spawns
//  for V, we spawn for the incident, and the scene doubles in unit count with
//  two authorities disagreeing about who is fighting whom.
//
//  The right answer, implemented here: V becomes a combatant in the existing
//  incident. Realistically you do not get your own separate police response
//  for shooting a cop at a firefight - you become the police operation's
//  second problem.
//
//    1. The incident stays open and keeps escalating. Heat keeps accumulating,
//       V's violence feeds it exactly like any other third party's.
//    2. Attitude re-evaluates for EXISTING units, not just new ones. An active
//       transition, not a policy applied at spawn.
//    3. Spawn authority passes to vanilla. We stop ADDING units. We keep
//       tracking, keep escalating, keep the incident alive.
//    4. Officer deaths caused by V count toward escalation, including the
//       MaxTac gate. That is handled in NCD_Sensors and is deliberately not
//       special-cased away here.
//    5. When V's stars clear and the incident is still hot, control returns
//       after a short cooldown. The fight was never ours to end.
//
//  Degrees of guilt are vanilla's job. A stray round in crossfire produces a
//  brief low-level reaction; deliberately engaging police produces a real
//  chase. We read vanilla's heat stage rather than inventing a parallel scale.
// ============================================================================

public class NCDOwnership extends ScriptableSystem {

  // Last observed vanilla wanted state, so the transition can be detected
  // rather than the condition merely being polled. The design is explicit that
  // this has to be an active transition.
  private let m_wasWanted: Bool;
  private let m_transfers: Int32;
  private let m_returns: Int32;

  public static func Get(gi: GameInstance) -> ref<NCDOwnership> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDOwnership") as NCDOwnership;
  }

  // ==========================================================================
  //  Vanilla prevention state
  // ==========================================================================

  public static func GetPrevention(gi: GameInstance) -> ref<PreventionSystem> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"PreventionSystem") as PreventionSystem;
  }

  public static func PlayerIsWanted(gi: GameInstance) -> Bool {
    let ps: ref<PreventionSystem> = NCDOwnership.GetPrevention(gi);
    if !IsDefined(ps) {
      return false;
    };
    return EnumInt(ps.GetHeatStage()) > 0;
  }

  public static func PlayerIsChased(gi: GameInstance) -> Bool {
    let ps: ref<PreventionSystem> = NCDOwnership.GetPrevention(gi);
    if !IsDefined(ps) {
      return false;
    };
    return ps.IsChasingPlayer();
  }

  public func WasWanted() -> Bool {
    return this.m_wasWanted;
  }

  public func TransferCount() -> Int32 {
    return this.m_transfers;
  }

  public func ReturnCount() -> Int32 {
    return this.m_returns;
  }

  // ==========================================================================
  //  Called once per heartbeat, before any dispatch decision.
  //
  //  Returns true if our units currently answer to vanilla rather than to us.
  // ==========================================================================
  public func Update(now: Float, incidents: array<ref<NCDIncident>>) -> Bool {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let gi: GameInstance = this.GetGameInstance();
    if !IsDefined(cfg) {
      return false;
    };

    let wanted: Bool = NCDOwnership.PlayerIsWanted(gi);

    if !cfg.ownershipTransferEnabled {
      // Feature off. Fall back to whatever the blunt switches say, and record
      // the state so that turning the feature back on mid-session sees a
      // correct previous value rather than a stale one.
      this.m_wasWanted = wanted;
      return wanted;
    };

    let spawner: ref<NCDSpawner> = NCDSpawner.Get(gi);

    // --- V just became wanted -----------------------------------------------
    if wanted && !this.m_wasWanted {
      this.m_transfers += 1;

      // 2. Every unit we have on scene stops ignoring V. This is the active
      //    transition: a cop that was walking past thirty seconds ago turns.
      let flipped: Int32 = 0;
      if IsDefined(spawner) {
        flipped = spawner.SetPlayerAttitudeOnAllUnits(false);
      };

      // 3. Spawn authority passes to vanilla on every live incident. Note the
      //    incidents themselves are untouched - they keep their heat, their
      //    tier, their casualty counts and their combatants.
      for inc in incidents {
        inc.vanillaOwnsSpawning = true;
        inc.ownershipReturnsAt = 0.0;
      };

      NCDLog(s"ownership -> vanilla (units flipped=\(flipped) incidents=\(ArraySize(incidents)))");
    };

    // --- V's stars cleared ---------------------------------------------------
    if !wanted && this.m_wasWanted {
      // Control comes back on a delay rather than instantly, so a chase that
      // flickers off for a second does not hand authority back and forth.
      for inc in incidents {
        if inc.vanillaOwnsSpawning {
          inc.ownershipReturnsAt = now + cfg.ownershipReturnDelay;
        };
      };
      NCDLog(s"ownership cooldown started (\(cfg.ownershipReturnDelay)s)");
    };

    // --- cooldown elapsed, take it back -------------------------------------
    if !wanted {
      let restored: Bool = false;
      for inc in incidents {
        if inc.vanillaOwnsSpawning && inc.ownershipReturnsAt > 0.0 && now >= inc.ownershipReturnsAt {
          inc.vanillaOwnsSpawning = false;
          inc.ownershipReturnsAt = 0.0;
          restored = true;
        };
      };
      if restored {
        this.m_returns += 1;
        // 5. Friendly override is restored and the system resumes. The fight
        //    was never ours to end.
        if IsDefined(spawner) {
          let flipped: Int32 = spawner.SetPlayerAttitudeOnAllUnits(true);
          NCDLog(s"ownership -> us (units restored=\(flipped))");
        };
      };
    };

    this.m_wasWanted = wanted;
    return wanted;
  }

  // ==========================================================================
  //  May we add units to this incident right now?
  //
  //  Note what this does NOT do: it never closes the incident, never clears
  //  heat, never stops escalation. It only withholds the one thing vanilla is
  //  also doing.
  // ==========================================================================
  public func MaySpawnFor(inc: ref<NCDIncident>) -> Bool {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    if !IsDefined(cfg) || !IsDefined(inc) {
      return false;
    };
    if !cfg.ownershipTransferEnabled {
      return true;
    };
    return !inc.vanillaOwnsSpawning;
  }

  public func Reset() -> Void {
    this.m_wasWanted = false;
  }
}
