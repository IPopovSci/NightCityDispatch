module NCDispatch

// ============================================================================
//  District response doctrine
//
//  "The same firefight produces a gunship in Corpo Plaza and total silence in
//   Pacifica. Response is a function of whose property is being damaged, not
//   of harm caused."
//
//  This file has two halves and they fail very differently.
//
//  1. THE PROFILE TABLE (BuildProfiles) is transcribed straight from the
//     design document's district table. It is the content of the feature and
//     it is correct as written.
//
//  2. THE GEOMETRY TABLE (BuildZones) maps a world position to one of those
//     profiles. It ships EMPTY. Every zone resolves to Unknown and gets the
//     default profile until you fill it in.
//
//  The geometry ships empty on purpose. Night City's world-space coordinates
//  could not be verified from any source available when this was written (see
//  docs/BLOCKERS.md), and guessing them would silence a district or summon
//  MaxTac to Pacifica with no way to tell that from a logic bug. Filling it in
//  takes about fifteen minutes with calibrationMode on: walk to a district,
//  read V's position off the probe, add a line. docs/CALIBRATION.md is the
//  step-by-step.
//
//  Zones are circles, not boxes. A circle is one centre and one radius, which
//  is exactly what you can read off a screen while standing in a place, and it
//  degrades gracefully - an overlapping or slightly-wrong circle produces a
//  slightly-wrong response profile, never a crash.
// ============================================================================

// ---------------------------------------------------------------------------
// Zone identity. Int32 constants rather than an enum so that adding a zone
// never has to touch a type declaration.
// ---------------------------------------------------------------------------
public class NCDZone {
  public static func Unknown()      -> Int32 { return 0; }
  public static func CityCenter()   -> Int32 { return 1; }
  public static func Westbrook()    -> Int32 { return 2; }
  public static func Japantown()    -> Int32 { return 3; }
  public static func HeywoodGov()   -> Int32 { return 4; }
  public static func VistaDelRey()  -> Int32 { return 5; }
  public static func WatsonCentre() -> Int32 { return 6; }
  public static func Northside()    -> Int32 { return 7; }
  public static func SantoDomingo() -> Int32 { return 8; }
  public static func Pacifica()     -> Int32 { return 9; }
  public static func Badlands()     -> Int32 { return 10; }
}

// ---------------------------------------------------------------------------
// One district's response doctrine.
// ---------------------------------------------------------------------------
public class NCDZoneProfile extends IScriptable {
  public let zone: Int32;
  public let name: String;

  // Seconds between an incident being reported and the first unit being
  // created. "Delay is not a defect; it's the mechanism that lets the player
  // watch a situation develop."
  public let responseDelay: Float;

  // Highest tier reachable here, whatever happens. A Northside incident
  // cannot reach tactical no matter how bad it gets.
  //   0 = no response at all
  //   1 = patrol
  //   2 = containment
  //   3 = tactical
  //   4 = MaxTac
  public let ceiling: Int32;

  // Scales the heat thresholds. Below 1.0 the district reacts to less. City
  // Center calls it in early; Northside barely calls it in at all.
  public let thresholdMult: Float;

  // Multiplies the number of units in each wave. Vista del Rey shows up late
  // and in numbers; Watson shows up thin.
  public let forceMult: Float;

  // City Center only. Corporate pressure produces disproportionate force -
  // MaxTac for something that would get one cruiser in Santo Domingo.
  public let maxTacOverride: Bool;

  // Purely descriptive, shown in the probe so you can see which profile is
  // actually in effect.
  public let character: String;
}

public class NCDDoctrine extends ScriptableSystem {

  private let m_profiles: array<ref<NCDZoneProfile>>;
  private let m_zoneIds: array<Int32>;
  private let m_zoneX: array<Float>;
  private let m_zoneY: array<Float>;
  private let m_zoneR: array<Float>;

  public static func Get(gi: GameInstance) -> ref<NCDDoctrine> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDDoctrine") as NCDDoctrine;
  }

  private func OnAttach() -> Void {
    this.BuildProfiles();
    this.BuildZones();
  }

  // ==========================================================================
  //  1. PROFILES - transcribed from the design document. This is the feature.
  // ==========================================================================

  private func AddProfile(zone: Int32, name: String, delay: Float, ceiling: Int32,
                          thresholdMult: Float, forceMult: Float, override: Bool,
                          character: String) -> Void {
    let p: ref<NCDZoneProfile> = new NCDZoneProfile();
    p.zone = zone;
    p.name = name;
    p.responseDelay = delay;
    p.ceiling = ceiling;
    p.thresholdMult = thresholdMult;
    p.forceMult = forceMult;
    p.maxTacOverride = override;
    p.character = character;
    ArrayPush(this.m_profiles, p);
  }

  private func BuildProfiles() -> Void {
    let empty: array<ref<NCDZoneProfile>>;
    this.m_profiles = empty;

    // Unknown is the fallback for anywhere the geometry table does not cover,
    // which by default is everywhere. It is deliberately middling - a
    // competent, unremarkable response - so that an uncalibrated install
    // behaves like Heywood rather than like nothing or like Corpo Plaza.
    this.AddProfile(NCDZone.Unknown(), "Unlisted", 30.0, 3, 1.0, 1.0, false,
      "Default. Fill in the zone table to get real district behaviour.");

    this.AddProfile(NCDZone.CityCenter(), "City Center", 14.0, 4, 0.65, 1.4, true,
      "Disproportionate. Corporate property. Arrives in force for things that would be ignored elsewhere.");

    this.AddProfile(NCDZone.Westbrook(), "Westbrook", 20.0, 3, 0.8, 1.2, false,
      "Wealth is protected.");

    this.AddProfile(NCDZone.Japantown(), "Japantown", 30.0, 3, 1.0, 1.0, false,
      "Tyger Claw territory. Response is present but negotiated - slower, more cautious.");

    this.AddProfile(NCDZone.HeywoodGov(), "Heywood - Wellsprings / The Glen", 26.0, 3, 1.0, 1.0, false,
      "Government district. Competent, unremarkable.");

    this.AddProfile(NCDZone.VistaDelRey(), "Heywood - Vista del Rey", 45.0, 2, 1.3, 1.4, false,
      "Valentino turf. NCPD shows up late and in numbers, or not at all.");

    this.AddProfile(NCDZone.WatsonCentre(), "Watson - Little China / Kabuki", 45.0, 2, 1.3, 0.8, false,
      "Overstretched. Response exists but is thin and arrives after the fact.");

    this.AddProfile(NCDZone.Northside(), "Watson - Northside", 60.0, 1, 1.7, 0.6, false,
      "Maelstrom territory. Minimal presence. Often just a drive-by that does not stop.");

    this.AddProfile(NCDZone.SantoDomingo(), "Santo Domingo", 45.0, 2, 1.25, 1.0, false,
      "Industrial. Corporate security responds to corporate property; NCPD covers the rest badly.");

    // Pacifica having no response is a feature, not an omission. It is the
    // clearest way the system communicates its own logic to the player:
    // firefights there escalate forever and nobody comes.
    this.AddProfile(NCDZone.Pacifica(), "Pacifica", 0.0, 0, 1.0, 0.0, false,
      "Abandoned combat zone. NCPD does not enter. This is the point.");

    this.AddProfile(NCDZone.Badlands(), "Badlands", 0.0, 0, 1.0, 0.0, false,
      "Outside jurisdiction. Nomad and corpo problems only.");
  }

  // ==========================================================================
  //  2. GEOMETRY - ships empty. See docs/CALIBRATION.md.
  // ==========================================================================

  private func AddZone(zone: Int32, x: Float, y: Float, radius: Float) -> Void {
    ArrayPush(this.m_zoneIds, zone);
    ArrayPush(this.m_zoneX, x);
    ArrayPush(this.m_zoneY, y);
    ArrayPush(this.m_zoneR, radius);
  }

  private func BuildZones() -> Void {
    let emptyI: array<Int32>;
    let emptyF: array<Float>;
    this.m_zoneIds = emptyI;
    this.m_zoneX = emptyF;
    this.m_zoneY = emptyF;
    this.m_zoneR = emptyF;

    // -----------------------------------------------------------------------
    // FILL THIS IN. Set calibrationMode = true in NCD_Config, walk to the
    // centre of a district, read the "pos" figures off the probe, and add a
    // line here. Radius in metres - err large, the smallest matching circle
    // wins so you can nest a neighbourhood inside a district.
    //
    // Order does not matter. Overlaps are fine.
    //
    // Worked example, with made-up numbers so you can see the shape:
    //
    //   this.AddZone(NCDZone.WatsonCentre(), -1300.0,  1450.0, 400.0);
    //   this.AddZone(NCDZone.Northside(),    -1050.0,  2100.0, 350.0);
    //   this.AddZone(NCDZone.Pacifica(),     -1900.0, -1500.0, 700.0);
    //
    // Nothing below this line until you add it. Every position resolves to
    // Unknown and gets the default profile, which is intentional: an empty
    // table produces one consistent, sane response everywhere rather than a
    // confidently wrong one somewhere.
    // -----------------------------------------------------------------------
  }

  // ==========================================================================
  //  Resolution
  // ==========================================================================

  // Smallest circle containing the point wins, so a neighbourhood nested
  // inside a district resolves to the neighbourhood.
  public func Resolve(pos: Vector4) -> Int32 {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    if !IsDefined(cfg) || !cfg.districtsEnabled {
      return NCDZone.Unknown();
    };

    let best: Int32 = NCDZone.Unknown();
    let bestR: Float = 0.0;
    let i: Int32 = 0;
    while i < ArraySize(this.m_zoneIds) {
      let dx: Float = pos.X - this.m_zoneX[i];
      let dy: Float = pos.Y - this.m_zoneY[i];
      let r: Float = this.m_zoneR[i];
      // Squared compare - no sqrt helper is needed and none was verified.
      if (dx * dx) + (dy * dy) <= (r * r) {
        if bestR <= 0.0 || r < bestR {
          best = this.m_zoneIds[i];
          bestR = r;
        };
      };
      i += 1;
    };
    return best;
  }

  public func ProfileFor(zone: Int32) -> ref<NCDZoneProfile> {
    let fallback: ref<NCDZoneProfile>;
    for p in this.m_profiles {
      if p.zone == zone {
        return p;
      };
      if p.zone == NCDZone.Unknown() {
        fallback = p;
      };
    };
    return fallback;
  }

  public func ProfileAt(pos: Vector4) -> ref<NCDZoneProfile> {
    return this.ProfileFor(this.Resolve(pos));
  }

  public func ZoneCount() -> Int32 {
    return ArraySize(this.m_zoneIds);
  }
}
