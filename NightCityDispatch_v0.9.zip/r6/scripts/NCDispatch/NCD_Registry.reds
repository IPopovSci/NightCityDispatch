module NCDispatch

// ============================================================================
//  Incident registry
//
//  Owns every incident. Sensors push events in from game threads; the
//  heartbeat pulls a decayed, pruned view out. Nothing else touches the array.
//
//  LOCKING RULE, and it is the reason this file exists separately from the
//  dispatcher: every mutation of heat or of a tally happens inside this class
//  under the write lock. v0.8a decayed heat inside the lock and then let the
//  dispatcher add sustained heat to the same field outside it, racing with the
//  sensor hooks.
//
//  Fields the dispatcher owns exclusively - state, tier, respondAt, nextWaveAt,
//  ownership - are never touched by sensors and are safe to write directly.
//
//  ALSO IN HERE: the stage counters. Requested / accepted / attached / alive
//  were four distinct numbers on this project and three of them lied at
//  different times, so every stage boundary gets its own counter and none of
//  them are ever collapsed.
// ============================================================================

public class NCDRegistry extends ScriptableSystem {

  private let m_incidents: array<ref<NCDIncident>>;
  private let m_lock: RWLock;
  private let m_nextId: Int32;

  // --- sensing --------------------------------------------------------------
  public let sensedCombat: Int32;
  public let sensedAlert: Int32;
  public let sensedDeath: Int32;
  public let sensedOfficerDeath: Int32;

  // --- incident lifecycle ---------------------------------------------------
  public let incidentsOpened: Int32;
  public let incidentsClosed: Int32;
  public let peakHeat: Float;

  // --- spawn pipeline, one counter per stage boundary -----------------------
  // wavesRequested : the dispatcher decided a wave should happen
  // unitsRequested : CreateEntity was about to be called
  // unitsAccepted  : CreateEntity returned a valid EntityID. This means the
  //                  request was QUEUED, not that anything exists.
  // unitsAttached  : Entity/Attached fired. This is the first number that
  //                  means a unit is really in the world.
  // unitsDetached  : Entity/Detach fired.
  // unitsDespawned : we called DeleteEntity ourselves.
  public let wavesRequested: Int32;
  public let unitsRequested: Int32;
  public let unitsAccepted: Int32;
  public let unitsAttached: Int32;
  public let unitsDetached: Int32;
  public let unitsDespawned: Int32;

  // --- why a wave did not happen -------------------------------------------
  // A wave that is correctly suppressed and a wave that silently failed look
  // identical without these.
  public let blockedByDistrict: Int32;
  public let blockedByOwnership: Int32;
  public let blockedByCap: Int32;
  public let blockedByEntryCond: Int32;
  public let spawnPointFailures: Int32;

  // --- hook liveness --------------------------------------------------------
  public let attachHookLive: Bool;

  public static func Get(gi: GameInstance) -> ref<NCDRegistry> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDRegistry") as NCDRegistry;
  }

  // ==========================================================================
  //  Sensor entry point
  //
  //  killer is the entity that caused a death, or invalid. combatant is the
  //  entity whose behaviour generated the event, or invalid for bystander
  //  noise - alerted civilians raise heat but are never marked as targets.
  // ==========================================================================
  //  mayOpen distinguishes an event that can START an incident from one that
  //  can only feed an existing one. Bystander fear is the second kind: "volume
  //  matters more than individual events". Without this, one startled civilian
  //  opens an incident, and with maxIncidents at 4 a busy street corner fills
  //  every slot with noise and locks out the firefight next to it.
  public func AddHeat(pos: Vector4, amount: Float, combatant: EntityID,
                      killer: EntityID, isDeath: Bool, isOfficerDeath: Bool,
                      mayOpen: Bool) -> Void {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    if !IsDefined(cfg) || !cfg.modON || amount <= 0.0 {
      return;
    };

    let gi: GameInstance = this.GetGameInstance();
    let now: Float = EngineTime.ToFloat(GameInstance.GetSimTime(gi));

    RWLock.Acquire(this.m_lock);

    let target: ref<NCDIncident>;
    for inc in this.m_incidents {
      if !IsDefined(target) && Vector4.Distance(inc.position, pos) <= cfg.mergeRadius {
        target = inc;
      };
    };

    if !IsDefined(target) && mayOpen {
      if ArraySize(this.m_incidents) < cfg.maxIncidents {
        target = this.OpenLocked(pos, now);
      };
    };

    if IsDefined(target) {
      target.heat += amount;
      if target.heat > cfg.maxIncidentHeat {
        target.heat = cfg.maxIncidentHeat;
      };
      if target.heat > target.peakHeat {
        target.peakHeat = target.heat;
      };
      if target.peakHeat > this.peakHeat {
        this.peakHeat = target.peakHeat;
      };

      // Violence resuming after a quiet spell restarts the continuous-violence
      // clock. The MaxTac duration gate reads that clock, not total age, so a
      // fight that stops and starts again does not accumulate credit toward a
      // specialist deployment it never earned.
      if target.violenceSince <= 0.0 || target.SecondsQuiet(now) > cfg.quietAfter {
        target.violenceSince = now;
      };
      target.lastEventAt = now;

      // Drift the centre toward new activity so the marker stays roughly on
      // top of the shooting rather than on wherever it started.
      target.position = (target.position * 0.8) + (pos * 0.2);

      target.AddCombatant(combatant);

      if isDeath {
        target.deaths += 1;
        target.CreditKill(killer);
      };
      if isOfficerDeath {
        target.officerDeaths += 1;
      };
    };

    RWLock.Release(this.m_lock);
  }

  // Caller must hold the write lock.
  private func OpenLocked(pos: Vector4, now: Float) -> ref<NCDIncident> {
    let inc: ref<NCDIncident> = new NCDIncident();
    this.m_nextId += 1;
    inc.id = this.m_nextId;
    inc.position = pos;
    inc.zone = NCDZone.Unknown();
    inc.heat = 0.0;
    inc.peakHeat = 0.0;
    inc.state = NCDState.Dormant();
    inc.stateEnteredAt = now;
    inc.tier = 0;
    inc.tierEnteredAt = now;
    inc.openedAt = now;
    inc.lastEventAt = now;
    inc.violenceSince = now;
    inc.respondAt = 0.0;
    inc.nextWaveAt = 0.0;
    inc.nextEscalationAt = 0.0;
    inc.deaths = 0;
    inc.officerDeaths = 0;
    inc.unitsDeployed = 0;
    inc.perimeterBreaches = 0;
    inc.vanillaOwnsSpawning = false;
    inc.ownershipReturnsAt = 0.0;
    ArrayPush(this.m_incidents, inc);
    this.incidentsOpened += 1;
    return inc;
  }

  // ==========================================================================
  //  Heartbeat entry point
  //
  //  Two phases on purpose. Phase 1 queries the world for each incident -
  //  who is still fighting, who has left the perimeter - without holding the
  //  lock, because engine lookups under a lock held by sensor threads is a
  //  stall waiting to happen. Phase 2 applies the results under the lock.
  // ==========================================================================
  public func Tick(now: Float, dt: Float, playerPos: Vector4) -> array<ref<NCDIncident>> {
    let survivors: array<ref<NCDIncident>>;
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    if !IsDefined(cfg) {
      return survivors;
    };

    // --- snapshot -----------------------------------------------------------
    RWLock.AcquireShared(this.m_lock);
    let snapshot: array<ref<NCDIncident>> = this.m_incidents;
    RWLock.ReleaseShared(this.m_lock);

    // --- phase 1: query the world, no lock held -----------------------------
    let gi: GameInstance = this.GetGameInstance();
    let fightingCounts: array<Int32>;
    let breachCounts: array<Int32>;
    for inc in snapshot {
      let fighting: Int32 = 0;
      let breaches: Int32 = 0;
      for c in inc.combatants {
        let p: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, c.id) as ScriptedPuppet;
        if IsDefined(p) && ScriptedPuppet.IsActive(p) && NPCPuppet.IsInCombat(p) && !c.isOurs {
          fighting += 1;
          // A combatant still fighting outside the cordon is the perimeter
          // failing, which is one of the design's tier 3 entry conditions.
          // Only they count - our own officers standing off at the staging
          // distance are outside that radius by design, and counting them
          // would report the perimeter as broken the instant it was set up.
          if Vector4.Distance(p.GetWorldPosition(), inc.position) > cfg.perimeterRadius {
            breaches += 1;
          };
        };
      };
      ArrayPush(fightingCounts, fighting);
      ArrayPush(breachCounts, breaches);
    };

    // --- phase 2: apply under the lock --------------------------------------
    RWLock.Acquire(this.m_lock);

    let kept: array<ref<NCDIncident>>;
    let i: Int32 = 0;
    while i < ArraySize(snapshot) {
      let inc: ref<NCDIncident> = snapshot[i];

      // Sustained heat. This is what separates a brief exchange from a
      // prolonged battle, and it is the core of the MaxTac gate.
      if i < ArraySize(fightingCounts) && fightingCounts[i] > 0 {
        inc.heat += cfg.heatSustainPerCombatant * Cast<Float>(fightingCounts[i]) * dt;
        inc.lastEventAt = now;
        // Ongoing combat restarts the continuous-violence clock as well as
        // resetting the quiet timer. Without this, a fight that goes quiet and
        // then resumes without generating a fresh combat-entry or death event
        // - which is the normal shape of a lull in a long firefight - would
        // keep a zeroed violence clock, and the tier 1 duration gate and the
        // MaxTac duration gate would both stop being reachable.
        if inc.violenceSince <= 0.0 {
          inc.violenceSince = now;
        };
      };
      if i < ArraySize(breachCounts) {
        inc.perimeterBreaches = breachCounts[i];
      };

      inc.heat -= cfg.heatDecayPerSec * dt;
      if inc.heat > cfg.maxIncidentHeat {
        inc.heat = cfg.maxIncidentHeat;
      };
      if inc.heat > inc.peakHeat {
        inc.peakHeat = inc.heat;
      };
      if inc.peakHeat > this.peakHeat {
        this.peakHeat = inc.peakHeat;
      };

      // Quiet for long enough - the continuous-violence clock stops.
      if inc.SecondsQuiet(now) > cfg.quietAfter {
        inc.violenceSince = 0.0;
      };

      let tooFar: Bool = Vector4.Distance(inc.position, playerPos) > cfg.maxRangeFromPlayer;
      let coldEnough: Bool = inc.heat <= cfg.closeBelowHeat;

      // An incident with units still on the ground is not dropped for going
      // cold - it has to walk through SWEEPING and WITHDRAWING first, or the
      // units it deployed are orphaned. Only CLOSED, or out of range, removes.
      let unitsOut: Bool = NCDState.HasUnits(inc.state);
      let remove: Bool = false;
      if inc.state == NCDState.Closed() {
        remove = true;
      };
      if tooFar {
        remove = true;
      };
      if coldEnough && !unitsOut {
        remove = true;
      };

      if remove {
        this.incidentsClosed += 1;
      } else {
        ArrayPush(kept, inc);
      };
      i += 1;
    };

    this.m_incidents = kept;
    survivors = kept;

    RWLock.Release(this.m_lock);
    return survivors;
  }

  // ==========================================================================
  //  Queries
  // ==========================================================================

  // Nearest incident to a position within a radius. Used to attribute an
  // officer death to the incident that killed them, and to route deaths whose
  // combat entry we never saw.
  public func FindNearest(pos: Vector4, radius: Float) -> ref<NCDIncident> {
    let best: ref<NCDIncident>;
    let bestDist: Float = radius;
    RWLock.AcquireShared(this.m_lock);
    for inc in this.m_incidents {
      let d: Float = Vector4.Distance(inc.position, pos);
      if d <= bestDist {
        best = inc;
        bestDist = d;
      };
    };
    RWLock.ReleaseShared(this.m_lock);
    return best;
  }

  public func Snapshot() -> array<ref<NCDIncident>> {
    RWLock.AcquireShared(this.m_lock);
    let out: array<ref<NCDIncident>> = this.m_incidents;
    RWLock.ReleaseShared(this.m_lock);
    return out;
  }

  public func Count() -> Int32 {
    RWLock.AcquireShared(this.m_lock);
    let n: Int32 = ArraySize(this.m_incidents);
    RWLock.ReleaseShared(this.m_lock);
    return n;
  }

  public func MaxHeat() -> Float {
    let best: Float = 0.0;
    RWLock.AcquireShared(this.m_lock);
    for inc in this.m_incidents {
      if inc.heat > best {
        best = inc.heat;
      };
    };
    RWLock.ReleaseShared(this.m_lock);
    return best;
  }

  // The incident the probe should describe: the hottest one.
  public func Hottest() -> ref<NCDIncident> {
    let best: ref<NCDIncident>;
    let bestHeat: Float = -1.0;
    RWLock.AcquireShared(this.m_lock);
    for inc in this.m_incidents {
      if inc.heat > bestHeat {
        best = inc;
        bestHeat = inc.heat;
      };
    };
    RWLock.ReleaseShared(this.m_lock);
    return best;
  }

  public func Clear() -> Void {
    let empty: array<ref<NCDIncident>>;
    RWLock.Acquire(this.m_lock);
    this.incidentsClosed += ArraySize(this.m_incidents);
    this.m_incidents = empty;
    RWLock.Release(this.m_lock);
  }
}
