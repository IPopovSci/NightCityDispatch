# Night City Dispatch v0.8a

NCPD responds to violence that isn't yours.

NPCs entering combat, panicking, and dying accumulate **heat** at a location.
Enough heat, and police show up - patrol, then tactical, then MaxTac - hostile
to the people actually fighting, neutral to V.

## Install

**Spawning is OFF by default in v0.7.** The sensing and escalation half is
stable and safe. The spawning half has crashed twice and once produced a wanted
level that could not be shaken. Set `spawnEnabled = true` only on a backed-up
save.

Install as a normal MO2 mod, overwriting the previous version. Rename it
`[NoDelete] [00xx] Night City Dispatch` so Wabbajack keeps it across Ultrapunk
updates.

Requires redscript only.

## How it works

| Stage | What |
|---|---|
| Sense | Wraps `NPCPuppet.ChangeHighLevelState` and `ScriptedPuppet.OnDeath`. Combat entry = 2.5 heat, Alerted = 0.7, death = 3.0. Non-V kills weighted 1.35x. |
| Aggregate | Events within 30 m merge into one incident. Heat decays 0.5/sec. Incidents beyond 130 m of V are dropped. |
| Escalate | Heat 6 -> 2 patrol. Heat 16 -> 3 tactical. Heat 34 -> 4 MaxTac. 22 s between waves. |
| Spawn | Off-camera navmesh point ~55 m out, then they run in. |
| Clean up | Per-unit check every 12 s; removed when far, dead-and-unseen, or idle and drifting. |

Responding officers are excluded from sensing, so they cannot generate heat by
entering combat and summon reinforcements for themselves.

## Player safety

1. Officers are forced friendly to V on spawn.
2. If V already has stars, that override is skipped - vanilla owns attitude.
3. If vanilla prevention is chasing V, the system stands down and clears.

## Diagnostics

`NCD_Probe.reds` prints an on-screen line every 5 s:

    NCD 12 [CRSDA] sig 32/34/1 inc 3 heat 41.2/55.0 spawn 10/10 att 10/4 units 6(tag0)

- `[CRSDA]` - Config / Registry / Spawner / Dispatcher resolved, plus A = the
  entity-attached callback registered successfully. A dash = that piece is dead.
- `sig a/b/c` - combat entries / alerts / deaths sensed
- `heat now/peak` - highest current incident heat, and highest ever seen
- `spawn accepted/requested` - CreateEntity calls that returned a valid ID.
  This only means the request was QUEUED, not that anything spawned.
- `att attached/detached` - units that actually entered the world, and left it.
  If attached climbs while detached matches it, they are spawning and being
  removed again immediately.
- `inc` - active incidents
- `units N(tagM)` - N is our own count of live spawned units and is the real
  number. M is what `GetTagged` reports, kept only as a cross-check; it has
  been observed reading 0 while units were demonstrably alive.

Reading it: if `peak` never reaches `tier1Heat`, it is a tuning problem. If
`peak` crosses but `requested` stays 0, the dispatcher is not firing. If
`accepted` climbs while `att` stays 0, entities are being requested but never
created - check that `A` is present in the bracket, and try
`allowSpawnInView = true`.

Delete `NCD_Probe.reds` when done. Nothing else depends on it.

## Tuning

All in `NCD_Config.reds`. Relaunch to apply.

- Still crashing -> set `spawnEnabled = false`. If it stops, spawning is the
  cause and the record list is the first thing to look at.
- Too much police -> raise `tier1Heat`, raise `heatDecayPerSec`, lower `maxLiveUnits`
- Never triggers -> lower `tier1Heat` to 4.0
- MaxTac too eager -> raise `tier3Heat` past 50
- Alerted bystanders too noisy -> drop `heatAlerted` to 0.3

## Known limits

- Incidents only exist near V. Nothing escalates off-screen.
- Officers arrive on foot. No vehicles, no AV drops.
- Units fight until one side is down. No arrests, no de-escalation.

## Changelog

**v0.7** - Two real bugs, both mine.

Unshakeable police: officers go hostile to combatants, V catches a stray, vanilla
prevention grants stars, and `respectPlayerHeat` then STOPS forcing friendly on
every later spawn - so the mod bootstraps a wanted level and keeps feeding it.
Added a circuit breaker: any wanted level at all now despawns every unit and
stands the system down.

Reload crash: nothing was cleaned up at session end. Spawned entities and their
self-rescheduling TTL callbacks outlived the world. Added `OnDetach` teardown.

Also removed the forced `AlertPuppet` on spawn and the synthetic gunshot stim
used to make officers notice targets - broadcasting a gunshot beside the player
escalates everything in earshot, V included. Spawning now defaults OFF.

**v0.8a** - `spawnEnabled` was shipped as `false`. It was flipped during the
v0.7 crash work and never announced, so v0.8 looked like a spawning regression
against v0.6 when in fact nothing was ever calling `CreateEntity`. The
`SPAWN 0/94` signature - attempts climbing, successes flat - is precisely what
the disabled branch produces. Back to `true`, and the probe now prefixes
SPAWN-OFF when it is disabled, because a switched-off spawner and a broken one
produce identical telemetry otherwise.

**v0.8** - `GetTagged` returns 0 even while the attach callback is firing for
those same tags, so unit population is now tracked in an array we own, pruned
against live entities each tick. This was not cosmetic: the spawn cap is
computed as `maxLiveUnits - live`, so a permanently-zero count meant every wave
spawned at full size every cooldown with no ceiling. Unbounded entity
accumulation is the best explanation yet for the crashes.

Added `maxIncidentHeat` (55.0). A sustained fight was reaching 88+, far past
the MaxTac threshold, which kept re-triggering waves indefinitely.

**v0.7** - `suppressDuringChase` now defaults OFF. It stood the whole system
down whenever vanilla prevention was chasing you, which made the mod
untestable, since picking a fight with police is the easiest way to generate
violence. `respectPlayerHeat` already prevents attitude laundering, and police
arriving at a firefight you are in is correct behaviour.

Added session teardown. Dynamic entities and their self-rescheduling TTL
callbacks were surviving into a disposed session, and the TTL callback then
called `DeleteEntity` on a system mid-disposal. Now despawns on
`Session/BeforeEnd` and `OnDetach`, and TTL callbacks bail out during teardown.
This is the prime suspect for the crash on reload.

Added a detach counter to distinguish "never spawned" from "spawned and
immediately removed".

**v0.6** - Checked the actual Codeware spec instead of inferring semantics from
other mods, and found two things.

First, `spawnInView = false` does not drop a spawn whose point is in view - it
QUEUES it until the player looks away, potentially forever. `CreateEntity`
still returns a valid ID. That is precisely the `spawn 6/6, units 0` signature.
Default is now true.

Second, and worse: the entity-attached callback was registered inside
`OnPlayerAttach`, which per the docs only fires on a NEW GAME. Loading a save
goes through `OnRestored`. So on any loaded save the callback never registered,
meaning no attitude assignment, no move orders, and no despawn cleanup.
Registration moved to `OnAttach` as the official example does. Also switched
the entity system handle to `wref` per the docs' warning about holding strong
references to game systems.

**v0.5** - `spawn 5/5, units 0` showed that a valid EntityID from
`CreateEntity` means the request was accepted, not that an entity exists. Added
an `att` counter incremented in the entity-attached callback, which is the real
measure, plus an `A` flag confirming that callback registered at all. Exposed
`allowSpawnInView`, now defaulting true: with it false the engine silently
drops any spawn whose point is within view, which is a plausible cause of every
request vanishing.

**v0.4** - CRASH FIX. Tier 1 used `Character.sq023_policeman` and
`mq010_policeman`, which are quest-scene NPCs. They were taken from They Will
Remember's identification database, where they are used to RECOGNISE NPCs, not
to spawn them - a record existing in TweakDB is not the same as it being safe
to instantiate cold. Tier 1 fires first, which matches the crash timing. All
three tiers now use only records the game itself spawns dynamically as vehicle
passengers. Also dropped the `n"random"` appearance override (unresolved
appearances crash natively rather than erroring), added a position sanity check
before `CreateEntity`, and now verify the returned EntityID. Added a
`spawnEnabled` config switch for bisecting.

**v0.3** - Officer deaths now escalate (8.0 heat) - the self-exclusion guard
blocked our units from generating heat by entering combat, which was correct,
but it also silently swallowed downed officers. Added sustained heat: each
combatant still alive and fighting feeds 0.35/sec into its incident, so long
firefights escalate rather than decaying below threshold. Waves can now repeat
at the same tier after cooldown. Probe now reports heat and spawn telemetry.

**v0.2a** - Fixed an unresolved type annotation on `GetSystemRequestsHandler`.

**v0.2** - Rewrote the sensor layer. v0.1 wrapped
`ReactionManagerComponent.OnDelayStimEvent`, which never fired once in a real
load order - confirmed by instrumented counter, not assumption. Now uses
`NPCPuppet.ChangeHighLevelState` and `ScriptedPuppet.OnDeath`. Added
self-exclusion guard against feedback loops. Counters moved into `NCDRegistry`
so the probe is safely deletable. `debugON` now defaults true.
