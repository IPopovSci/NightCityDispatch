module NCDispatch

// ============================================================================
//  Night City Dispatch - configuration
//
//  Every knob lives here. Edit values, relaunch the game (redscript recompiles
//  on launch), done. No external config framework required.
// ============================================================================

public class NCDConfig extends ScriptableSystem {

  public static func Get() -> ref<NCDConfig> {
    return GameInstance.GetScriptableSystemsContainer(GetGameInstance()).Get(n"NCDispatch.NCDConfig") as NCDConfig;
  }

  // --- master switches ------------------------------------------------------

  public let modON: Bool = true;

  // Bisect switch. Set false to run sensing and escalation with no spawning
  // at all - useful for isolating whether a crash comes from CreateEntity.
  // When this is false the probe prints SPAWN-OFF, because a silently
  // disabled spawner looks identical to a broken one.
  public let spawnEnabled: Bool = true;

  // Set true and check the redscript log to watch heat build in real time.
  public let debugON: Bool = true;

  // --- incident tracking ----------------------------------------------------

  // Two violent events within this many metres are treated as one incident.
  public let mergeRadius: Float = 30.0;

  // Hard cap on simultaneously tracked incidents. Keeps the tick cheap.
  public let maxIncidents: Int32 = 4;

  // Incidents further than this from V are dropped entirely. This is the
  // "within where the player is" boundary - beyond it the NPCs are not
  // streamed in and there is nothing to police.
  public let maxRangeFromPlayer: Float = 130.0;

  // --- heat weights per event type -----------------------------------------

  // An NPC entering Combat. This is the primary signal.
  public let heatCombatEntry: Float = 2.5;

  // An NPC entering Alerted - bystanders reacting to nearby trouble.
  public let heatAlerted: Float = 0.7;

  // An NPC dying.
  public let heatDeath: Float = 3.0;

  // One of OUR officers dying. A downed cop escalates hard - this is the one
  // case where our own units are allowed to generate heat.
  public let heatOfficerDeath: Float = 8.0;

  // Sustained heat per second, per combatant still alive and fighting. This is
  // what makes a prolonged firefight escalate instead of decaying out.
  public let heatSustainPerCombatant: Float = 0.35;

  // Multiplier applied when the shooter is NOT V. Gang-on-gang violence is
  // what this mod exists for, so it is weighted a little heavier than V's
  // own gunfire (which vanilla prevention already handles).
  public let thirdPartyMult: Float = 1.35;

  // Heat bled off per second. Higher = incidents resolve faster.
  public let heatDecayPerSec: Float = 0.5;

  // --- escalation ladder ----------------------------------------------------

  public let tier1Heat: Float = 6.0;    // patrol response
  public let tier2Heat: Float = 16.0;   // tactical response
  public let tier3Heat: Float = 34.0;

  // Hard ceiling on incident heat. Without this a long fight saturates far
  // above tier 3 and keeps re-triggering waves every cooldown indefinitely.
  public let maxIncidentHeat: Float = 55.0;   // MaxTac

  public let tier1Count: Int32 = 2;
  public let tier2Count: Int32 = 3;
  public let tier3Count: Int32 = 4;

  // Minimum seconds between waves on the same incident.
  public let waveCooldown: Float = 22.0;

  // Global cap on units this mod has alive at once.
  public let maxLiveUnits: Int32 = 12;

  // --- spawning -------------------------------------------------------------

  // Officers are placed roughly this far from V, then run in.
  public let spawnDistance: Float = 55.0;

  // false = the engine REFUSES to create the entity if the spawn point is
  // within view, and the request is silently dropped. That is elegant when it
  // works and invisible when it does not. true guarantees creation.
  public let allowSpawnInView: Bool = true;

  // How often the despawn check runs per unit.
  public let ttlInterval: Float = 12.0;

  // Units beyond this distance from V are removed.
  public let despawnDistance: Float = 165.0;

  // --- player safety --------------------------------------------------------

  // Force spawned officers friendly toward V. This is the whole point: they
  // are here for the gang fight, not for you.
  public let forceFriendlyToPlayer: Bool = true;

  // If V already has stars, hand attitude back to vanilla prevention and do
  // not force friendly - otherwise this mod would launder your wanted level.
  public let respectPlayerHeat: Bool = true;

  // Suppress dispatch entirely while V is being chased. Default OFF:
  // respectPlayerHeat already stops us overriding attitude while you are
  // wanted, and cops turning up to a firefight you happen to be in is correct
  // behaviour rather than a bug. Leaving this on also makes the mod
  // untestable, because starting a fight with police is the easiest way to
  // generate violence.
  public let suppressDuringChase: Bool = false;

  // CIRCUIT BREAKER. If V picks up a wanted level while our units are alive,
  // delete every one of them immediately. Without this the mod can bootstrap a
  // wanted level it then keeps feeding, and you cannot shake it.
  public let despawnOnPlayerWanted: Bool = true;

  // --- tick -----------------------------------------------------------------

  public let tickInterval: Float = 1.5;

  // --- unit records ---------------------------------------------------------
  // Every record here is one the GAME ITSELF spawns dynamically (they are all
  // used as vehicle passenger records). That matters: a record merely existing
  // is not the same as it being safe to instantiate from scratch. Quest-scene
  // NPCs exist in TweakDB but carry scene dependencies and can hard-crash when
  // spawned cold. Do not add records here unless you know they are spawned
  // dynamically somewhere in vanilla or in a working mod.

  public func Tier1Units() -> array<TweakDBID> {
    return [
      t"Character.ncpd_inspector_ranged1_lexington_ma",
      t"Character.ncpd_inspector_melee1_baton_ma"
    ];
  }

  public func Tier2Units() -> array<TweakDBID> {
    return [
      t"Character.prevention_border_guards",
      t"Character.prevention_border_guards_shotgun",
      t"Character.prevention_maxtac_rifle_ma"
    ];
  }

  public func Tier3Units() -> array<TweakDBID> {
    return [
      t"Character.maxtac_rifle_ma_elite",
      t"Character.maxtac_shotgun_ma_elite",
      t"Character.maxtac_melee_ma_elite",
      t"Character.maxtac_gunner_mb_elite"
    ];
  }
}

public static func NCDLog(msg: String) -> Void {
  let cfg: ref<NCDConfig> = NCDConfig.Get();
  if IsDefined(cfg) && cfg.debugON {
    FTLog("[NCDispatch] " + msg);
  };
}
