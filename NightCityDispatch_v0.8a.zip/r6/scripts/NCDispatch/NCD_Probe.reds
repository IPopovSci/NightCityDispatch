module NCDispatch

// ============================================================================
//  DIAGNOSTIC PROBE v2 - temporary, delete once things work
//
//  v1 used FTLog only, which did not surface. This version writes to three
//  places at once so at least one of them lands:
//    1. an on-screen message (unmissable)
//    2. FTLog (redscript sink)
//  (LogChannel was removed - it does not exist in this redscript version.)
//
//  Replaces NCD_Probe.reds. Keep NCD_ProbeSensor.reds as-is.
// ============================================================================

public class NCDProbe extends ScriptableSystem {

  private let m_tickID: DelayID;
  private let m_beats: Int32;


  public static func Get(gi: GameInstance) -> ref<NCDProbe> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDProbe") as NCDProbe;
  }

  protected func OnAttach() -> Void {
    FTLog("[NCDProbe] attached");
    this.Schedule(6.0);
  }

  private func Schedule(t: Float) -> Void {
    let ds: ref<DelaySystem> = GameInstance.GetDelaySystem(this.GetGameInstance());
    if IsDefined(ds) {
      let cb: ref<NCDProbeCallback> = new NCDProbeCallback();
      cb.system = this;
      this.m_tickID = ds.DelayCallback(cb, t);
    };
  }

  // ---------------------------------------------------------------------------
  // Standard redscript on-screen debug print.
  // ---------------------------------------------------------------------------
  private func Screen(text: String) -> Void {
    let gi: GameInstance = this.GetGameInstance();
    let bb: ref<IBlackboard> = GameInstance.GetBlackboardSystem(gi).Get(GetAllBlackboardDefs().UI_Notifications);
    if !IsDefined(bb) {
      return;
    };
    let msg: SimpleScreenMessage;
    msg.isShown = true;
    msg.duration = 4.0;
    msg.message = text;
    bb.SetVariant(GetAllBlackboardDefs().UI_Notifications.OnscreenMessage, ToVariant(msg), true);
  }

  public func Beat() -> Void {
    let gi: GameInstance = this.GetGameInstance();

    if GameInstance.GetSystemRequestsHandler().IsPreGame() {
      this.Schedule(5.0);
      return;
    };

    this.m_beats += 1;

    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let reg: ref<NCDRegistry> = NCDRegistry.Get(gi);
    let spw: ref<NCDSpawner> = NCDSpawner.Get(gi);
    let dsp: ref<NCDDispatcher> = NCDDispatcher.Get(gi);

    // Compact, because it has to fit on screen.
    let sys: String = "";
    if IsDefined(cfg) { sys += "C"; } else { sys += "-"; };
    if IsDefined(reg) { sys += "R"; } else { sys += "-"; };
    if IsDefined(spw) { sys += "S"; } else { sys += "-"; };
    if IsDefined(dsp) { sys += "D"; } else { sys += "-"; };
    if IsDefined(reg) && reg.attachHookLive { sys += "A"; } else { sys += "-"; };

    let inc: Int32 = 0;
    let live: Int32 = 0;
    let tagged: Int32 = 0;
    let cmb: Int32 = 0;
    let alr: Int32 = 0;
    let dth: Int32 = 0;
    let hNow: Float = 0.0;
    let hPeak: Float = 0.0;
    let sAtt: Int32 = 0;
    let sOk: Int32 = 0;
    let sAtch: Int32 = 0;
    let sDet: Int32 = 0;
    if IsDefined(reg) {
      inc = reg.Count();
      cmb = reg.sensedCombat;
      alr = reg.sensedAlert;
      dth = reg.sensedDeath;
      hNow = reg.MaxHeat();
      hPeak = reg.peakHeat;
      sAtt = reg.spawnAttempts;
      sOk = reg.spawnSuccess;
      sAtch = reg.unitsAttached;
      sDet = reg.unitsDetached;
    };
    if IsDefined(spw) {
      live = spw.LiveUnitCount();
      tagged = spw.TaggedCount();
    };

    let short: String = "NCD " + ToString(this.m_beats) + " [" + sys + "]"
      + " sig " + ToString(cmb) + "/" + ToString(alr) + "/" + ToString(dth)
      + " inc " + ToString(inc)
      + " heat " + FloatToStringPrec(hNow, 1) + "/" + FloatToStringPrec(hPeak, 1)
      + " spawn " + ToString(sOk) + "/" + ToString(sAtt) + " att " + ToString(sAtch) + "/" + ToString(sDet)
      + " units " + ToString(live) + "(tag" + ToString(tagged) + ")";

    if IsDefined(cfg) && !cfg.spawnEnabled {
      short = "SPAWN-OFF " + short;
    };

    this.Screen(short);
    FTLog(short);

    this.Schedule(5.0);
  }
}

public class NCDProbeCallback extends DelayCallback {
  public let system: wref<NCDProbe>;
  public func Call() -> Void {
    if IsDefined(this.system) {
      this.system.Beat();
    };
  }
}
