module NCDispatch

// ============================================================================
//  Incident model + registry
//
//  An "incident" is a cluster of violent events in space and time. Heat is
//  accumulated from stimuli, decays continuously, and crosses thresholds that
//  trigger escalating NCPD waves. Combatant EntityIDs are collected so the
//  responding units know who to shoot at.
// ============================================================================

public class NCDIncident extends IScriptable {
  public let position: Vector4;
  public let heat: Float;
  public let lastEvent: Float;
  public let tier: Int32;
  public let nextWaveAt: Float;
  public let combatants: array<EntityID>;

  public func AddCombatant(id: EntityID) -> Void {
    if EntityID.GetHash(id) > 1u && !ArrayContains(this.combatants, id) {
      if ArraySize(this.combatants) < 24 {
        ArrayPush(this.combatants, id);
      };
    };
  }
}

public class NCDRegistry extends ScriptableSystem {

  private let m_incidents: array<ref<NCDIncident>>;
  private let m_lock: RWLock;

  // Diagnostic counters, read by the probe. Harmless to leave in.
  public let sensedCombat: Int32;
  public let sensedAlert: Int32;
  public let sensedDeath: Int32;
  public let spawnAttempts: Int32;
  public let spawnSuccess: Int32;
  public let unitsAttached: Int32;
  public let unitsDetached: Int32;
  public let attachHookLive: Bool;
  public let peakHeat: Float;

  public static func Get(gi: GameInstance) -> ref<NCDRegistry> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDRegistry") as NCDRegistry;
  }

  // ---------------------------------------------------------------------------
  // Called from the stim hook. Merges into a nearby incident or opens a new one.
  // ---------------------------------------------------------------------------
  public func AddHeat(pos: Vector4, amount: Float, combatant: EntityID) -> Void {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    if !IsDefined(cfg) || !cfg.modON || amount <= 0.0 {
      return;
    };

    let gi: GameInstance = this.GetGameInstance();
    let now: Float = EngineTime.ToFloat(GameInstance.GetSimTime(gi));

    RWLock.Acquire(this.m_lock);

    let merged: Bool = false;
    let i: Int32 = 0;
    while i < ArraySize(this.m_incidents) {
      let inc: ref<NCDIncident> = this.m_incidents[i];
      if Vector4.Distance(inc.position, pos) <= cfg.mergeRadius {
        inc.heat += amount;
        inc.lastEvent = now;
        // Drift the incident centre toward new activity so a running
        // firefight keeps the marker roughly on top of the shooting.
        inc.position = (inc.position * 0.8) + (pos * 0.2);
        inc.AddCombatant(combatant);
        merged = true;
        i = ArraySize(this.m_incidents);
      } else {
        i += 1;
      };
    };

    if !merged && ArraySize(this.m_incidents) < cfg.maxIncidents {
      let inc: ref<NCDIncident> = new NCDIncident();
      inc.position = pos;
      inc.heat = amount;
      inc.lastEvent = now;
      inc.tier = 0;
      inc.nextWaveAt = 0.0;
      inc.AddCombatant(combatant);
      ArrayPush(this.m_incidents, inc);
    };

    RWLock.Release(this.m_lock);
  }

  // ---------------------------------------------------------------------------
  // Decay + prune. Returns the surviving incidents for the dispatcher to read.
  // ---------------------------------------------------------------------------
  public func Update(now: Float, dt: Float, playerPos: Vector4) -> array<ref<NCDIncident>> {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let survivors: array<ref<NCDIncident>>;
    if !IsDefined(cfg) {
      return survivors;
    };

    RWLock.Acquire(this.m_lock);

    let kept: array<ref<NCDIncident>>;
    for inc in this.m_incidents {
      inc.heat -= cfg.heatDecayPerSec * dt;
      let tooFar: Bool = Vector4.Distance(inc.position, playerPos) > cfg.maxRangeFromPlayer;
      if inc.heat > cfg.maxIncidentHeat {
        inc.heat = cfg.maxIncidentHeat;
      };
      if inc.heat > 0.5 && !tooFar {
        ArrayPush(kept, inc);
      };
    };
    this.m_incidents = kept;
    survivors = kept;

    RWLock.Release(this.m_lock);
    return survivors;
  }

  public func Clear() -> Void {
    let empty: array<ref<NCDIncident>>;
    RWLock.Acquire(this.m_lock);
    this.m_incidents = empty;
    RWLock.Release(this.m_lock);
  }

  // Highest heat currently held by any incident - for diagnostics.
  public func MaxHeat() -> Float {
    let best: Float = 0.0;
    RWLock.AcquireShared(this.m_lock);
    for inc in this.m_incidents {
      if inc.heat > best { best = inc.heat; };
    };
    RWLock.ReleaseShared(this.m_lock);
    return best;
  }

  public func Count() -> Int32 {
    RWLock.AcquireShared(this.m_lock);
    let n: Int32 = ArraySize(this.m_incidents);
    RWLock.ReleaseShared(this.m_lock);
    return n;
  }
}
