module NCDispatch

// ============================================================================
//  Dispatcher
//
//  The heartbeat. Decays incident heat, checks it against the escalation
//  ladder, and asks the spawner for a wave when a threshold is crossed.
// ============================================================================

public class NCDDispatcher extends ScriptableSystem {

  private let m_initialized: Bool;
  private let m_tickDelayID: DelayID;
  private let m_lastTick: Float;

  public static func Get(gi: GameInstance) -> ref<NCDDispatcher> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDDispatcher") as NCDDispatcher;
  }

  protected func OnAttach() -> Void {
    if this.m_initialized {
      return;
    };
    this.m_initialized = true;
    this.ScheduleTick(3.0);
  }

  protected func OnDetach() -> Void {
    let ds: ref<DelaySystem> = GameInstance.GetDelaySystem(this.GetGameInstance());
    if IsDefined(ds) {
      ds.CancelCallback(this.m_tickDelayID);
    };
  }

  private func ScheduleTick(interval: Float) -> Void {
    let ds: ref<DelaySystem> = GameInstance.GetDelaySystem(this.GetGameInstance());
    if IsDefined(ds) {
      let cb: ref<NCDHeartbeatCallback> = new NCDHeartbeatCallback();
      cb.system = this;
      this.m_tickDelayID = ds.DelayCallback(cb, interval);
    };
  }

  public func Heartbeat() -> Void {
    let gi: GameInstance = this.GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();

    if !IsDefined(cfg) || !cfg.modON {
      this.ScheduleTick(2.0);
      return;
    };
    if GameInstance.GetSystemRequestsHandler().IsPreGame() {
      this.ScheduleTick(2.0);
      return;
    };

    let player: ref<PlayerPuppet> = GetPlayer(gi);
    let registry: ref<NCDRegistry> = NCDRegistry.Get(gi);
    let spawner: ref<NCDSpawner> = NCDSpawner.Get(gi);
    if !IsDefined(player) || !IsDefined(registry) || !IsDefined(spawner) {
      this.ScheduleTick(2.0);
      return;
    };

    let now: Float = EngineTime.ToFloat(GameInstance.GetSimTime(gi));
    let dt: Float = now - this.m_lastTick;
    if dt <= 0.0 || dt > 30.0 {
      dt = cfg.tickInterval;
    };
    this.m_lastTick = now;

    // Circuit breaker + chase suppression. If V is wanted at all, our units
    // are removed and the system stands down. This is what stops the mod
    // bootstrapping a wanted level and then feeding it forever.
    let ps: ref<PreventionSystem> =
      GameInstance.GetScriptableSystemsContainer(gi).Get(n"PreventionSystem") as PreventionSystem;
    if IsDefined(ps) {
      let wanted: Bool = EnumInt(ps.GetHeatStage()) > 0;
      let chased: Bool = ps.IsChasingPlayer();
      if (cfg.despawnOnPlayerWanted && wanted) || (cfg.suppressDuringChase && chased) {
        spawner.DespawnAll();
        registry.Clear();
        this.ScheduleTick(cfg.tickInterval);
        return;
      };
    };

    let playerPos: Vector4 = player.GetWorldPosition();
    let incidents: array<ref<NCDIncident>> = registry.Update(now, dt, playerPos);

    if ArraySize(incidents) == 0 {
      this.ScheduleTick(cfg.tickInterval);
      return;
    };

    let live: Int32 = spawner.LiveUnitCount();

    // Sustained heat: an ongoing firefight keeps feeding the incident, so a
    // long fight escalates instead of decaying below threshold.
    for inc in incidents {
      let fighting: Int32 = 0;
      for cid in inc.combatants {
        let cPuppet: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, cid) as ScriptedPuppet;
        if IsDefined(cPuppet) && ScriptedPuppet.IsActive(cPuppet) && NPCPuppet.IsInCombat(cPuppet) {
          fighting += 1;
        };
      };
      if fighting > 0 {
        inc.heat += cfg.heatSustainPerCombatant * Cast<Float>(fighting) * dt;
      };
    };

    if registry.MaxHeat() > registry.peakHeat {
      registry.peakHeat = registry.MaxHeat();
    };

    for inc in incidents {
      if live < cfg.maxLiveUnits && now >= inc.nextWaveAt {

      let wantTier: Int32 = 0;
      if inc.heat >= cfg.tier3Heat {
        wantTier = 3;
      } else {
        if inc.heat >= cfg.tier2Heat {
          wantTier = 2;
        } else {
          if inc.heat >= cfg.tier1Heat {
            wantTier = 1;
          };
        };
      };

      if wantTier > 0 && wantTier >= inc.tier {
        let count: Int32 = cfg.tier1Count;
        if wantTier == 2 {
          count = cfg.tier2Count;
        };
        if wantTier == 3 {
          count = cfg.tier3Count;
        };

        let room: Int32 = cfg.maxLiveUnits - live;
        if count > room {
          count = room;
        };

        if count > 0 {
          let got: Int32 = spawner.SpawnWave(inc, wantTier, count);
          if got > 0 {
            inc.tier = wantTier;
            inc.nextWaveAt = now + cfg.waveCooldown;
            live += got;
            NCDLog(s"dispatch tier=\(wantTier) heat=\(inc.heat) live=\(live)");
          };
        };
      };

      };
    };

    this.ScheduleTick(cfg.tickInterval);
  }
}

public class NCDHeartbeatCallback extends DelayCallback {
  public let system: wref<NCDDispatcher>;
  public func Call() -> Void {
    if IsDefined(this.system) {
      this.system.Heartbeat();
    };
  }
}
