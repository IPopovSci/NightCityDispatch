module NCDispatch

// ============================================================================
//  Spawner
//
//  Creates NCPD units off-camera near an incident, points them at it, sets
//  attitude (friendly to V, hostile to the combatants) and cleans them up.
//
//  Spawn/attach/TTL pattern follows They Will Remember's Spawner.reds, which
//  is known-good against the current game build.
// ============================================================================

public class NCDSpawner extends ScriptableSystem {

  private let m_entitySystem: wref<DynamicEntitySystem>;
  private let m_callbackSystem: wref<CallbackSystem>;

  // Combatants for the wave currently being spawned. Read by the attach
  // callback, which fires asynchronously once the entity streams in.
  private let m_pendingTargets: array<EntityID>;
  private let m_pendingDestination: Vector4;
  private let m_lock: RWLock;
  private let m_hookRegistered: Bool;
  private let m_sessionEnding: Bool;

  // Our own record of what we spawned. GetTagged() reports 0 even when the
  // attach callback fires for those same tags, so it cannot be trusted as a
  // population count - and that count gates the spawn cap.
  private let m_tracked: array<EntityID>;

  public static func Get(gi: GameInstance) -> ref<NCDSpawner> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"NCDispatch.NCDSpawner") as NCDSpawner;
  }

  private func OnAttach() -> Void {
    this.m_entitySystem = GameInstance.GetDynamicEntitySystem();
    this.m_callbackSystem = GameInstance.GetCallbackSystem();

    // Registered here, NOT in OnPlayerAttach. Per the Codeware docs,
    // OnPlayerAttach fires for a new game while a loaded save goes through
    // OnRestored - so registering there silently does nothing when you load a
    // save, which is how almost everyone actually starts playing.
    if IsDefined(this.m_callbackSystem) {
      this.m_callbackSystem.RegisterCallback(n"Entity/Attached", this, n"OnUnitAttached")
        .AddTarget(DynamicEntityTarget.Tag(n"NCDispatch"));
      this.m_callbackSystem.RegisterCallback(n"Entity/Detach", this, n"OnUnitDetached")
        .AddTarget(DynamicEntityTarget.Tag(n"NCDispatch"));

      // Tear our entities down BEFORE the session disposes its own objects.
      // Leaving dynamic entities and pending callbacks alive across a reload
      // is a documented route to native crashes.
      this.m_callbackSystem.RegisterCallback(n"Session/BeforeEnd", this, n"OnSessionEnding");
      this.m_hookRegistered = true;
    };
  }

  // Both of these fire well after OnAttach; either one confirms the hook.
  private func OnPlayerAttach(request: ref<PlayerAttachRequest>) {
    this.MarkHookLive();
  }

  private func OnRestored(saveVersion: Int32, gameVersion: Int32) {
    this.MarkHookLive();
  }

  // Session teardown. Without this, entities and their rescheduling TTL
  // callbacks survive into a world that no longer exists - which is a reload
  // crash waiting to happen.
  private func OnDetach() -> Void {
    this.DespawnAll();
  }

  private func MarkHookLive() -> Void {
    if !this.m_hookRegistered {
      return;
    };
    let regHook: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if IsDefined(regHook) {
      regHook.attachHookLive = true;
    };
  }

  // ---------------------------------------------------------------------------
  // Count of units this mod currently has alive.
  // ---------------------------------------------------------------------------
  public func LiveUnitCount() -> Int32 {
    let gi: GameInstance = this.GetGameInstance();
    let stillAlive: array<EntityID>;
    RWLock.Acquire(this.m_lock);
    for id in this.m_tracked {
      let p: ref<ScriptedPuppet> = GameInstance.FindEntityByID(gi, id) as ScriptedPuppet;
      if IsDefined(p) && ScriptedPuppet.IsActive(p) {
        ArrayPush(stillAlive, id);
      };
    };
    this.m_tracked = stillAlive;
    RWLock.Release(this.m_lock);
    return ArraySize(stillAlive);
  }

  // Cross-check only, shown in the probe next to the real number.
  public func TaggedCount() -> Int32 {
    let es: wref<DynamicEntitySystem> = GameInstance.GetDynamicEntitySystem();
    if !IsDefined(es) {
      return 0;
    };
    return ArraySize(es.GetTagged(n"NCDispatch"));
  }

  public func DespawnAll() -> Void {
    let empty: array<EntityID>;
    RWLock.Acquire(this.m_lock);
    for id in this.m_tracked {
      GameInstance.GetDynamicEntitySystem().DeleteEntity(id);
    };
    this.m_tracked = empty;
    RWLock.Release(this.m_lock);
    if !IsDefined(this.m_entitySystem) {
      return;
    };
    let units: array<ref<Entity>> = this.m_entitySystem.GetTagged(n"NCDispatch");
    for u in units {
      this.m_entitySystem.DeleteEntity(u.GetEntityID());
    };
  }

  // ---------------------------------------------------------------------------
  // Spawn one wave of `count` units of `tier` responding to `incident`.
  // ---------------------------------------------------------------------------
  public func SpawnWave(incident: ref<NCDIncident>, tier: Int32, count: Int32) -> Int32 {
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let gi: GameInstance = this.GetGameInstance();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    if !IsDefined(cfg) || !IsDefined(player) || !IsDefined(this.m_entitySystem) {
      return 0;
    };

    let records: array<TweakDBID>;
    if tier <= 1 {
      records = cfg.Tier1Units();
    } else {
      if tier == 2 {
        records = cfg.Tier2Units();
      } else {
        records = cfg.Tier3Units();
      };
    };
    if ArraySize(records) == 0 {
      return 0;
    };
    if !cfg.spawnEnabled {
      let regOff: ref<NCDRegistry> = NCDRegistry.Get(gi);
      if IsDefined(regOff) {
        regOff.spawnAttempts += count;
      };
      return 0;
    };

    RWLock.Acquire(this.m_lock);
    this.m_pendingTargets = incident.combatants;
    this.m_pendingDestination = incident.position;
    RWLock.Release(this.m_lock);

    let spawned: Int32 = 0;
    let i: Int32 = 0;
    while i < count {
      let spawnPos: Vector4;
      if this.FindSpawnPoint(cfg.spawnDistance, spawnPos) {
        let direction: Vector4 = incident.position - spawnPos;
        let len: Float = Vector4.Length(direction);
        let orientation: Quaternion;
        if len > 0.01 {
          orientation = EulerAngles.ToQuat(Vector4.ToRotation(direction / len));
        } else {
          orientation = player.GetWorldOrientation();
        };

        // Reject a degenerate navmesh result rather than handing garbage
        // coordinates to a native call.
        if !Vector4.IsZero(spawnPos) {
          let pick: Int32 = RandRange(0, ArraySize(records));
          let spec = new DynamicEntitySpec();
          spec.recordID = records[pick];
          // No appearanceName override. n"random" is fine for gang records but
          // is not guaranteed to resolve on police records, and an unresolved
          // appearance is a native-side crash rather than a script error.
          spec.position = spawnPos;
          spec.orientation = orientation;
          spec.spawnInView = cfg.allowSpawnInView;
          spec.alwaysSpawned = true;
          spec.persistState = false;
          spec.persistSpawn = false;
          spec.tags = [n"NCDispatch", n"NCDispatch.Unit"];
          let newID: EntityID = this.m_entitySystem.CreateEntity(spec);
          if EntityID.GetHash(newID) > 1u {
            spawned += 1;
            RWLock.Acquire(this.m_lock);
            ArrayPush(this.m_tracked, newID);
            RWLock.Release(this.m_lock);
          };
        };
      };
      i += 1;
    };

    let reg: ref<NCDRegistry> = NCDRegistry.Get(gi);
    if IsDefined(reg) {
      reg.spawnAttempts += count;
      reg.spawnSuccess += spawned;
    };

    NCDLog(s"wave tier=\(tier) requested=\(count) spawned=\(spawned)");
    return spawned;
  }

  // ---------------------------------------------------------------------------
  // Off-camera navmesh point at roughly `desiredDistance` from V.
  // Mirrors TWR's FindReinforcementSpawnPoint.
  // ---------------------------------------------------------------------------
  private func FindSpawnPoint(desiredDistance: Float, out spawnPos: Vector4) -> Bool {
    let gi: GameInstance = this.GetGameInstance();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    let nav: ref<NavigationSystem> = GameInstance.GetNavigationSystem(gi);
    if !IsDefined(nav) || !IsDefined(player) {
      return false;
    };

    let playerPos: Vector4 = player.GetWorldPosition();
    let angle: Float = RandF() * 360.0;
    let offsetDist: Float = 2.0;

    let origin: Vector4 = playerPos;
    origin.X += offsetDist * CosF(angle);
    origin.Y += offsetDist * SinF(angle);
    origin.Z = playerPos.Z + 1.0;
    let originFinal: Vector4 = nav.GetNearestNavmeshPointBelowOnlyHumanNavmesh(origin, 0.5, 6);

    let position: Vector4;
    let ok: Bool = nav.FindNavmeshPointAwayFromReferencePoint(
      originFinal, playerPos, desiredDistance, NavGenAgentSize.Human, position, 10.0, 60.0);

    if !ok {
      let origin2: Vector4 = playerPos;
      origin2.X += offsetDist * CosF(angle + 180.0);
      origin2.Y += offsetDist * SinF(angle + 180.0);
      origin2.Z = playerPos.Z + 1.0;
      let originFinal2: Vector4 = nav.GetNearestNavmeshPointBelowOnlyHumanNavmesh(origin2, 0.5, 6);
      ok = nav.FindNavmeshPointAwayFromReferencePoint(
        originFinal2, playerPos, desiredDistance, NavGenAgentSize.Human, position, 10.0, 60.0);
    };

    if ok {
      spawnPos = position;
    };
    return ok;
  }

  private cb func OnUnitDetached(event: ref<EntityLifecycleEvent>) {
    let regDet: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if IsDefined(regDet) {
      regDet.unitsDetached += 1;
    };
  }

  protected cb func OnSessionEnding(event: ref<GameSessionEvent>) -> Void {
    this.m_sessionEnding = true;
    this.DespawnAll();
  }

  public func IsSessionEnding() -> Bool {
    return this.m_sessionEnding;
  }

  // ---------------------------------------------------------------------------
  // Fires once the unit has actually streamed into the world.
  // ---------------------------------------------------------------------------
  private cb func OnUnitAttached(event: ref<EntityLifecycleEvent>) {
    let entity: ref<Entity> = event.GetEntity();
    if !IsDefined(entity) {
      return;
    };
    let officer: ref<ScriptedPuppet> = entity as ScriptedPuppet;
    if !IsDefined(officer) {
      return;
    };

    let regAtt: ref<NCDRegistry> = NCDRegistry.Get(this.GetGameInstance());
    if IsDefined(regAtt) {
      regAtt.unitsAttached += 1;
    };

    let gi: GameInstance = this.GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    if !IsDefined(cfg) || !IsDefined(player) {
      return;
    };

    RWLock.AcquireShared(this.m_lock);
    let targets: array<EntityID> = this.m_pendingTargets;
    let destination: Vector4 = this.m_pendingDestination;
    RWLock.ReleaseShared(this.m_lock);

    // --- 1. attitude toward V ------------------------------------------------
    // This is the load-bearing bit: these officers are not here for you.
    if cfg.forceFriendlyToPlayer {
      let playerWanted: Bool = false;
      if cfg.respectPlayerHeat {
        let ps: ref<PreventionSystem> =
          GameInstance.GetScriptableSystemsContainer(gi).Get(n"PreventionSystem") as PreventionSystem;
        if IsDefined(ps) && EnumInt(ps.GetHeatStage()) > 0 {
          playerWanted = true;
        };
      };
      if !playerWanted {
        let officerAttitude: ref<AttitudeAgent> = officer.GetAttitudeAgent();
        let playerAttitude: ref<AttitudeAgent> = player.GetAttitudeAgent();
        if IsDefined(officerAttitude) && IsDefined(playerAttitude) {
          officerAttitude.SetAttitudeTowards(playerAttitude, EAIAttitude.AIA_Friendly);
        };
      };
    };

    // --- 2. hostility toward the actual combatants ---------------------------
    let officerAttitude2: ref<AttitudeAgent> = officer.GetAttitudeAgent();
    for targetID in targets {
      let targetEnt: ref<Entity> = GameInstance.FindEntityByID(gi, targetID);
      let targetPuppet: ref<ScriptedPuppet> = targetEnt as ScriptedPuppet;
      if IsDefined(targetPuppet) && ScriptedPuppet.IsActive(targetPuppet) {
        let targetAttitude: ref<AttitudeAgent> = targetPuppet.GetAttitudeAgent();
        if IsDefined(officerAttitude2) && IsDefined(targetAttitude) {
          officerAttitude2.SetAttitudeTowards(targetAttitude, EAIAttitude.AIA_Hostile);
          targetAttitude.SetAttitudeTowards(officerAttitude2, EAIAttitude.AIA_Hostile);
        };
        // Deliberately NOT broadcasting a stim here. A synthetic gunshot next
        // to the player escalates everything in earshot, V included.
      };
    };

    // --- 3. move to the incident --------------------------------------------
    let aiComponent = officer.GetAIControllerComponent();
    let moveCmd: ref<AIMoveToCommand> = new AIMoveToCommand();
    let end: AIPositionSpec;
    let endWorldPosition: WorldPosition;
    WorldPosition.SetVector4(endWorldPosition, destination);
    AIPositionSpec.SetWorldPosition(end, endWorldPosition);
    moveCmd.movementTarget = end;
    moveCmd.ignoreInCombat = false;
    moveCmd.alwaysUseStealth = false;
    moveCmd.ignoreNavigation = false;
    moveCmd.movementType = moveMovementType.Sprint;
    moveCmd.desiredDistanceFromTarget = 6.0 + RandF() * 8.0;
    moveCmd.finishWhenDestinationReached = true;

    let evt: ref<AICommandEvent> = new AICommandEvent();
    evt.command = moveCmd;
    officer.QueueEvent(evt);
    if IsDefined(aiComponent) {
      aiComponent.SendCommand(moveCmd);
    };

    // --- 4. schedule cleanup -------------------------------------------------
    GameInstance.GetDelaySystem(gi).DelayCallback(
      NCDUnitTTLCallback.Create(officer.GetEntityID()), cfg.ttlInterval, true);
  }
}

// ============================================================================
//  TTL / despawn
// ============================================================================

public class NCDUnitTTLCallback extends DelayCallback {

  private let id: EntityID;

  public static func Create(id: EntityID) -> ref<NCDUnitTTLCallback> {
    let self: ref<NCDUnitTTLCallback> = new NCDUnitTTLCallback();
    self.id = id;
    return self;
  }

  public func Call() -> Void {
    let gi: GameInstance = GetGameInstance();
    let cfg: ref<NCDConfig> = NCDConfig.Get();
    let entitySystem: wref<DynamicEntitySystem> = GameInstance.GetDynamicEntitySystem();
    let player: ref<PlayerPuppet> = GetPlayer(gi);
    if !IsDefined(cfg) || !IsDefined(entitySystem) || !IsDefined(player) {
      return;
    };

    // Never touch the entity system while the session is being disposed.
    if GameInstance.GetSystemRequestsHandler().IsPreGame() {
      return;
    };
    let spawnerRef: ref<NCDSpawner> = NCDSpawner.Get(gi);
    if IsDefined(spawnerRef) && spawnerRef.IsSessionEnding() {
      return;
    };

    let ent: ref<Entity> = GameInstance.FindEntityByID(gi, this.id);
    let puppet: ref<ScriptedPuppet> = ent as ScriptedPuppet;
    if !IsDefined(puppet) {
      return;
    };

    let dist: Float = Vector4.Distance(puppet.GetWorldPosition(), player.GetWorldPosition());
    let dead: Bool = !ScriptedPuppet.IsActive(puppet);
    let idle: Bool = !NPCPuppet.IsInCombat(puppet);

    // Remove if: far away, or dead and out of sight, or idle and drifting off.
    let remove: Bool = dist > cfg.despawnDistance
      || (dead && dist > 60.0)
      || (idle && dist > cfg.despawnDistance * 0.6);

    if remove {
      entitySystem.DeleteEntity(this.id);
      NCDLog("despawned a unit");
    } else {
      GameInstance.GetDelaySystem(gi).DelayCallback(
        NCDUnitTTLCallback.Create(this.id), cfg.ttlInterval, true);
    };
  }
}
