import NCDispatch.*

// ============================================================================
//  Sensors v2
//
//  v1 wrapped ReactionManagerComponent.OnDelayStimEvent. In a real load order
//  that method never fired once - confirmed by counter, not by guessing.
//
//  v2 uses two hooks taken verbatim from Street Sense, which are known to fire
//  against the current build:
//
//    NPCPuppet.ChangeHighLevelState  - every NPC entering Combat or Alerted
//    ScriptedPuppet.OnDeath          - every NPC death
//
//  Combat entry is a far better signal than stimuli anyway: it is the game
//  telling us a fight is starting, rather than us inferring it from noise.
// ============================================================================

// ---------------------------------------------------------------------------
// Guard against counting our own officers - otherwise responding units enter
// combat, generate heat, and summon more units forever.
// ---------------------------------------------------------------------------
public static func NCD_IsOurUnit(obj: ref<GameObject>) -> Bool {
  if !IsDefined(obj) {
    return false;
  };
  let es: ref<DynamicEntitySystem> = GameInstance.GetDynamicEntitySystem();
  if !IsDefined(es) {
    return false;
  };
  return ArrayContains(es.GetTags(obj.GetEntityID()), n"NCDispatch");
}

@wrapMethod(NPCPuppet)
public final static func ChangeHighLevelState(obj: ref<GameObject>, newState: gamedataNPCHighLevelState) -> Void {
  wrappedMethod(obj, newState);

  let cfg: ref<NCDConfig> = NCDConfig.Get();
  if !IsDefined(cfg) || !cfg.modON {
    return;
  };
  if !IsDefined(obj) || obj.IsPlayer() {
    return;
  };
  if GameInstance.GetSystemRequestsHandler().IsPreGame() {
    return;
  };
  if NCD_IsOurUnit(obj) {
    return;
  };

  let weight: Float = 0.0;
  let isCombat: Bool = false;
  if Equals(newState, gamedataNPCHighLevelState.Combat) {
    weight = cfg.heatCombatEntry;
    isCombat = true;
  } else {
    if Equals(newState, gamedataNPCHighLevelState.Alerted) {
      weight = cfg.heatAlerted;
    };
  };

  if weight <= 0.0 {
    return;
  };

  let registry: ref<NCDRegistry> = NCDRegistry.Get(GetGameInstance());
  if !IsDefined(registry) {
    return;
  };

  if isCombat {
    registry.sensedCombat += 1;
    // Anyone entering combat is a legitimate target for responding officers.
    registry.AddHeat(obj.GetWorldPosition(), weight, obj.GetEntityID());
  } else {
    registry.sensedAlert += 1;
    // Alerted bystanders raise heat but are never marked as targets.
    let none: EntityID;
    registry.AddHeat(obj.GetWorldPosition(), weight, none);
  };
}

@wrapMethod(ScriptedPuppet)
protected cb func OnDeath(evt: ref<gameDeathEvent>) -> Bool {
  // Capture position before wrappedMethod - death processing can invalidate it.
  let deathPos: Vector4 = this.GetWorldPosition();
  let wasOurUnit: Bool = NCD_IsOurUnit(this);

  let result: Bool = wrappedMethod(evt);

  let cfg: ref<NCDConfig> = NCDConfig.Get();
  if !IsDefined(cfg) || !cfg.modON {
    return result;
  };

  let sysHandler = GameInstance.GetSystemRequestsHandler();
  if IsDefined(sysHandler) && sysHandler.IsPreGame() {
    return result;
  };

  let registry: ref<NCDRegistry> = NCDRegistry.Get(GetGameInstance());
  if !IsDefined(registry) {
    return result;
  };

  registry.sensedDeath += 1;

  // An officer going down escalates hard. This is the deliberate exception to
  // the self-exclusion rule: our units cannot generate heat by ENTERING combat
  // (that would loop forever), but they absolutely can by dying.
  if wasOurUnit {
    let noTarget: EntityID;
    registry.AddHeat(deathPos, cfg.heatOfficerDeath, noTarget);
    return result;
  };

  // A body dropped by someone other than V is the strongest signal there is.
  let killer: EntityID;
  let weight: Float = cfg.heatDeath;
  let instigator: ref<GameObject> = evt.instigator as GameObject;
  if IsDefined(instigator) && !instigator.IsPlayer() && !NCD_IsOurUnit(instigator) {
    killer = instigator.GetEntityID();
    weight *= cfg.thirdPartyMult;
  };

  registry.AddHeat(deathPos, weight, killer);
  return result;
}
